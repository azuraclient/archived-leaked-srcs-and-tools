#pragma once
#include "memory.h"
#include "unity.h"

#include "SDK\MainCamera.h"
#include "SDK\Provider.h"
#include "SDK\VehicleManager.h"
#include "SDK\ZombieManager.h"
#include "SDK\ItemManager.h"
#include "SDK\StructureManager.h"
#include "SDK\BarricadeManager.h"
#include "SDK\AnimalManager.h"

#include "settings.h"
#include "menu.h"
#include "players.h"
#include "zombies.h"
#include "loot.h"

class Unturned
{
private:
	Graphics* draw = nullptr;

    enum GameState
    {
        LobbyLoading,
        inLobby,
        ServerLoading,
        inServer
    };

    bool find_unturned()
    {
        MONO_BASEADDRESS = 0x0;
        unsigned char instances = getProcessCount(XORS(L"Unturned.exe"));
        for (unsigned char i = 0; i < instances && !MONO_BASEADDRESS; i++)
            MONO_BASEADDRESS = modBase(findProcess(XORS(L"Unturned.exe"), i), XORS("mono-2.0-bdwgc.dll"));
        if (MONO_BASEADDRESS)
            return true;
        draw->begin();
        const char* txt = XORS("Searching for Unturned.exe");
        fRect txtSize = draw->textRect(0, TOPLEFT, 10, 3, txt);
        draw->rect(txtSize, 0, { 0.3, 0.3, 0.3, 0.5 });
        draw->text(txtSize, 10, 3, { 0.9, 0.9, 0.9, 1 }, txt);
        draw->end();
        return false;
    }
    
    bool find_offsets()
    {
        draw->begin();
        const char* txt = XORS("Loading Mono");
        fRect txtSize = draw->textRect(0, TOPLEFT, 10, 3, txt);
        draw->rect(txtSize, 0, { 0.3, 0.3, 0.3, 0.5 });
        draw->text(txtSize, 10, 3, { 0.9, 0.9, 0.9, 1 }, txt);
        draw->end();

        SDK::offset::Provider::define_feilds();
        SDK::offset::ModeConfigData::define_feilds();
        SDK::offset::GameplayConfigData::define_feilds();
        SDK::offset::SteamPlayerID::define_feilds();
        SDK::offset::SteamPlayer::define_feilds();
        SDK::offset::PlayerSkills::define_feilds();
        SDK::offset::PlayerLook::define_feilds();
        SDK::offset::PlayerLife::define_feilds();
        SDK::offset::PlayerEquipment::define_feilds();
        SDK::offset::PlayerAnimator::define_feilds();
        SDK::offset::Player::define_feilds();
        SDK::offset::ItemAsset::define_feilds();
        SDK::offset::ItemWeaponAsset::define_feilds();
        SDK::offset::ItemGunAsset::define_feilds();
        SDK::offset::MainCamera::define_feilds();
        SDK::offset::VehicleManager::define_feilds();
        SDK::offset::VehicleAsset::define_feilds();
        SDK::offset::InteractableVehicle::define_feilds();
        SDK::offset::Zombie::define_feilds();
        SDK::offset::ZombieManager::define_feilds();
        SDK::offset::ZombieRegion::define_feilds();
        SDK::offset::ItemRegion::define_feilds();
        SDK::offset::ItemManager::define_feilds();
        SDK::offset::ItemDrop::define_feilds();
        SDK::offset::Item::define_feilds();
        SDK::offset::ItemWeaponAsset::define_feilds();
        SDK::offset::StructureManager::define_feilds();
        SDK::offset::StructureDrop::define_feilds();
        SDK::offset::ItemStructureAsset::define_feilds();
        SDK::offset::StructureRegion::define_feilds();
        SDK::offset::BarricadeManager::define_feilds();
        SDK::offset::BarricadeDrop::define_feilds();
        SDK::offset::BarricadeRegion::define_feilds();
        SDK::offset::ItemBarricadeAsset::define_feilds();
        SDK::offset::Animal::define_feilds();
        SDK::offset::AnimalAsset::define_feilds();
        SDK::offset::AnimalManager::define_feilds();
        SDK::offset::PlayerMovement::define_feilds();
        SDK::offset::PlayerInteract::define_feilds();
        SDK::offset::Asset::define_feilds();
        SDK::offset::InteractableItem::define_feilds();
        SDK::offset::Skill::define_feilds();
        SDK::offset::PlayerStance::define_feilds();
        SDK::offset::UseableGun::define_feilds();
        SDK::offset::Attachments::define_feilds();
        SDK::offset::ItemSightAsset::define_feilds();

        VehicleManager   = (SDK::VehicleManager*)   SDK::offset::VehicleManager::   mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();
        ZombieManager    = (SDK::ZombieManager*)    SDK::offset::ZombieManager::    mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();
        ItemManager      = (SDK::ItemManager*)      SDK::offset::ItemManager::      mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();
        StructureManager = (SDK::StructureManager*) SDK::offset::StructureManager:: mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();
        BarricadeManager = (SDK::BarricadeManager*) SDK::offset::BarricadeManager:: mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();
        AnimalManager    = (SDK::AnimalManager*)    SDK::offset::AnimalManager::    mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();
        Provider         = (SDK::Provider*)         SDK::offset::Provider::         mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();
        MainCamera       = (SDK::MainCamera*)       SDK::offset::MainCamera::       mono_class->get_vtable(mono::get_root_domain())->get_static_field_data();

        return Provider->_isInitialized();
    }
    
    GameState game_state()
    {
        if (Provider->_isConnected())
        {
            auto _clients = Provider->_clients();
            if (!_clients.size())
                return GameState::ServerLoading;
            else
                return GameState::inServer;
        }
        else
        {
            if (MainCamera->camera())
                return GameState::inLobby;
            else
                return GameState::LobbyLoading;
        }
    }
    
    PlayerList* players = nullptr;
    ZombieList* zombies = nullptr;
    ItemList* items = nullptr;

    Menu* gui = nullptr;

    void cMain();

    void AimbotPlayer(PlayerList::Target target, SDK::Player* _player, unity::Matrix matrix, Vec3 camPoint);
    void AimbotZombie(ZombieList::Target target, SDK::Player* _player, unity::Matrix matrix, Vec3 camPoint);
    bool shouldTargetZombie(unity::Matrix* matrix, PlayerList::Target tp, ZombieList::Target tz);
public:
    Unturned(Graphics* draw)
    {
        this->draw = draw;
        gui = new Menu(draw);

        while (!find_unturned())// searching for game
            if (draw->getKey(VK_END)->hold)
                return;
        while (!find_offsets() && MONO_BASEADDRESS)//loading mono
            if (draw->getKey(VK_END)->hold)
                MONO_BASEADDRESS = 0;

        players = new PlayerList(draw);
        zombies = new ZombieList(draw);
        items = new ItemList(draw);

        auto _config = Provider->_modeConfigData()->Gameplay();
        Settings::Game::chart = _config->Chart();
        Settings::Game::satellite = _config->Satellite();
        Settings::Game::compass = _config->Compass();
        Settings::Game::exitTimer = (float)_config->Timer_Exit() / 20.f;
    }

    Vec2 worldToScreen(unity::Matrix* matrix, Vec3 WorldPos)
    {
        if (WorldPos == 0)
            return -1;
        float width = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(WorldPos) + matrix->translation.w;
        Vec2 pos = Vec2(Vec3(matrix->right.x, matrix->up.x, matrix->forward.x).dot(WorldPos) + matrix->translation.x, Vec3(matrix->right.y, matrix->up.y, matrix->forward.y).dot(WorldPos) + matrix->translation.y);
        if (width < 0.098)
            return -1;
        Vec2 point = Vec2((draw->canvasSize.x / 2) * (1 + pos.x / width), (draw->canvasSize.y / 2) * (1 - pos.y / width));
        if (point.x > 0 && point.y > 0 && point.x < draw->canvasSize.x && point.y < draw->canvasSize.y)
            return point;
        return -1;
    }

    static Vec2 calcAngles(Vec3 src, Vec3 dest)
    {
        Vec3 delta = dest - src;
        return {
            1.5707963268f + -atan2f(delta.y, sqrtf(delta.z * delta.z + delta.x * delta.x)),
            atan2f(delta.x, delta.z)
        };
    }

    void update()
    {
        while (MONO_BASEADDRESS && read<QWORD>(MONO_BASEADDRESS) && !draw->getKey(VK_END)->hold)
        {
            draw->begin();
            switch (game_state())
            {
            case GameState::LobbyLoading:
            {
                const char* txt = XORS("Loading into lobby");
                fRect txtSize = draw->textRect(0, TOPLEFT, 10, 3, txt);
                draw->rect(txtSize, 0, { 0.3, 0.3, 0.3, 0.5 });
                draw->text(txtSize, 10, 3, { 0.9, 0.9, 0.9, 1 }, txt);
                break;
            }
            case GameState::inLobby:
            {
                const char* txt = XORS("Join a server");
                fRect txtSize = draw->textRect(0, TOPLEFT, 10, 3, txt);
                draw->rect(txtSize, 0, { 0.3, 0.3, 0.3, 0.5 });
                draw->text(txtSize, 10, 3, { 0.9, 0.9, 0.9, 1 }, txt);
                break;
            }
            case GameState::ServerLoading:
            {
                const char* txt = XORS("Loading into Server");
                fRect txtSize = draw->textRect(0, TOPLEFT, 10, 3, txt);
                draw->rect(txtSize, 0, { 0.3, 0.3, 0.3, 0.5 });
                draw->text(txtSize, 10, 3, { 0.9, 0.9, 0.9, 1 }, txt);
                break;
            }
            case GameState::inServer:
            {
                cMain();
                break;
            }
            default:
                draw->end();
                return;
            }

            // handling the menu
            if (draw->getKey(VK_DELETE)->Down)
                draw->toggleFocus();
            if (draw->getFocus())
            {
                if (!gui->update())
                    MONO_BASEADDRESS = 0x0;
            }
            draw->circle((draw->canvasSize / 2) - (Settings::Aimbot::fov * (draw->canvasSize.y / 2)), (Settings::Aimbot::fov * draw->canvasSize.y), CLEAR, true, { 0.7, 0.7, 0.7, 0.2 });
            draw->end();
        }
    }
};

bool Unturned::shouldTargetZombie(unity::Matrix* matrix, PlayerList::Target tp, ZombieList::Target tz)
{
    float min_distance = 100000.f;

    float scale = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(tp.point) + matrix->translation.w;
    float pxDist = worldToScreen(matrix, tp.point).distance(draw->canvasSize / 2);

    if (pxDist < Settings::Aimbot::fov * (draw->canvasSize.y / 2) && pxDist * scale < min_distance)
        min_distance = pxDist * scale;

    scale = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(tz.point) + matrix->translation.w;
    pxDist = worldToScreen(matrix, tz.point).distance(draw->canvasSize / 2);
    if (pxDist < Settings::Aimbot::fov * (draw->canvasSize.y / 2) && pxDist * scale < min_distance)
        return true;
    return false;
}

void Unturned::cMain()
{
    auto camera = MainCamera->camera();
    auto camPoint = camera->position();
    auto matrix = camera->Matrix();

    players->update(camPoint);
    zombies->update(camPoint);
    items->update(camPoint);

    items->render(&matrix);
    zombies->render(&matrix);
    players->render(&matrix);

    auto bPed = players->best_target(Settings::Aimbot::bone);
    auto bZom = zombies->best_target(Settings::Aimbot::bone);


    if(shouldTargetZombie(&matrix, bPed, bZom))
        AimbotZombie(bZom, players->LocalPlayer->_player(), matrix, camPoint);
    else
        AimbotPlayer(bPed, players->LocalPlayer->_player(), matrix, camPoint);

    auto _player = players->LocalPlayer->_player();
    auto _config = Provider->_modeConfigData()->Gameplay();
    auto _equipment = _player->_equipment();
    if (_equipment)
    {
        auto _asset = _equipment->_asset();
        if (_asset)
        {
            auto type = _asset->type();
            if (type == SDK::EItemType::GUN)
            {
                auto _sightAsset = _equipment->_useable()->firstAttachments()->_sightAsset();
                if (_sightAsset)
                {
                    if (draw->getCursor()->rightDown && (bPed.point != 0 || bZom.point != 0))
                    {
                        if (_sightAsset->thirdPersonZoomFactor() <= 2)
                        {
                            _sightAsset->thirdPersonZoomFactor(_sightAsset->zoom());
                            _sightAsset->zoom(1);
                        }
                    }
                    else if (draw->getCursor()->rightUp)
                    {
                        if (_sightAsset->thirdPersonZoomFactor() > 2)
                        {
                            _sightAsset->zoom(_sightAsset->thirdPersonZoomFactor());
                            _sightAsset->thirdPersonZoomFactor(1);
                        }
                    }
                }
                auto _weaponAsset = (SDK::ItemWeaponAsset*)_asset;
                auto _gunAsset = (SDK::ItemGunAsset*)_asset;
                if (Settings::Game::recoil != _gunAsset->aimingRecoilMultiplier())
                    _gunAsset->aimingRecoilMultiplier(Settings::Game::recoil);
                if ((Settings::Game::spread / 4.f) != _gunAsset->baseSpreadAngleRadians())
                    _gunAsset->baseSpreadAngleRadians((Settings::Game::spread / 4.f));
            }
        }
    }

    if (Settings::Game::chart != _config->Chart())
        _config->Chart(Settings::Game::chart);
    if (Settings::Game::satellite != _config->Satellite())
        _config->Satellite(Settings::Game::satellite);
    if (Settings::Game::compass != _config->Compass())
        _config->Compass(Settings::Game::compass);
    if ((Settings::Game::exitTimer * 20.f) != _config->Timer_Exit())
        _config->Timer_Exit(Settings::Game::exitTimer * 20.f);
}

inline void Unturned::AimbotZombie(ZombieList::Target target, SDK::Player* _player, unity::Matrix matrix, Vec3 camPoint)
{
    if (target.point != 0 && Settings::Aimbot::targetZombies)
    {
        auto _equipment = _player->_equipment();
        auto _movement = _player->_movement();
        if (_equipment && !_movement->vehicle())
        {
            auto _asset = _equipment->_asset();
            auto type = _asset->type();
            if (type == SDK::EItemType::GUN || type == SDK::EItemType::MELEE)
            {
                auto _weaponAsset = (SDK::ItemWeaponAsset*)_asset;
                auto _gunAsset = (SDK::ItemGunAsset*)_asset;
                if (_weaponAsset->range() > target.point.distance(camPoint))
                {
                    target.point.y += target.point.distanceFlat(camPoint) * tanf(asin(target.point.distanceFlat(camPoint) * (9.81f * _gunAsset->bulletGravityMultiplier()) / (_gunAsset->muzzleVelocity() * _gunAsset->muzzleVelocity())) * 0.5f);
                    //target.velocity *= (target.point.distance(camPoint) / _gunAsset->muzzleVelocity()) * 1.15f;
                    //target.point -= target.velocity;
                    auto _look = _player->_look();
                    Vec2 _angles = {
                    _look->_pitch(),
                    _look->_yaw() };

                    Vec2 fromAngles = (_angles / 57.2957795131f);
                    Vec2 toAngle = calcAngles(camPoint, target.point);
                    Vec2 Angles = fromAngles.findMidPoint(toAngle, 0.0f + (0.005f - 0.0f) * (1.0f - Settings::Aimbot::smoothing));
                    if (!Settings::Aimbot::smoothing)
                    {
                        Angles -= _player->_animator()->scopeSway();
                        Angles = toAngle;
                        Angles *= 57.2957795131f;
                    }
                    else
                        Angles *= 57.2957795131f;
                    if (draw->getCursor()->right)
                    {
                        _look->_pitch(Angles.x);
                        _look->_yaw(Angles.y);
                    }
                }
            }
        }
    }
}

inline void Unturned::AimbotPlayer(PlayerList::Target target, SDK::Player* _player, unity::Matrix matrix, Vec3 camPoint)
{
    if (target.point != 0 && Settings::Aimbot::targetPlayers)
    {
        auto _equipment = _player->_equipment();
        auto _movement = _player->_movement();
        if (_equipment && !_movement->vehicle())
        {
            auto _asset = _equipment->_asset();
            auto type = _asset->type();
            if (type == SDK::EItemType::GUN || type == SDK::EItemType::MELEE)
            {
                auto _weaponAsset = (SDK::ItemWeaponAsset*)_asset;
                auto _gunAsset = (SDK::ItemGunAsset*)_asset;
                if (_weaponAsset->range() > target.point.distance(camPoint))
                {
                    target.point.y += target.point.distanceFlat(camPoint) * tanf(asin(target.point.distanceFlat(camPoint) * (9.81f * _gunAsset->bulletGravityMultiplier()) / (_gunAsset->muzzleVelocity() * _gunAsset->muzzleVelocity())) * 0.5f);
                    target.velocity *= (target.point.distance(camPoint) / _gunAsset->muzzleVelocity()) * 1.15f;
                    target.point -= target.velocity;
                    auto _look = _player->_look();
                    Vec2 _angles = {
                    _look->_pitch(),
                    _look->_yaw() };

                    Vec2 fromAngles = (_angles / 57.2957795131f);
                    Vec2 toAngle = calcAngles(camPoint, target.point);
                    Vec2 Angles = fromAngles.findMidPoint(toAngle, 0.0f + (0.005f - 0.0f) * (1.0f - Settings::Aimbot::smoothing));
                    if (!Settings::Aimbot::smoothing)
                    {
                        Angles -= _player->_animator()->scopeSway();
                        Angles = toAngle;
                        Angles *= 57.2957795131f;
                    }
                    else
                        Angles *= 57.2957795131f;
                    if (draw->getCursor()->right)
                    {
                        _look->_pitch(Angles.x);
                        _look->_yaw(Angles.y);
                    }
                }
            }
        }
    }
}
