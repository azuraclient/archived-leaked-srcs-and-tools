#include "graphics.h"
#include "memory.h"
#include "mono.h"

#include "unturned.h"

#define CONSOLE int main()
#define WINDOW int WINAPI wWinMain( _In_     HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_     PWSTR     pCmdLine, _In_     int       nShowCmd)


WINDOW
{
	// checks if an istance is already running
	CreateMutexA(0, FALSE, XORS("Local\\$MDTYOJNVCUI$"));
	if (GetLastError() == ERROR_ALREADY_EXISTS)
		return 0;

	if (memory_init())
	{
		Graphics* draw = new Graphics();
		Unturned* mono = new Unturned(draw);

		mono->update();

		delete mono;
		delete draw;
	}
	return 0;
}