#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    enum EPlayerStance
    {
        CLIMB,
        SWIM,
        SPRINT,
        STAND,
        CROUCH,
        PRONE,
        DRIVING,
        SITTING
    };
    namespace offset {
        namespace PlayerStance {
            mono_class_t* mono_class;
            unsigned int _stance;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerStance"));
                if (!mono_class)
                    return;
                _stance = mono_class->find_field(XORS("_stance"))->offset();
            }
        };
    };
    struct PlayerStance {
        auto _stance() { return (EPlayerStance)read<WORD>((QWORD)this + offset::PlayerStance::_stance); }
    };
};
SDK::PlayerStance* PlayerStance = nullptr;