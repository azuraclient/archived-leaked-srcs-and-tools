#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemSightAsset.h"

namespace SDK
{
    namespace offset {
        namespace Attachments {
            mono_class_t* mono_class;

            unsigned int _sightAsset;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Attachments"));
                if (!mono_class)
                    return;
                _sightAsset = mono_class->find_field(XORS("_sightAsset"))->offset();
            }
        };
    };
    struct Attachments {
        auto _sightAsset() { return read<SDK::ItemSightAsset*>((QWORD)this + offset::Attachments::_sightAsset); }
    };
};
SDK::Attachments* Attachments = nullptr;