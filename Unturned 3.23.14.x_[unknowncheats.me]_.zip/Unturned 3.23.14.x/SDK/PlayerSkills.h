#pragma once
#include "../unity.h"
#include "../mono.h"

#include "Skill.h"

namespace SDK
{
    namespace offset {
        namespace PlayerSkills {
            mono_class_t* mono_class;

            unsigned int _reputation;
            unsigned int _skills;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerSkills"));
                if (!mono_class)
                    return;
                _reputation = mono_class->find_field(XORS("_reputation"))->offset();
                _skills = mono_class->find_field(XORS("_skills"))->offset();
            }
        };
    };
    struct PlayerSkills {
        auto _reputation() { return read<DWORD>((QWORD)this + offset::PlayerSkills::_reputation); }
        auto _skills(int row, int colum) { return read<Skill*>({(QWORD)this + offset::PlayerSkills::_skills,  (QWORD)(0x20 + row * 8), (QWORD)(0x20 + colum * 8)});}
    };
};
SDK::PlayerSkills* PlayerSkills = nullptr;