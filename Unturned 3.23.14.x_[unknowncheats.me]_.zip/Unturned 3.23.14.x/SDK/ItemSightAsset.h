#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace ItemSightAsset {
            mono_class_t* mono_class;

            unsigned int zoom;
            unsigned int thirdPersonZoomFactor;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemSightAsset"));
                if (!mono_class)
                    return;
                zoom = mono_class->find_field(XORS("<zoom>k__BackingField"))->offset();
                thirdPersonZoomFactor = mono_class->find_field(XORS("<thirdPersonZoomFactor>k__BackingField"))->offset();

            }
        };
    };
    struct ItemSightAsset {
        auto thirdPersonZoomFactor() { return read<float>((QWORD)this + offset::ItemSightAsset::thirdPersonZoomFactor); }
        auto thirdPersonZoomFactor(float val) { return write<float>((QWORD)this + offset::ItemSightAsset::thirdPersonZoomFactor, val); }
        auto zoom() { return read<float>((QWORD)this + offset::ItemSightAsset::zoom); }
        auto zoom(float val) { return write<float>((QWORD)this + offset::ItemSightAsset::zoom, val); }
    };
};
SDK::ItemSightAsset* ItemSightAsset = nullptr;