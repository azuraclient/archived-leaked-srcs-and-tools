#pragma once
#include "../unity.h"
#include "../mono.h"

#include "BarricadeDrop.h"

namespace SDK
{
    namespace offset {
        namespace BarricadeRegion {
            mono_class_t* mono_class;

            unsigned int _drops;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.BarricadeRegion"));
                if (!mono_class)
                    return;
                _drops = mono_class->find_field(XORS("_drops"))->offset();
            }
        };
    };
    struct BarricadeRegion {
        auto _drops() { return read<unity::List<BarricadeDrop*>*>((QWORD)this + offset::BarricadeRegion::_drops)->data(); }
    };
};
SDK::BarricadeRegion* BarricadeRegion = nullptr;