#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace PlayerLook {
            mono_class_t* mono_class;

            unsigned int _characterCamera;
            unsigned int _scopeCamera;
            unsigned int _aim;
            unsigned int yawInputMultiplier;
            unsigned int pitchInputMultiplier;
            unsigned int _isScopeActive;
            unsigned int _pitch;
            unsigned int _yaw;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerLook"));
                if (!mono_class)
                    return;
                _characterCamera = mono_class->find_field(XORS("_characterCamera"))->offset();
                _scopeCamera = mono_class->find_field(XORS("_scopeCamera"))->offset();
                _aim = mono_class->find_field(XORS("_aim"))->offset();
                yawInputMultiplier = mono_class->find_field(XORS("yawInputMultiplier"))->offset();
                pitchInputMultiplier = mono_class->find_field(XORS("pitchInputMultiplier"))->offset();
                _pitch = mono_class->find_field(XORS("_pitch"))->offset();
                _yaw = mono_class->find_field(XORS("_yaw"))->offset();
            }
        };
    };
    struct PlayerLook {
        auto _characterCamera() { return read<unity::Camera*>((QWORD)this + offset::PlayerLook::_characterCamera); }
        auto _scopeCamera() { return read<unity::Camera*>((QWORD)this + offset::PlayerLook::_scopeCamera); }
        auto _aim() { return read<unity::TransformPtr*>((QWORD)this + offset::PlayerLook::_aim)->m_CachedPtr(); }
        auto yawInputMultiplier() { return read<float>((QWORD)this + offset::PlayerLook::yawInputMultiplier); }
        auto pitchInputMultiplier() { return read<float>((QWORD)this + offset::PlayerLook::pitchInputMultiplier); }
        auto _isScopeActive() { return read<bool>((QWORD)this + offset::PlayerLook::_isScopeActive); }
        auto _pitch() { return read<float>((QWORD)this + offset::PlayerLook::_pitch); }
        auto _yaw() { return read<float>((QWORD)this + offset::PlayerLook::_yaw); }


        auto yawInputMultiplier(float val) { return write<float>((QWORD)this + offset::PlayerLook::yawInputMultiplier, val); }
        auto pitchInputMultiplier(float val) { return write<float>((QWORD)this + offset::PlayerLook::pitchInputMultiplier, val); }
        auto _pitch(float val) { return write<float>((QWORD)this + offset::PlayerLook::_pitch, val); }
        auto _yaw(float val) { return write<float>((QWORD)this + offset::PlayerLook::_yaw, val); }
    };
};
SDK::PlayerLook* PlayerLook = nullptr;