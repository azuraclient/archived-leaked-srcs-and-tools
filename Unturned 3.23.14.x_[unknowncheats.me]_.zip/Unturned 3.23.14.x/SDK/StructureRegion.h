#pragma once
#include "../unity.h"
#include "../mono.h"

#include "StructureDrop.h"

namespace SDK
{
    namespace offset {
        namespace StructureRegion {
            mono_class_t* mono_class;

            unsigned int _drops;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.StructureRegion"));
                if (!mono_class)
                    return;
                _drops = mono_class->find_field(XORS("_drops"))->offset();
            }
        };
    };
    struct StructureRegion {
        auto _drops() { return read<unity::List<StructureDrop*>*>((QWORD)this + offset::StructureRegion::_drops); }
    };
};
SDK::StructureRegion* StructureRegion = nullptr;