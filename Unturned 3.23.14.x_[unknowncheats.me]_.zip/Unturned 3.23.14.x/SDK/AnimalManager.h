#pragma once
#include "../unity.h"
#include "../mono.h"

#include "Animal.h"

namespace SDK
{
    namespace offset {
        namespace AnimalManager {
            mono_class_t* mono_class;

            unsigned int _animals;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.AnimalManager"));
                if (!mono_class)
                    return;
                _animals = mono_class->find_field(XORS("_animals"))->offset();
            }
        };
    };
    struct AnimalManager {
        auto _animals() { return read<unity::List<Animal*>*>((QWORD)this + offset::AnimalManager::_animals)->data(); }
    };
};
SDK::AnimalManager* AnimalManager = nullptr;