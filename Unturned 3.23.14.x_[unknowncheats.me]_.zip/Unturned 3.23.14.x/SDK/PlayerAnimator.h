#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace PlayerAnimator {
            mono_class_t* mono_class;

            unsigned int scopeSway;
            unsigned int viewmodelSwayMultiplier;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerAnimator"));
                if (!mono_class)
                    return;
                scopeSway = mono_class->find_field(XORS("scopeSway"))->offset();
                viewmodelSwayMultiplier = mono_class->find_field(XORS("viewmodelSwayMultiplier"))->offset();
            }
        };
    };
    struct PlayerAnimator {
        auto scopeSway() { return read<Vec2>((QWORD)this + offset::PlayerAnimator::scopeSway); }
        auto viewmodelSwayMultiplier() { return read<float>((QWORD)this + offset::PlayerAnimator::viewmodelSwayMultiplier); }
    };
};
SDK::PlayerAnimator* PlayerAnimator = nullptr;