#pragma once
#include "../unity.h"
#include "../mono.h"

#include "Zombie.h"

namespace SDK
{
    namespace offset {
        namespace ZombieRegion {
            mono_class_t* mono_class;

            unsigned int _zombies;
            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ZombieRegion"));
                if (!mono_class)
                    return;
                _zombies = mono_class->find_field(XORS("_zombies"))->offset();
            }
        };
    };
    struct ZombieRegion {
        auto _zombies() { return read<unity::List<Zombie*>*>((QWORD)this + offset::ZombieRegion::_zombies)->data(); }
    };
};
SDK::ZombieRegion* ZombieRegion = nullptr;