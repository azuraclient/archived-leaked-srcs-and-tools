#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemAsset.h"

namespace SDK
{
    namespace offset {
        namespace ItemWeaponAsset {
            mono_class_t* mono_class;

            unsigned int range;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemWeaponAsset"));
                if (!mono_class)
                    return;
                range = mono_class->find_field(XORS("range"))->offset();
            }
        };
    };
    struct ItemWeaponAsset : public ItemAsset {
        auto range() { return read<float>((QWORD)this + offset::ItemWeaponAsset::range); }
    };
};
SDK::ItemWeaponAsset* ItemWeaponAsset = nullptr;