#pragma once
#include "../unity.h"
#include "../mono.h"

#include "InteractableVehicle.h"

namespace SDK
{
    namespace offset {
        namespace VehicleManager {
            mono_class_t* mono_class;

            unsigned int _vehicles;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.VehicleManager"));
                if (!mono_class)
                    return;
                _vehicles = mono_class->find_field(XORS("_vehicles"))->offset();
            }
        };
    };
    struct VehicleManager {
        auto _vehicles() { return read<unity::List<InteractableVehicle*>*>((QWORD)this + offset::VehicleManager::_vehicles)->data(); }
    };
};
SDK::VehicleManager* VehicleManager = nullptr;