#pragma once
#include "../unity.h"
#include "../mono.h"

#include "Asset.h"

namespace SDK
{
	namespace EItemRarity
	{
		enum EItemRarity
		{
			COMMON,
			UNCOMMON,
			RARE,
			EPIC,
			LEGENDARY,
			MYTHICAL
		};
	}; 

	namespace EItemType
	{
		enum EItemType
		{
			HAT,
			PANTS,
			SHIRT,
			MASK,
			BACKPACK,
			VEST,
			GLASSES,
			GUN,
			SIGHT,
			TACTICAL,
			GRIP,
			BARREL,
			MAGAZINE,
			FOOD,
			WATER,
			MEDICAL,
			MELEE,
			FUEL,
			TOOL,
			BARRICADE,
			STORAGE,
			BEACON,
			FARM,
			TRAP,
			STRUCTURE,
			SUPPLY,
			THROWABLE,
			GROWER,
			OPTIC,
			REFILL,
			FISHER,
			CLOUD,
			MAP,
			KEY,
			BOX,
			ARREST_START,
			ARREST_END,
			TANK,
			GENERATOR,
			DETONATOR,
			CHARGE,
			LIBRARY,
			FILTER,
			SENTRY,
			VEHICLE_REPAIR_TOOL,
			TIRE,
			COMPASS,
			OIL_PUMP
		};
	};
    namespace offset {
        namespace ItemAsset {
            mono_class_t* mono_class;

            unsigned int _itemName;
            unsigned int type;
            unsigned int useable;
            unsigned int rarity;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemAsset"));
                if (!mono_class)
                    return;
                _itemName = mono_class->find_field(XORS("_itemName"))->offset();
                type = mono_class->find_field(XORS("type"))->offset();
                useable = mono_class->find_field(XORS("useable"))->offset();
                rarity = mono_class->find_field(XORS("rarity"))->offset();
            }
        };
    };
    struct ItemAsset : Asset {
        auto _itemName() { return read<unity::String*>((QWORD)this + offset::ItemAsset::_itemName)->string(); }
        auto type() { return (EItemType::EItemType)read<WORD>((QWORD)this + offset::ItemAsset::type); }
        auto useable() { return read<unity::String*>((QWORD)this + offset::ItemAsset::useable)->string(); }
        auto rarity() { return (EItemRarity::EItemRarity)read<WORD>((QWORD)this + offset::ItemAsset::rarity); }
    };
};
SDK::ItemAsset* ItemAsset = nullptr;