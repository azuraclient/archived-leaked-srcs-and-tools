#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemRegion.h"

namespace SDK
{
    namespace offset {
        namespace ItemManager {
            mono_class_t* mono_class;

            unsigned int regions;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemManager"));
                if (!mono_class)
                    return;
                regions = mono_class->find_field(XORS("<regions>k__BackingField"))->offset();
            }
        };
    };
    struct ItemManager {
        auto regions() { return read<unity::Array<ItemRegion*>*>((QWORD)this + offset::ItemManager::regions)->data(); }
    };
};
SDK::ItemManager* ItemManager = nullptr;