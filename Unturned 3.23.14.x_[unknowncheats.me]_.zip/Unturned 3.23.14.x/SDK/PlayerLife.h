#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace PlayerLife {
            mono_class_t* mono_class;

            unsigned int _isDead;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerLife"));
                if (!mono_class)
                    return;
                _isDead = mono_class->find_field(XORS("_isDead"))->offset();
            }
        };
    };
    struct PlayerLife {
        auto _isDead() { return read<bool>((QWORD)this + offset::PlayerLife::_isDead); }
    };
};
SDK::PlayerLife* PlayerLife = nullptr;