#pragma once
#include "../unity.h"
#include "../mono.h"

#include "Attachments.h"

namespace SDK
{
    namespace offset {
        namespace UseableGun {
            mono_class_t* mono_class;

            unsigned int firstAttachments;
            unsigned int thirdAttachments;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.UseableGun"));
                if (!mono_class)
                    return;
                firstAttachments = mono_class->find_field(XORS("firstAttachments"))->offset();
                thirdAttachments = mono_class->find_field(XORS("thirdAttachments"))->offset();
            }
        };
    };
    struct UseableGun {
        auto firstAttachments() { return read<SDK::Attachments*>((QWORD)this + offset::UseableGun::firstAttachments); }
        auto thirdAttachments() { return read<SDK::Attachments*>((QWORD)this + offset::UseableGun::thirdAttachments); }
    };
};
SDK::UseableGun* UseableGun = nullptr;