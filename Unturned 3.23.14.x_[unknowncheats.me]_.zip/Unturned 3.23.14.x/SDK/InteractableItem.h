#pragma once
#include "../unity.h"
#include "../mono.h"

#include "Item.h"
#include "ItemAsset.h"

namespace SDK
{
    namespace offset {
        namespace InteractableItem {
            mono_class_t* mono_class;

            unsigned int item;
            unsigned int asset;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.InteractableItem"));
                if (!mono_class)
                    return;
                item = mono_class->find_field(XORS("item"))->offset();
                asset = mono_class->find_field(XORS("asset"))->offset();
            }
        };
    };
    struct InteractableItem {
        auto item() { return read<Item*>((QWORD)this + offset::InteractableItem::item); }
        auto asset() { return read<ItemAsset*>((QWORD)this + offset::InteractableItem::asset); }
    };
};
SDK::InteractableItem* InteractableItem = nullptr;