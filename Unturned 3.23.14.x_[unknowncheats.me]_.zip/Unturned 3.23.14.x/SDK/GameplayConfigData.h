#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace GameplayConfigData {
            mono_class_t* mono_class;

            unsigned int Chart;
            unsigned int Satellite;
            unsigned int Compass;
            unsigned int Can_Suicide;
            unsigned int Timer_Exit;
            unsigned int Timer_Respawn;
            unsigned int Timer_Home;
            unsigned int Timer_Leave_Group;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.GameplayConfigData"));
                if (!mono_class)
                    return;
                Chart = mono_class->find_field(XORS("Chart"))->offset();
                Satellite = mono_class->find_field(XORS("Satellite"))->offset();
                Compass = mono_class->find_field(XORS("Compass"))->offset();
                Can_Suicide = mono_class->find_field(XORS("Can_Suicide"))->offset();
                Timer_Exit = mono_class->find_field(XORS("Timer_Exit"))->offset();
                Timer_Respawn = mono_class->find_field(XORS("Timer_Respawn"))->offset();
                Timer_Home = mono_class->find_field(XORS("Timer_Home"))->offset();
                Timer_Leave_Group = mono_class->find_field(XORS("Timer_Leave_Group"))->offset();
            }
        };
    };
    struct GameplayConfigData {
        auto Chart() { return read<bool>((QWORD)this + offset::GameplayConfigData::Chart); }
        auto Satellite() { return read<bool>((QWORD)this + offset::GameplayConfigData::Satellite); }
        auto Compass() { return read<bool>((QWORD)this + offset::GameplayConfigData::Compass); }
        auto Can_Suicide() { return read<bool>((QWORD)this + offset::GameplayConfigData::Can_Suicide); }
        auto Timer_Exit() { return read<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Exit); }
        auto Timer_Respawn() { return read<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Respawn); }
        auto Timer_Home() { return read<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Home); }
        auto Timer_Leave_Group() { return read<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Leave_Group); }

        auto Chart(bool val) { return write<bool>((QWORD)this + offset::GameplayConfigData::Chart, val); }
        auto Satellite(bool val) { return write<bool>((QWORD)this + offset::GameplayConfigData::Satellite, val); }
        auto Compass(bool val) { return write<bool>((QWORD)this + offset::GameplayConfigData::Compass, val); }
        auto Can_Suicide(bool val) { return write<bool>((QWORD)this + offset::GameplayConfigData::Can_Suicide, val); }
        auto Timer_Exit(DWORD val) { return write<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Exit, val); }
        auto Timer_Respawn(DWORD val) { return write<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Respawn, val); }
        auto Timer_Home(DWORD val) { return write<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Home, val); }
        auto Timer_Leave_Group(DWORD val) { return write<DWORD>((QWORD)this + offset::GameplayConfigData::Timer_Leave_Group, val); }
    };
};
SDK::GameplayConfigData* GameplayConfigData = nullptr;