#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace Item {
            mono_class_t* mono_class;

            unsigned int _id;
            unsigned int amount;
            unsigned int quality;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Item"));
                if (!mono_class)
                    return;
                _id = mono_class->find_field(XORS("_id"))->offset();
                amount = mono_class->find_field(XORS("amount"))->offset();
                quality = mono_class->find_field(XORS("quality"))->offset();
            }
        };
    };
    struct Item {
        auto _id() { return read<WORD>((QWORD)this + offset::Item::_id); }
        auto amount() { return read<BYTE>((QWORD)this + offset::Item::amount); }
        auto quality() { return read<BYTE>((QWORD)this + offset::Item::quality); }
    };
};
SDK::Item* Item = nullptr;