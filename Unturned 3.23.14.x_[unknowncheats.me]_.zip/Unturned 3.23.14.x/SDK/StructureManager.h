#pragma once
#include "../unity.h"
#include "../mono.h"

#include "StructureRegion.h"

namespace SDK
{
    namespace offset {
        namespace StructureManager {
            mono_class_t* mono_class;

            unsigned int regions;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.StructureManager"));
                if (!mono_class)
                    return;
                regions = mono_class->find_field(XORS("<regions>k__BackingField"))->offset();
            }
        };
    };
    struct StructureManager {
        auto regions() { return read<unity::List<StructureRegion*>*>((QWORD)this + offset::StructureManager::regions); }
    };
};
SDK::StructureManager* StructureManager = nullptr;