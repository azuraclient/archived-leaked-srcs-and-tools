#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace VehicleAsset {
            mono_class_t* mono_class;

            unsigned int _vehicleName;
            unsigned int _rarity;
            unsigned int _healthMax;
            unsigned int _healthMin;
            unsigned int _health;
            unsigned int _fuelMax;
            unsigned int _fuelMin;
            unsigned int _fuel;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.VehicleAsset"));
                if (!mono_class)
                    return;
                _vehicleName = mono_class->find_field(XORS("_vehicleName"))->offset();
                _rarity = mono_class->find_field(XORS("_rarity"))->offset();
                _healthMax = mono_class->find_field(XORS("_healthMax"))->offset();
                _healthMin = mono_class->find_field(XORS("_healthMin"))->offset();
                _health = mono_class->find_field(XORS("_health"))->offset();
                _fuelMax = mono_class->find_field(XORS("_fuelMax"))->offset();
                _fuelMin = mono_class->find_field(XORS("_fuelMin"))->offset();
                _fuel = mono_class->find_field(XORS("_fuel"))->offset();
            }
        };
    };
    struct VehicleAsset {
        auto _vehicleName() { return read<unity::String*>((QWORD)this + offset::VehicleAsset::_vehicleName)->string(); }
        auto _rarity() { return read<DWORD>((QWORD)this + offset::VehicleAsset::_rarity); }
        auto _healthMax() { return read<WORD>((QWORD)this + offset::VehicleAsset::_healthMax); }
        auto _healthMin() { return read<WORD>((QWORD)this + offset::VehicleAsset::_healthMin); }
        auto _health() { return read<WORD>((QWORD)this + offset::VehicleAsset::_health); }
        auto _fuelMax() { return read<WORD>((QWORD)this + offset::VehicleAsset::_fuelMax); }
        auto _fuelMin() { return read<WORD>((QWORD)this + offset::VehicleAsset::_fuelMin); }
        auto _fuel() { return read<WORD>((QWORD)this + offset::VehicleAsset::_fuel); }
    };
};
SDK::VehicleAsset* VehicleAsset = nullptr;