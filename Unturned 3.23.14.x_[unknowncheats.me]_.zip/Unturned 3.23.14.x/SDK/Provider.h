#pragma once
#include "../unity.h"
#include "../mono.h"

#include "SteamPlayer.h"
#include "ModeConfigData.h"

namespace SDK 
{
    namespace offset {
        namespace Provider {
            mono_class_t* mono_class;

            unsigned int _isConnected;
            unsigned int _clients;
            unsigned int _isInitialized;
            unsigned int _modeConfigData;
            unsigned int _serverName;
            unsigned int _clientName;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Provider"));
                if (!mono_class)
                    return;
                _isConnected = mono_class->find_field(XORS("_isConnected"))->offset();
                _isInitialized = mono_class->find_field(XORS("_isInitialized"))->offset();
                _clients = mono_class->find_field(XORS("_clients"))->offset();
                _modeConfigData = mono_class->find_field(XORS("_modeConfigData"))->offset();
                _serverName = mono_class->find_field(XORS("_serverName"))->offset();
                _clientName = mono_class->find_field(XORS("_clientName"))->offset();
            }
        };
    }; 
    struct Provider {
        auto _isConnected() { return read<bool>((QWORD)this + offset::Provider::_isConnected); }
        auto _isInitialized() { return read<bool>((QWORD)this + offset::Provider::_isInitialized); }
        auto _clients() { return read<unity::List<SteamPlayer*>*>((QWORD)this + offset::Provider::_clients)->data(); }
        auto _modeConfigData() { return read<ModeConfigData*>((QWORD)this + offset::Provider::_modeConfigData); }
        auto _serverName() { return read<unity::String*>((QWORD)this + offset::Provider::_serverName)->string(); }
        auto _clientName() { return read<unity::String*>((QWORD)this + offset::Provider::_clientName)->string(); }
    };
}; 
SDK::Provider* Provider = nullptr;