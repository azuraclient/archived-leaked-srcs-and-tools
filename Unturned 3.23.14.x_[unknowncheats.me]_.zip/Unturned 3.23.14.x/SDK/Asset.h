#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace Asset {
            mono_class_t* mono_class;

            unsigned int id;
            unsigned int name;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Asset"));
                if (!mono_class)
                    return;
                id = mono_class->find_field(XORS("id"))->offset();
                name = mono_class->find_field(XORS("name"))->offset();
            }
        };
    };
    struct Asset {
        auto id() { return read<WORD>((QWORD)this + offset::Asset::id); }
        auto name() { return read<unity::String*>((QWORD)this + offset::Asset::name)->string(); }
    };
};
SDK::Asset* Asset = nullptr;