#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ZombieRegion.h"

namespace SDK
{
    namespace offset {
        namespace ZombieManager {
            mono_class_t* mono_class;

            unsigned int regions;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ZombieManager"));
                if (!mono_class)
                    return;
                regions = mono_class->find_field(XORS("_regions"))->offset();
            }
        };
    };
    struct ZombieManager {
        auto regions() { return read<unity::Array<ZombieRegion*>*>((QWORD)this + offset::ZombieManager::regions)->data(); }
    };
};
SDK::ZombieManager* ZombieManager = nullptr;