#pragma once
#include "../unity.h"
#include "../mono.h"


namespace SDK
{
	namespace EBuild
	{
		enum EBuild
		{
			FORTIFICATION,
			BARRICADE,
			DOOR,
			GATE,
			BED,
			LADDER,
			STORAGE,
			FARM,
			TORCH,
			CAMPFIRE,
			SPIKE,
			WIRE,
			GENERATOR,
			SPOT,
			SAFEZONE,
			FREEFORM,
			SIGN,
			VEHICLE,
			CLAIM,
			BEACON,
			STORAGE_WALL,
			BARREL_RAIN,
			OIL,
			CAGE,
			SHUTTER,
			TANK,
			CHARGE,
			SENTRY,
			SENTRY_FREEFORM,
			OVEN,
			LIBRARY,
			OXYGENATOR,
			GLASS,
			NOTE,
			HATCH,
			MANNEQUIN,
			STEREO,
			SIGN_WALL,
			CLOCK,
			BARRICADE_WALL
		};
	};
    namespace offset {
        namespace ItemBarricadeAsset {
            mono_class_t* mono_class;

            unsigned int _build;
            unsigned int _health;
            unsigned int _range;
            unsigned int _radius;
            unsigned int _offset;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemBarricadeAsset"));
                if (!mono_class)
                    return;
                _build = mono_class->find_field(XORS("_build"))->offset();
                _health = mono_class->find_field(XORS("_health"))->offset();
                _range = mono_class->find_field(XORS("_range"))->offset();
                _radius = mono_class->find_field(XORS("_radius"))->offset();
                _offset = mono_class->find_field(XORS("_offset"))->offset();
            }
        };
    };
    struct ItemBarricadeAsset : public ItemAsset {
        auto _build() { return (EBuild::EBuild)read<WORD>((QWORD)this + offset::ItemBarricadeAsset::_build); }
        auto _health() { return read<DWORD>((QWORD)this + offset::ItemBarricadeAsset::_health); }
        auto _range() { return read<float>((QWORD)this + offset::ItemBarricadeAsset::_range); }
        auto _radius() { return read<float>((QWORD)this + offset::ItemBarricadeAsset::_radius); }
        auto _offset() { return read<float>((QWORD)this + offset::ItemBarricadeAsset::_offset); }

		auto _range(float val) { return write<float>((QWORD)this + offset::ItemBarricadeAsset::_range, val); }
		auto _radius(float val) { return write<float>((QWORD)this + offset::ItemBarricadeAsset::_radius, val); }
		auto _offset(float val) { return write<float>((QWORD)this + offset::ItemBarricadeAsset::_offset, val); }
    };
};
SDK::ItemBarricadeAsset* ItemBarricadeAsset = nullptr;