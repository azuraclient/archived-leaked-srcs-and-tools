#pragma once
#include "../unity.h"
#include "../mono.h"

#include "InteractableItem.h"

namespace SDK
{
    namespace offset {
        namespace ItemDrop {
            mono_class_t* mono_class;

            unsigned int _model;
            unsigned int _interactableItem;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemDrop"));
                if (!mono_class)
                    return;
                _model = mono_class->find_field(XORS("_model"))->offset();
                _interactableItem = mono_class->find_field(XORS("_interactableItem"))->offset();
            }
        };
    };
    struct ItemDrop {
        auto _model() { return read<unity::TransformPtr*>((QWORD)this + offset::ItemDrop::_model)->m_CachedPtr(); }
        auto _interactableItem() { return read<InteractableItem*>((QWORD)this + offset::ItemDrop::_interactableItem); }
    };
};
SDK::ItemDrop* ItemDrop = nullptr;