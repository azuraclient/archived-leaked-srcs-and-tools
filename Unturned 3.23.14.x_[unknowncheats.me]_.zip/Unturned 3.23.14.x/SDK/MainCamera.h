#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace MainCamera {
            mono_class_t* mono_class;

            unsigned int camera;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.MainCamera"));
                if (!mono_class)
                    return;
                camera = mono_class->find_field(XORS("camera"))->offset();
            }
        };
    };
    struct MainCamera {
        auto camera() { return read<unity::Camera*>((QWORD)this + offset::MainCamera::camera); }
    };
};
SDK::MainCamera* MainCamera = nullptr;