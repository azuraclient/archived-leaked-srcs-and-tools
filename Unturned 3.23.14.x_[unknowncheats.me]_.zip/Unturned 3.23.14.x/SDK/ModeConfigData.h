#pragma once
#include "../unity.h"
#include "../mono.h"

#include "GameplayConfigData.h"

namespace SDK
{
    namespace offset {
        namespace ModeConfigData {
            mono_class_t* mono_class;

            unsigned int Gameplay;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ModeConfigData"));
                if (!mono_class)
                    return;
                Gameplay = mono_class->find_field(XORS("Gameplay"))->offset();
            }
        };
    };
    struct ModeConfigData {
        auto Gameplay() { return read<GameplayConfigData*>((QWORD)this + offset::ModeConfigData::Gameplay); }
    };
};
SDK::ModeConfigData* ModeConfigData = nullptr;