#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace AnimalAsset {
            mono_class_t* mono_class;

            unsigned int _animalName;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.AnimalAsset"));
                if (!mono_class)
                    return;
                _animalName = mono_class->find_field(XORS("_animalName"))->offset();
            }
        };
    };
    struct AnimalAsset {
        auto _animalName() { return read<DWORD>((QWORD)this + offset::AnimalAsset::_animalName); }
    };
};
SDK::AnimalAsset* AnimalAsset = nullptr;