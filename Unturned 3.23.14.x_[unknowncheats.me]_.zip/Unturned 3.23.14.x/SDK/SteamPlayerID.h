#pragma once
namespace SDK
{
    namespace offset {
        namespace SteamPlayerID {
            mono_class_t* mono_class;

            unsigned int _playerName;
            unsigned int _characterName;
            unsigned int _nickName;
            unsigned int _steamID;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.SteamPlayerID"));
                if (!mono_class)
                    return;
                _playerName = mono_class->find_field(XORS("_playerName"))->offset();
                _characterName = mono_class->find_field(XORS("_characterName"))->offset();
                _nickName = mono_class->find_field(XORS("_nickName"))->offset();
                _steamID = mono_class->find_field(XORS("_steamID"))->offset();
            }
        };
    };
    struct SteamPlayerID {
        auto _playerName() { return read<unity::String*>((QWORD)this + offset::SteamPlayerID::_playerName)->string(); }
        auto _characterName() { return read<unity::String*>((QWORD)this + offset::SteamPlayerID::_characterName)->string(); }
        auto _nickName() { return read<unity::String*>((QWORD)this + offset::SteamPlayerID::_nickName)->string(); }
        auto _steamID() { return read<QWORD>((QWORD)this + offset::SteamPlayerID::_steamID); }
    };
};
SDK::SteamPlayerID* SteamPlayerID = nullptr;