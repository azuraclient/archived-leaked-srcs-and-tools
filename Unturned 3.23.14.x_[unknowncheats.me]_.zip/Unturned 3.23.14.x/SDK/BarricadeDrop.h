#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemBarricadeAsset.h"

namespace SDK
{
    namespace offset {
        namespace BarricadeDrop {
            mono_class_t* mono_class;

            unsigned int _model;
            unsigned int asset;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.BarricadeDrop"));
                if (!mono_class)
                    return;
                _model = mono_class->find_field(XORS("_model"))->offset();
                asset = mono_class->find_field(XORS("<asset>k__BackingField"))->offset();
            }
        };
    };
    struct BarricadeDrop {
        auto _model() { return read<unity::TransformPtr*>((QWORD)this + offset::BarricadeDrop::_model)->m_CachedPtr(); }
        auto asset() { return read<ItemBarricadeAsset*>((QWORD)this + offset::BarricadeDrop::asset); }
    };
};
SDK::BarricadeDrop* BarricadeDrop = nullptr;