#pragma once
#include "../unity.h"
#include "../mono.h"

#include "../SDK/InteractableVehicle.h"

namespace SDK
{
    namespace offset {
        namespace PlayerMovement {
            mono_class_t* mono_class;

            unsigned int _isSafe;
            unsigned int _isMoving;
            unsigned int _isGrounded;
            unsigned int lastUpdatePos;
            unsigned int snapshot;
            unsigned int vehicle;
            unsigned int velocity;
            unsigned int ground;
            unsigned int lastFootstep;
            unsigned int _move;

            Vec3 lastV;
            clock_t l_time;
            std::vector<Vec3> lastpoints;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerMovement"));
                if (!mono_class)
                    return;
                _isSafe = mono_class->find_field(XORS("_isSafe"))->offset();
                _isMoving = mono_class->find_field(XORS("_isMoving"))->offset();
                _isGrounded = mono_class->find_field(XORS("_isGrounded"))->offset();
                lastUpdatePos = mono_class->find_field(XORS("lastUpdatePos"))->offset();
                snapshot = mono_class->find_field(XORS("lastStatPos"))->offset();
                vehicle = mono_class->find_field(XORS("vehicle"))->offset();
                velocity = mono_class->find_field(XORS("velocity"))->offset();
                ground = mono_class->find_field(XORS("ground"))->offset();
                lastFootstep = mono_class->find_field(XORS("lastFootstep"))->offset();
                _move = mono_class->find_field(XORS("_move"))->offset();
            }
        };
    };
    struct PlayerMovement {
        auto _isSafe() { return read<DWORD>((QWORD)this + offset::PlayerMovement::_isSafe); }
        auto _isMoving() { return read<DWORD>((QWORD)this + offset::PlayerMovement::_isMoving); }
        auto _isGrounded() { return read<DWORD>((QWORD)this + offset::PlayerMovement::_isGrounded); }
        auto vehicle() { return read<SDK::InteractableVehicle*>((QWORD)this + offset::PlayerMovement::vehicle); }
        auto lastUpdatePos() { return read<Vec3>((QWORD)this + offset::PlayerMovement::lastUpdatePos); }
        auto velocity() { return read<Vec3>((QWORD)this + offset::PlayerMovement::velocity); }
        auto ground() { return read<Vec3>((QWORD)this + offset::PlayerMovement::ground); }
        auto lastFootstep() { return read<float>((QWORD)this + offset::PlayerMovement::lastFootstep); }
        auto _move() { return read<Vec3>((QWORD)this + offset::PlayerMovement::_move); }

        auto calcuate_velocity(unity::Transform* base, float sprint_mastery, float swim_mastery, SDK::EPlayerStance stance)
        { 
            Vec3 vector = (base->position() - lastUpdatePos()).normalized();
            auto car = vehicle();
            if (car)
            {
                vector = (car->center()->parent()->position() - car->lastUpdatedPos()).normalized();
                vector *= car->_physicsSpeed();
            }


            float num = 1.f + sprint_mastery * 0.25f;
            if (stance == SDK::EPlayerStance::SWIM)
                vector *= (3.f * (1.f + swim_mastery * 0.25f));
            else if (stance == SDK::EPlayerStance::CLIMB)
                vector *= (4.5f * num);
            else if (stance == SDK::EPlayerStance::SPRINT)
                vector *= (7.f * num);
            else if (stance == SDK::EPlayerStance::STAND)
                vector *= (3.f * num);
            else if (stance == SDK::EPlayerStance::CROUCH)
                vector *= (2.5f * num);
            else if (stance == SDK::EPlayerStance::PRONE)
                vector *= (1.5f * num);
            return vector;
            
        }
    };
};
SDK::PlayerMovement* PlayerMovement = nullptr;