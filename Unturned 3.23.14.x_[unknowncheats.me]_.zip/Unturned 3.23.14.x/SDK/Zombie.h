#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    enum EZombieSpeciality
    {
        NONE,
        NORMAL,
        MEGA,
        CRAWLER,
        SPRINTER,
        FLANKER_FRIENDLY,
        FLANKER_STALK,
        BURNER,
        ACID,
        BOSS_ELECTRIC,
        BOSS_WIND,
        BOSS_FIRE,
        BOSS_ALL,
        BOSS_MAGMA,
        SPIRIT,
        BOSS_SPIRIT,
        BOSS_NUCLEAR,
        DL_RED_VOLATILE,
        DL_BLUE_VOLATILE,
        BOSS_ELVER_STOMPER,
        BOSS_KUWAIT,
        BOSS_BUAK_ELECTRIC,
        BOSS_BUAK_WIND,
        BOSS_BUAK_FIRE,
        BOSS_BUAK_FINAL
    };
    namespace offset {
        namespace Zombie {
            mono_class_t* mono_class;

            unsigned int id;
            unsigned int target;
            unsigned int type;
            unsigned int speciality;
            unsigned int skeleton;
            unsigned int isDead;
            unsigned int isMega;
            unsigned int                 lastUpdatedPos = mono_class->find_field(XORS("lastUpdatedPos"))->offset();
            ;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Zombie"));
                if (!mono_class)
                    return;
                id = mono_class->find_field(XORS("id"))->offset();
                target = mono_class->find_field(XORS("target"))->offset();
                type = mono_class->find_field(XORS("type"))->offset();
                speciality = mono_class->find_field(XORS("speciality"))->offset();
                skeleton = mono_class->find_field(XORS("skeleton"))->offset();
                isDead = mono_class->find_field(XORS("isDead"))->offset();
                isMega = mono_class->find_field(XORS("isMega"))->offset();
                lastUpdatedPos = mono_class->find_field(XORS("lastUpdatedPos"))->offset();
            }
        };
    };
    struct Zombie {
        auto id() { return read<WORD>((QWORD)this + offset::Zombie::id); }
        auto target() { return read<unity::TransformPtr*>((QWORD)this + offset::Zombie::target)->m_CachedPtr(); }
        auto type() { return read<BYTE>((QWORD)this + offset::Zombie::type); }
        auto speciality() { return (EZombieSpeciality)read<BYTE>((QWORD)this + offset::Zombie::speciality); }
        auto skeleton() { return read<unity::TransformPtr*>((QWORD)this + offset::Zombie::skeleton)->m_CachedPtr(); }
        auto isDead() { return read<bool>((QWORD)this + offset::Zombie::isDead); }
        auto isMega() { return read<bool>((QWORD)this + offset::Zombie::isMega); }
        auto lastUpdatedPos() { return read<Vec3>((QWORD)this + offset::Zombie::lastUpdatedPos); }
    };
};
SDK::Zombie* Zombie = nullptr;