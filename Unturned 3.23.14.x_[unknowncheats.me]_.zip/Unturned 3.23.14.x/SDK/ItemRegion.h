#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemDrop.h"

namespace SDK
{
    namespace offset {
        namespace ItemRegion {
            mono_class_t* mono_class;

            unsigned int _drops;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemRegion"));
                if (!mono_class)
                    return;
                _drops = mono_class->find_field(XORS("_drops"))->offset();
            }
        };
    };
    struct ItemRegion {
        auto _drops() { return read<unity::List<ItemDrop*>*>((QWORD)this + offset::ItemRegion::_drops)->data(); }
    };
};
SDK::ItemRegion* ItemRegion = nullptr;