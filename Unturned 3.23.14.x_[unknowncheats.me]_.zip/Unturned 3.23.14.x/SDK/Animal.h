#pragma once
#include "../unity.h"
#include "../mono.h"

#include "AnimalAsset.h"

namespace SDK
{
    namespace offset {
        namespace Animal {
            mono_class_t* mono_class;

            unsigned int skeleton;
            unsigned int isDead;
            unsigned int health;
            unsigned int _asset;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Animal"));
                if (!mono_class)
                    return;
                skeleton = mono_class->find_field(XORS("skeleton"))->offset();
                isDead = mono_class->find_field(XORS("isDead"))->offset();
                health = mono_class->find_field(XORS("health"))->offset();
                _asset = mono_class->find_field(XORS("_asset"))->offset();
            }
        };
    };
    struct Animal {
        auto skeleton() { return read<unity::TransformPtr*>((QWORD)this + offset::Animal::skeleton)->m_CachedPtr(); }
        auto isDead() { return read<bool>((QWORD)this + offset::Animal::isDead); }
        auto health() { return read<WORD>((QWORD)this + offset::Animal::health); }
        auto _asset() { return read<AnimalAsset*>((QWORD)this + offset::Animal::_asset); }
    };
};
SDK::Animal* Animal = nullptr;