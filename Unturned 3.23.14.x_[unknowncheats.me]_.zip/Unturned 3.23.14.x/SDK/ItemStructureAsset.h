#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace EConstruct
    {
        enum EConstruct
        {
            FLOOR,
            WALL,
            RAMPART,
            ROOF,
            PILLAR,
            POST,
            FLOOR_POLY,
            ROOF_POLY
        };
    };
    namespace offset {
        namespace ItemStructureAsset {
            mono_class_t* mono_class;

            unsigned int _itemName;
            unsigned int _health;
            unsigned int _construct;
            unsigned int _range;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemStructureAsset"));
                if (!mono_class)
                    return;
                _itemName = mono_class->find_field(XORS("_itemName"))->offset();
                _health = mono_class->find_field(XORS("_health"))->offset();
                _construct = mono_class->find_field(XORS("_construct"))->offset();
                _range = mono_class->find_field(XORS("_range"))->offset();
            }
        };
    };
    struct ItemStructureAsset : public ItemAsset {
        auto _itemName() { return read<unity::String*>((QWORD)this + offset::ItemStructureAsset::_itemName)->string(); }
        auto _health() { return read<WORD>((QWORD)this + offset::ItemStructureAsset::_health); }
        auto _construct() { return (EConstruct::EConstruct)read<WORD>((QWORD)this + offset::ItemStructureAsset::_construct); }
        auto _range() { return read<float>((QWORD)this + offset::ItemStructureAsset::_range); }

        auto _range(float val) { return write<float>((QWORD)this + offset::ItemStructureAsset::_range, val); }
    };
};
SDK::ItemStructureAsset* ItemStructureAsset = nullptr;