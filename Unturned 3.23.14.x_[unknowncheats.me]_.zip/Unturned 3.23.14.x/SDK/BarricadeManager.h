#pragma once
#include "../unity.h"
#include "../mono.h"

#include "BarricadeRegion.h"

namespace SDK
{
    namespace offset {
        namespace BarricadeManager {
            mono_class_t* mono_class;

            unsigned int regions;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.BarricadeManager"));
                if (!mono_class)
                    return;
                regions = mono_class->find_field(XORS("<regions>k__BackingField"))->offset();
            }
        };
    };
    struct BarricadeManager {
        auto regions() { return read<unity::Array<BarricadeRegion*>*>((QWORD)this + offset::BarricadeManager::regions)->data(); }
    };
};
SDK::BarricadeManager* BarricadeManager = nullptr;