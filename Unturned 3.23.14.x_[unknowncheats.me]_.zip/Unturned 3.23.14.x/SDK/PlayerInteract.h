#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace PlayerInteract {
            mono_class_t* mono_class;

            unsigned int shouldOverrideSalvageTime;
            unsigned int overrideSalvageTimeValue;
            unsigned int interactableSalvageTime;
            unsigned int salvageTime;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerInteract"));
                if (!mono_class)
                    return;
                shouldOverrideSalvageTime = mono_class->find_field(XORS("shouldOverrideSalvageTime"))->offset();
                overrideSalvageTimeValue = mono_class->find_field(XORS("overrideSalvageTimeValue"))->offset();
                interactableSalvageTime = mono_class->find_field(XORS("interactableSalvageTime"))->offset();
                salvageTime = mono_class->find_field(XORS("salvageTime"))->offset();
            }
        };
    };
    struct PlayerInteract {
        auto shouldOverrideSalvageTime() { return read<DWORD>((QWORD)this + offset::PlayerInteract::shouldOverrideSalvageTime); }
        auto overrideSalvageTimeValue() { return read<DWORD>((QWORD)this + offset::PlayerInteract::overrideSalvageTimeValue); }
        auto interactableSalvageTime() { return read<DWORD>((QWORD)this + offset::PlayerInteract::interactableSalvageTime); }
        auto salvageTime() { return read<DWORD>((QWORD)this + offset::PlayerInteract::salvageTime); }
    };
};
SDK::PlayerInteract* PlayerInteract = nullptr;