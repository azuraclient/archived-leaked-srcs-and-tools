#pragma once
#include "../unity.h"
#include "../mono.h"

#include "PlayerStance.h"
#include "PlayerEquipment.h"
#include "PlayerLife.h"
#include "PlayerSkills.h"
#include "PlayerLook.h"
#include "PlayerAnimator.h"
#include "PlayerInteract.h"
#include "PlayerMovement.h"


namespace SDK
{
    namespace offset {
        namespace Player {
            mono_class_t* mono_class;

            unsigned int _equipment;
            unsigned int _life;
            unsigned int _skills;
            unsigned int _look;
            unsigned int _animator;
            unsigned int _interact;
            unsigned int _movement;
            unsigned int _stance;
            unsigned int onLocalPluginWidgetFlagsChanged;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Player"));
                if (!mono_class)
                    return;
                _equipment = mono_class->find_field(XORS("_equipment"))->offset();
                _life = mono_class->find_field(XORS("_life"))->offset();
                _skills = mono_class->find_field(XORS("_skills"))->offset();
                _look = mono_class->find_field(XORS("_look"))->offset();
                _animator = mono_class->find_field(XORS("_animator"))->offset();
                _interact = mono_class->find_field(XORS("_interact"))->offset();
                _movement = mono_class->find_field(XORS("_movement"))->offset();
                _stance = mono_class->find_field(XORS("_stance"))->offset();
                onLocalPluginWidgetFlagsChanged = mono_class->find_field(XORS("onLocalPluginWidgetFlagsChanged"))->offset();
            }
        };
    };
    struct Player {
        auto _equipment() { return read<PlayerEquipment*>((QWORD)this + offset::Player::_equipment); }
        auto _life() { return read<PlayerLife*>((QWORD)this + offset::Player::_life); }
        auto _skills() { return read<PlayerSkills*>((QWORD)this + offset::Player::_skills); }
        auto _look() { return read<PlayerLook*>((QWORD)this + offset::Player::_look); }
        auto _animator() { return read<PlayerAnimator*>((QWORD)this + offset::Player::_animator); }
        auto _interact() { return read<PlayerInteract*>((QWORD)this + offset::Player::_interact); }
        auto _movement() { return read<PlayerMovement*>((QWORD)this + offset::Player::_movement); }
        auto _stance() { return read<PlayerStance*>((QWORD)this + offset::Player::_stance); }
        auto _isLocal() { return read<QWORD>((QWORD)this + offset::Player::onLocalPluginWidgetFlagsChanged) > 0; }
    };
};
SDK::Player* Player = nullptr;