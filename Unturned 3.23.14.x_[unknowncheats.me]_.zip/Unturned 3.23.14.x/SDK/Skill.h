#pragma once
#include "../unity.h"
#include "../mono.h"

namespace SDK
{
    namespace offset {
        namespace Skill {
            mono_class_t* mono_class;

            unsigned int level;
            unsigned int max;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.Skill"));
                if (!mono_class)
                    return;
                level = mono_class->find_field(XORS("level"))->offset();
                max = mono_class->find_field(XORS("max"))->offset();
            }
        };
    };
    struct Skill {
        auto mastery() { return (float)read<BYTE>((QWORD)this + offset::Skill::level) / (float)read<BYTE>((QWORD)this + offset::Skill::max); }
    };
};
SDK::Skill* Skill = nullptr;