#pragma once
#include "../unity.h"
#include "../mono.h"

#include "SteamPlayerID.h"
#include "Player.h"

namespace SDK
{
    namespace offset {
        namespace SteamPlayer {
            mono_class_t* mono_class;

            unsigned int _model;
            unsigned int _playerID;
            unsigned int _player;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.SteamPlayer"));
                if (!mono_class)
                    return;
                _model = mono_class->find_field(XORS("_model"))->offset();
                _player = mono_class->find_field(XORS("_player"))->offset();
                _playerID = mono_class->find_field(XORS("_playerID"))->offset();
            }
        };
    };
    struct SteamPlayer {
        auto skeleton() { return read<unity::TransformPtr*>((QWORD)this + offset::SteamPlayer::_model)->m_CachedPtr()->child(0)->child(1); }
        auto _model() { return read<unity::TransformPtr*>((QWORD)this + offset::SteamPlayer::_model)->m_CachedPtr(); }
        auto _playerID() { return read<SteamPlayerID*>((QWORD)this + offset::SteamPlayer::_playerID); }
        auto _player() { return read<Player*>((QWORD)this + offset::SteamPlayer::_player); }
    };
};
SDK::SteamPlayer* SteamPlayer = nullptr;