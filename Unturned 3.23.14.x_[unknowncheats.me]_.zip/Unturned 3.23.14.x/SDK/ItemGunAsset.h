#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemAsset.h"

namespace SDK
{
    namespace offset {
        namespace ItemGunAsset {
            mono_class_t* mono_class;

            unsigned int ballisticSteps;
            unsigned int ballisticTravel;
            unsigned int muzzleVelocity;
            unsigned int bulletGravityMultiplier;
            unsigned int baseSpreadAngleRadians;
            unsigned int aimingRecoilMultiplier;
            unsigned int spreadAim;
            unsigned int aimInDuration;
            unsigned int canAimDuringSprint;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.ItemGunAsset"));
                if (!mono_class)
                    return;
                ballisticSteps = mono_class->find_field(XORS("ballisticSteps"))->offset();
                ballisticTravel = mono_class->find_field(XORS("ballisticTravel"))->offset();
                muzzleVelocity = mono_class->find_field(XORS("<muzzleVelocity>k__BackingField"))->offset();
                bulletGravityMultiplier = mono_class->find_field(XORS("<bulletGravityMultiplier>k__BackingField"))->offset();
                baseSpreadAngleRadians = mono_class->find_field(XORS("<baseSpreadAngleRadians>k__BackingField"))->offset();
                aimingRecoilMultiplier = mono_class->find_field(XORS("aimingRecoilMultiplier"))->offset();
                aimInDuration = mono_class->find_field(XORS("<aimInDuration>k__BackingField"))->offset();
                canAimDuringSprint = mono_class->find_field(XORS("<canAimDuringSprint>k__BackingField"))->offset();
            }
        };
    };
    struct ItemGunAsset : public ItemAsset {
        auto ballisticSteps() { return read<BYTE>((QWORD)this + offset::ItemGunAsset::ballisticSteps); }
        auto ballisticTravel() { return read<float>((QWORD)this + offset::ItemGunAsset::ballisticTravel); }
        auto muzzleVelocity() { return read<float>((QWORD)this + offset::ItemGunAsset::muzzleVelocity); }
        auto bulletGravityMultiplier() { return read<float>((QWORD)this + offset::ItemGunAsset::bulletGravityMultiplier); }
        auto baseSpreadAngleRadians() { return read<float>((QWORD)this + offset::ItemGunAsset::baseSpreadAngleRadians); }
        auto aimingRecoilMultiplier() { return read<float>((QWORD)this + offset::ItemGunAsset::aimingRecoilMultiplier); }
        auto spreadAim() { return read<float>((QWORD)this + offset::ItemGunAsset::spreadAim); }
        auto aimInDuration() { return read<float>((QWORD)this + offset::ItemGunAsset::aimInDuration); }
        auto canAimDuringSprint() { return read<bool>((QWORD)this + offset::ItemGunAsset::canAimDuringSprint); }

        bool baseSpreadAngleRadians(float val) { return write<float>((QWORD)this + offset::ItemGunAsset::baseSpreadAngleRadians, val); }
        bool aimingRecoilMultiplier(float val) { return write<float>((QWORD)this + offset::ItemGunAsset::aimingRecoilMultiplier, val); }
        bool spreadAim(float val) { return write<float>((QWORD)this + offset::ItemGunAsset::spreadAim, val); }
        bool aimInDuration(float val) { return write<float>((QWORD)this + offset::ItemGunAsset::aimInDuration, val); }
        bool canAimDuringSprint(bool val) { return write<bool>((QWORD)this + offset::ItemGunAsset::canAimDuringSprint, val); }
    };
};
SDK::ItemGunAsset* ItemGunAsset = nullptr;