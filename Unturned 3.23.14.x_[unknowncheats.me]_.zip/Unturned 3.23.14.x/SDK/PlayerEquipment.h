#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemWeaponAsset.h"
#include "ItemGunAsset.h"
#include "UseableGun.h"

namespace SDK
{
    namespace offset {
        namespace PlayerEquipment {
            mono_class_t* mono_class;

            unsigned int _asset;
            unsigned int _useable;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.PlayerEquipment"));
                if (!mono_class)
                    return;
                _asset = mono_class->find_field(XORS("_asset"))->offset();
                _useable = mono_class->find_field(XORS("_useable"))->offset();
            }
        };
    };
    struct PlayerEquipment {
        auto _asset() { return read<SDK::ItemAsset*>((QWORD)this + offset::PlayerEquipment::_asset); }
        auto _useable() { return read<SDK::UseableGun*>((QWORD)this + offset::PlayerEquipment::_useable); }
    };
};
SDK::PlayerEquipment* PlayerEquipment = nullptr;