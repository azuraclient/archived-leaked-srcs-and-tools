#pragma once
#include "../unity.h"
#include "../mono.h"

#include "VehicleAsset.h"

namespace SDK
{
    namespace offset {
        namespace InteractableVehicle {
            mono_class_t* mono_class;

            unsigned int id;
            unsigned int batteryCharge;
            unsigned int center;
            unsigned int health;
            unsigned int fuel;
            unsigned int _asset;
            unsigned int lastUpdatedPos;
            unsigned int real;
            unsigned int _physicsSpeed;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.InteractableVehicle"));
                if (!mono_class)
                    return;
                id = mono_class->find_field(XORS("id"))->offset();
                batteryCharge = mono_class->find_field(XORS("batteryCharge"))->offset();
                center = mono_class->find_field(XORS("center"))->offset();
                health = mono_class->find_field(XORS("health"))->offset();
                fuel = mono_class->find_field(XORS("fuel"))->offset();
                _asset = mono_class->find_field(XORS("_asset"))->offset();
                lastUpdatedPos = mono_class->find_field(XORS("lastUpdatedPos"))->offset();
                real = mono_class->find_field(XORS("real"))->offset();
                _physicsSpeed = mono_class->find_field(XORS("_physicsSpeed"))->offset();
            }
        };
    };
    struct InteractableVehicle {
        auto id() { return read<WORD>((QWORD)this + offset::InteractableVehicle::id); }
        auto batteryCharge() { return read<WORD>((QWORD)this + offset::InteractableVehicle::batteryCharge); }
        auto center() { return read<unity::TransformPtr*>((QWORD)this + offset::InteractableVehicle::center)->m_CachedPtr(); }
        auto health() { return read<WORD>((QWORD)this + offset::InteractableVehicle::health); }
        auto fuel() { return read<WORD>((QWORD)this + offset::InteractableVehicle::fuel); }
        auto _asset() { return read<VehicleAsset*>((QWORD)this + offset::InteractableVehicle::_asset); }
        auto lastUpdatedPos() { return read<Vec3>((QWORD)this + offset::InteractableVehicle::lastUpdatedPos); }
        auto _physicsSpeed() { return read<float>((QWORD)this + offset::InteractableVehicle::_physicsSpeed); }
    };
};
SDK::InteractableVehicle* InteractableVehicle = nullptr;