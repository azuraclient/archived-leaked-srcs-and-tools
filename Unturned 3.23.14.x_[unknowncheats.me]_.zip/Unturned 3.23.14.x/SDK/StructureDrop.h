#pragma once
#include "../unity.h"
#include "../mono.h"

#include "ItemStructureAsset.h"

namespace SDK
{
    namespace offset {
        namespace StructureDrop {
            mono_class_t* mono_class;

            unsigned int _model;
            unsigned int asset;

            void define_feilds()
            {
                mono_class = mono::find_class(XORS("Assembly-CSharp"), XORS("SDG.Unturned.StructureDrop"));
                if (!mono_class)
                    return;
                _model = mono_class->find_field(XORS("_model"))->offset();
                asset = mono_class->find_field(XORS("asset"))->offset();
            }
        };
    };
    struct StructureDrop {
        auto _model() { return read<unity::TransformPtr*>((QWORD)this + offset::StructureDrop::_model)->m_CachedPtr(); }
        auto asset() { return read<ItemStructureAsset*>((QWORD)this + offset::StructureDrop::asset); }
    };
};
SDK::StructureDrop* StructureDrop = nullptr;