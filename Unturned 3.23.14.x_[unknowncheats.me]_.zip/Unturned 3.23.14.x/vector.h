#pragma once
#pragma warning(disable : 4305)
#include <math.h>

class Vector4
{
private:
#define Operator4A(op)	Vector4 operator op	(const  Vector4& data) { return { x op data.x			, y op data.y		, z op data.z		, w op data.w		 };}
#define Operator4B(op)	Vector4 operator op= (const Vector4& data) { return { x op= data.x			, y op= data.y		, z op= data.z		, w op= data.w		 };}
#define OperatorPow4A	Vector4 operator ^	(const  Vector4& data) { return { powf(x, data.x)		, powf(y, data.y)	, powf(z, data.z)	, powf(w, data.w)	 };}
#define OperatorPow4B	Vector4 operator ^=	(const  Vector4& data) { return { x = powf(x, data.x)	, y = powf(y, data.y), z = powf(z, data.z), w = powf(w, data.w) };}
#define VecDef4(op) Operator4A(op) Operator4B(op)
#define VecDefPow4 OperatorPow4A OperatorPow4B
#define logic4(op1, op2) bool operator op1 (const Vector4& data) { return (x op1 data.x op2 y op1 data.y op2 z op1 data.z op2 w op1 data.w);}
public:
	float x = 0.f, y = 0.f, z = 0.f, w = 0.f;
	Vector4() {}
	template <class T1>
	Vector4(T1 x) : x(static_cast<float>(x)), y(static_cast<float>(x)), z(static_cast<float>(x)), w(static_cast<float>(x)) {}
	template <class T1, class T2, class T3, class T4>
	Vector4(T1 x, T2 y, T3 z, T4 w) : x(static_cast<float>(x)), y(static_cast<float>(y)), z(static_cast<float>(z)), w(static_cast<float>(w)) {}
	Operator4A(= );
	VecDef4(+);
	VecDef4(-);
	VecDef4(*);
	VecDef4(/ );
	VecDefPow4;
	logic4(< , &&);
	logic4(> , &&);
	logic4(<= , &&);
	logic4(>= , &&);
	logic4(!= , || );
	logic4(== , &&);
	float sum() { return x + y + z + w; }
	float dot(Vector4 data) { return (*this * data).sum(); }
	float distance(Vector4 data) { return sqrtf(((*this - data) ^ 2).sum()); }
};

class Vector3
{
private:
#define Operator3A(op)	Vector3 operator op	(const  Vector3& data) { return { x op data.x			, y op data.y		, z op data.z		};}
#define Operator3B(op)	Vector3 operator op= (const Vector3& data) { return { x op= data.x			, y op= data.y		, z op= data.z		};}
#define OperatorPow3A	Vector3 operator ^	(const  Vector3& data) { return { powf(x, data.x)		, powf(y, data.y)	, powf(z, data.z)	};}
#define OperatorPow3B	Vector3 operator ^=	(const  Vector3& data) { return { x = powf(x, data.x)	, y = powf(y, data.y), z = powf(z, data.z)};}
#define VecDef3(op) Operator3A(op) Operator3B(op)
#define VecDefPow3 OperatorPow3A OperatorPow3B
#define logic3(op1, op2) bool operator op1 (const Vector3& data) { return (x op1 data.x op2 y op1 data.y op2 z op1 data.z);}
public:
	float x = 0.f, y = 0.f, z = 0.f;
	Vector3() {}
	template <class T1>
	Vector3(T1 x) : x(static_cast<float>(x)), y(static_cast<float>(x)), z(static_cast<float>(x)) {}
	template <class T1, class T2, class T3>
	Vector3(T1 x, T2 y, T3 z) : x(static_cast<float>(x)), y(static_cast<float>(y)), z(static_cast<float>(z)) {}
	Operator3A(= );
	VecDef3(+);
	VecDef3(-);
	VecDef3(*);
	VecDef3(/ );
	VecDefPow3;
	logic3(< , &&);
	logic3(> , &&);
	logic3(<= , &&);
	logic3(>= , &&);
	logic3(!= , || );
	logic3(== , &&);
	float sum() { return x + y + z; }
	float sub() { return x - y - z; }
	float dot(Vector3 data) { return (*this * data).sum(); }
	float distance(Vector3 data) { return sqrtf(((*this - data) ^ 2).sum()); }
	float distanceFlat(Vector3 data) { return sqrtf(((Vector3(x, 0, z) - Vector3(data.x, 0, data.z)) ^ 2).sum()); }
	Vector3 cross(Vector3 data) {
		return Vector3(
			y * data.z - z * data.y,
			z * data.x - x * data.z,
			x * data.y - y * data.x
		);
	}
	Vector3 normalized() {
		float length = sqrtf(x * x + y * y + z * z);
		if (length != 0) {
			x /= length;
			y /= length;
			z /= length;
		}
		return *this;
	}

	static Vector3 rotatex(Vector3 origin, Vector3 points, float angle) {
		points -= origin;
		float temp = points.y;
		points.y = points.y * cosf(angle) - points.z * sinf(angle);
		points.z = temp * sinf(angle) + points.z * cosf(angle);
		return points + origin;
	}
	static Vector3 rotatey(Vector3 origin, Vector3 points, float angle) {
		points -= origin;
		float temp = points.z;
		points.z = points.z * cosf(angle) - points.x * sinf(angle);
		points.x = temp * sinf(angle) + points.x * cosf(angle);
		return points + origin;
	}
	static Vector3 rotatez(Vector3 origin, Vector3 points, float angle) {
		points -= origin;
		angle = angle * 3.14159f / 180.0f;
		float temp = points.x;
		points.x = points.x * cosf(angle) - points.y * sinf(angle);
		points.y = temp * sinf(angle) + points.y * cosf(angle);
		return points + origin;
	}
};

class Vector2
{
private:
#define OperatorA(op)	Vector2 operator op	(const  Vector2& data) { return { x op data.x			, y op data.y		};}
#define OperatorB(op)	Vector2 operator op= (const Vector2& data) { return { x op= data.x			, y op= data.y		};}
#define OperatorPowA	Vector2 operator ^	(const  Vector2& data) { return { powf(x, data.x)		, powf(y, data.y)	};}
#define OperatorPowB	Vector2 operator ^=	(const  Vector2& data) { return { x = powf(x, data.x)	, y = powf(y, data.y)};}
#define VecDef(op) OperatorA(op) OperatorB(op)
#define VecDefPow OperatorPowA OperatorPowB
#define logic(op1, op2) bool operator op1 (const Vector2& data) { return ( x op1 data.x op2 y op1 data.y);}
	float _findMidpoint(float angle1, float angle2, float percent) {

		angle1 = fmodf(angle1, 2.f * 3.14159265359f);
		angle2 = fmodf(angle2, 2.f * 3.14159265359f);

		float diff = angle2 - angle1;

		if (diff > 3.14159265359f) {
			diff -= 2 * 3.14159265359f;
		}
		else if (diff < -3.14159265359f) {
			diff += 2 * 3.14159265359f;
		}

		float midpoint = angle1 + percent * diff;

		if (midpoint < 0) {
			midpoint += 2 * 3.14159265359f;
		}
		else if (midpoint >= 2 * 3.14159265359f) {
			midpoint -= 2 * 3.14159265359f;
		}

		if (midpoint > 2.f * 3.14159265359f - 1e-10f) {
			midpoint = 0.0f;
		}
		return midpoint;
	}
	float _calculateCircularDistance(float angle1, float angle2) {
		// Ensure both angles are between 0 and 2*pi
		angle1 = fmodf(angle1, 2 * 3.14159265359f);
		angle2 = fmodf(angle2, 2 * 3.14159265359f);

		// Calculate the absolute angular difference
		float angularDifference = fabsf(angle1 - angle2);

		// Ensure the angular difference is between 0 and pi
		if (angularDifference > 3.14159265359f) {
			angularDifference = 2 * 3.14159265359f - angularDifference;
		}
		while (angularDifference < 0)
		{
			angularDifference += 2 * 3.14159265359f;
		}

		return angularDifference;
	}
public:
	float x = 0.f, y = 0.f;
	Vector2() {}

	template <class T1>
	Vector2(T1 x) : x(static_cast<float>(x)), y(static_cast<float>(x)) {}
	template <>
	Vector2(POINT data) : x(static_cast<float>(data.x)), y(static_cast<float>(data.y)) {}
	template <class T1, class T2>
	Vector2(T1 x, T2 y) : x(static_cast<float>(x)), y(static_cast<float>(y)) {}
	OperatorA(= );
	VecDef(+);
	VecDef(-);
	VecDef(*);
	VecDef(/ );
	VecDefPow;
	logic(< , &&);
	logic(> , &&);
	logic(<= , &&);
	logic(>= , &&);
	logic(!= , || );
	logic(== , &&);
	float sum() { return x + y; }
	float sub() { return x - y; }
	float dot(Vector2 data) { return (*this * data).sum(); }
	float distance(Vector2 data) { return sqrtf(((*this - data) ^ 2).sum()); }
	Vector2 findMidPoint(Vector2 to, float step) {

		while (y < 0)
			y += 2.0f * 3.14159265f;
		while (y > 2.0f * 3.14159265f)
			y -= 2.0f * 3.14159265f;
		while (to.y < 0)
			to.y += 2.0f * 3.14159265f;
		while (to.y > 2.0f * 3.14159265f)
			to.y -= 2.0f * 3.14159265f;

		while (x < 0)
			x += 2.0f * 3.14159265f;
		while (x > 2.0f * 3.14159265f)
			x -= 2.0f * 3.14159265f;
		while (to.x < 0)
			to.x += 2.0f * 3.14159265f;
		while (to.x > 2.0f * 3.14159265f)
			to.x -= 2.0f * 3.14159265f;

		float deltaX = to.x - x;
		float deltaY = to.y - y;

		if (deltaX > 3.14159265359f) {
			deltaX -= 2 * 3.14159265359f;
		}else if (deltaX < -3.14159265359f) {
			deltaX += 2 * 3.14159265359f;
		}if (deltaY > 3.14159265359f) {
			deltaY -= 2 * 3.14159265359f;
		}
		else if (deltaY < -3.14159265359f) {
			deltaY += 2 * 3.14159265359f;
		}

		float magnitude = sqrtf(deltaX * deltaX + deltaY * deltaY);

		if (magnitude < step) {
			return *this;
		}

		float ratio = step / magnitude;
		Vector2 midPoint;
		midPoint.x = x + ratio * deltaX;
		midPoint.y = y + ratio * deltaY;

		if (midPoint.x < 0.0f) {
			midPoint.x += 2 * 3.14159265359f;
		}else if (midPoint.x >= 2 * 3.14159265359f) {
			midPoint.x -= 2 * 3.14159265359f;
		}if (midPoint.y < 0.0f) {
			midPoint.y += 2 * 3.14159265359f;
		}else if (midPoint.y >= 2 * 3.14159265359f) {
			midPoint.y -= 2 * 3.14159265359f;
		}

		while (midPoint.y < 0)
			midPoint.y += 2.0f * 3.14159265f;
		while (midPoint.y > 2.0f * 3.14159265f)
			midPoint.y -= 2.0f * 3.14159265f;

		while (midPoint.x < 0)
			midPoint.x += 2.0f * 3.14159265f;
		while (midPoint.x > 2.0f * 3.14159265f)
			midPoint.x -= 2.0f * 3.14159265f;
		return midPoint;
	}
};

typedef Vector2 Vec2;
typedef Vector3 Vec3;
typedef Vector4 Vec4;
