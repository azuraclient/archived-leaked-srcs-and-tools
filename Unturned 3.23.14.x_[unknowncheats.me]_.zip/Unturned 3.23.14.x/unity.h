#pragma once
#include <emmintrin.h>
#include <windows.h>

#include "vector.h"
#include "memory.h"



class unity
{
private:
    struct TransformAccessReadOnly {
        QWORD pTransformData;
        int index;
    };
    struct TransformData {
        QWORD pTransformArray;
        QWORD pTransformIndices;
    };
    struct Matrix34 {
        Vec4 vec0, vec1, vec2;
    };
public:

    class Quaternion {
    public:
        float x = 0.f, y = 0.f, z = 0.f, w = 0.f;

        Quaternion(float _w = 1.0f, float _x = 0.0f, float _y = 0.0f, float _z = 0.0f)
            : w(_w), x(_x), y(_y), z(_z) {}
        

        void normalize() {
            float length = std::sqrt(w * w + x * x + y * y + z * z);
            if (length != 0) {
                w /= length;
                x /= length;
                y /= length;
                z /= length;
            }
        }

        Quaternion conjugate() const {
            return Quaternion(w, -x, -y, -z);
        }

        bool operator==(Quaternion data) { return (x == data.x && y == data.y && z == data.z && w == data.w); }
        bool operator!=(Quaternion data) { return (x != data.x || y != data.y || z != data.z || w != data.w); }

        Quaternion operator*(Vec3 data) {
            Quaternion other = { 1, data.x, data.y, data.z };
            return Quaternion(
                w * other.w - x * other.x - y * other.y - z * other.z,
                w * other.x + x * other.w + y * other.z - z * other.y,
                w * other.y - x * other.z + y * other.w + z * other.x,
                w * other.z + x * other.y - y * other.x + z * other.w
            );
        }

        Quaternion operator*(const Quaternion& other) const {
            return Quaternion(
                w * other.w - x * other.x - y * other.y - z * other.z,
                w * other.x + x * other.w + y * other.z - z * other.y,
                w * other.y - x * other.z + y * other.w + z * other.x,
                w * other.z + x * other.y - y * other.x + z * other.w
            );
        }

        Quaternion operator*(float data) const {
            return Quaternion(
                x * data,
                y * data,
                z * data,
                w * data
            );
        }
        Vec3 toEulerAngles() {
            float qx = w;
            float qy = y;
            float qz = z;
            float qw = x;

            // Calculate Euler angles
            float roll = atan2f(2.0f * (qw * qx + qy * qz), 1.0f - 2.0f * (qx * qx + qy * qy));
            float pitch = asinf(2.0f * (qw * qy - qz * qx));
            float yaw = atan2f(2.0f * (qw * qz + qx * qy), 1.0f - 2.0f * (qy * qy + qz * qz));

            roll -= 3.14159f;

            yaw = fmod(yaw, 2.f * 3.14159f);
            if (yaw < 0.0f)
                yaw += 2.f * 3.14159f;

            return Vec3(roll, pitch, yaw);
        }
    };

    struct Matrix {
        Vec4 right, up, forward, translation;
    };
    struct String {
        auto string() {
            auto str_len = read<DWORD>((QWORD)this + 0x10);
            auto str = (PBYTE)malloc(str_len * 0x2);
            if (str)
            {
                read((QWORD)this + 0x14, str, str_len * 0x2);
                std::wstring results = std::wstring((const wchar_t*)str);
                results.resize(str_len);
                free(str);
                return results;
            }
            return std::wstring(XORS(L"NULL"));
        }
    };
    template <class TYPE>
    struct List {
        auto data() { 
            std::vector<TYPE> results; results.resize(0); 
            results.resize(read<int>((QWORD)this + 0x18)); 
            if (results.size()) { 
                read(read<QWORD>((QWORD)this + 0x10) + 0x20, (PBYTE)&results.at(0), (DWORD)results.size() * sizeof(TYPE)); 
            } 
            return results; 
        }
    };
    template <class TYPE>
    struct Array {
        auto data() { 
            std::vector<TYPE> results;
            if (!(QWORD)this)
                return results;
            results.resize(read<int>((QWORD)this + 0x18)); 
            read((QWORD)this + 0x20, (PBYTE)&results.at(0), (DWORD)results.size() * sizeof(TYPE));
            return results; 
        }
    };
    struct Transform {
        
        auto root_rotation() {
            if (!(QWORD)this)
                return Quaternion();
            return read<Quaternion>({ (QWORD)this + 0x38, 0x18, 0x10 });
        }

        auto root_position() {
            if (!(QWORD)this)
                return Vector3();
            auto o_root = read<QWORD>({ (QWORD)this + 0x38, 0x18 });
            return read<Vector3>(o_root);
        }

        auto root_scaling() {
            if (!(QWORD)this)
                return Vector3();
            return read<Vector3>({ (QWORD)this + 0x38, 0x18, 0x20 });
        }
        
        auto rotation(int index = 0)
        {
            if (!(QWORD)this)
                return Quaternion();
            __m128i result = { 0 };
            const __m128 mulVec0 = { -0.00, -0.00, -0.00, -0.00 };
            const __m128 mulVec1 = { -1.00, -1.00, -1.00, 0.000 };
            const __m128 mulVec2 = { 0.000, 0.000, 0.000, 0.000 };
            const __m128 mulVec3 = { 1.000, 1.000, 1.000, 1.000 };

            TransformAccessReadOnly pTransformAccessReadOnly = read<TransformAccessReadOnly>((QWORD)this + 0x38);
            if (!pTransformAccessReadOnly.pTransformData)
                return Quaternion();
            TransformData transformData = read<TransformData>((QWORD)pTransformAccessReadOnly.pTransformData + 0x18);

            if (!transformData.pTransformArray)
                return Quaternion();
            SIZE_T sizeMatriciesBuf = sizeof(Matrix34) * pTransformAccessReadOnly.index + sizeof(Matrix34);
            SIZE_T sizeIndicesBuf = sizeof(int) * pTransformAccessReadOnly.index + sizeof(int);

            PVOID pMatriciesBuf = malloc(sizeMatriciesBuf);
            PVOID pIndicesBuf = malloc(sizeIndicesBuf);
            if (pMatriciesBuf && pIndicesBuf)
            {
                memset(pMatriciesBuf, 0, sizeMatriciesBuf);
                memset(pIndicesBuf, 0, sizeIndicesBuf);
                if (pMatriciesBuf && pIndicesBuf)
                {
                    if (!read((QWORD)transformData.pTransformArray, (PBYTE)pMatriciesBuf, (DWORD)sizeMatriciesBuf))
                    {
                        free(pMatriciesBuf);
                        free(pIndicesBuf);
                        return Quaternion();
                    }
                    if (!read((QWORD)transformData.pTransformIndices, (PBYTE)pIndicesBuf, (DWORD)sizeIndicesBuf))
                    {
                        free(pMatriciesBuf);
                        free(pIndicesBuf);
                        return Quaternion();
                    }

                    result = *(__m128i*)((QWORD)pMatriciesBuf + 0x30 * pTransformAccessReadOnly.index);
                    int transformIndex = *(int*)((QWORD)pIndicesBuf + 0x4 * pTransformAccessReadOnly.index) + index;
                    
                    auto v11 = _mm_and_ps(_mm_castsi128_ps(_mm_shuffle_epi32(_mm_setzero_si128(), 0)), mulVec2);

                    while (transformIndex >= 0)
                    {
                        if (0x30 * transformIndex >= sizeMatriciesBuf)
                        {
                            free(pMatriciesBuf);
                            free(pIndicesBuf);
                            return Quaternion();
                        }
                        if (0x4 * transformIndex >= sizeIndicesBuf)
                        {
                            free(pMatriciesBuf);
                            free(pIndicesBuf);
                            return Quaternion();
                        }
                        
                        Matrix34 v6 = *(Matrix34*)(uintptr_t(pMatriciesBuf) + 0x30 * transformIndex);

                        auto q = *(__m128i*)(uintptr_t(&v6) + 0x10);
                        auto v15 = *(__m128i*)(uintptr_t(&v6) + 0x20);
                        //#define __m128_cast(x) _mm_castsi128_ps(x)
                        //#define __m128i_cast(x) _mm_castps_si128(x)

                        auto v16 = _mm_xor_si128(_mm_and_si128(v15, _mm_castps_si128(mulVec0)), _mm_castps_si128(mulVec3));
                        auto v17 = _mm_xor_si128(
                            _mm_and_si128(
                                _mm_castps_si128(mulVec0),
                                _mm_castps_si128(_mm_or_ps(
                                    _mm_andnot_ps(
                                        mulVec2,
                                        _mm_mul_ps(_mm_castsi128_ps(_mm_shuffle_epi32(v16, 65)), _mm_castsi128_ps(_mm_shuffle_epi32(v16, 154)))),
                                    v11))),
                            result);
                        result = _mm_xor_si128(
                            _mm_and_si128(_mm_castps_si128(mulVec1), _mm_castps_si128(mulVec0)),
                            _mm_shuffle_epi32(
                                _mm_castps_si128(_mm_sub_ps(
                                    _mm_sub_ps(
                                        _mm_sub_ps(
                                            _mm_mul_ps(_mm_castsi128_ps(q), _mm_castsi128_ps(_mm_shuffle_epi32(v17, 210))),
                                            _mm_castsi128_ps(_mm_shuffle_epi32(
                                                _mm_castps_si128(_mm_mul_ps(_mm_castsi128_ps(q), _mm_castsi128_ps(_mm_shuffle_epi32(v17, 136)))),
                                                30))),
                                        _mm_castsi128_ps(_mm_shuffle_epi32(
                                            _mm_castps_si128(_mm_mul_ps(_mm_castsi128_ps(_mm_shuffle_epi32(q, 175)), _mm_castsi128_ps(v17))),
                                            141))),
                                    _mm_castsi128_ps(_mm_shuffle_epi32(
                                        _mm_castps_si128(_mm_mul_ps(
                                            _mm_movelh_ps(_mm_castsi128_ps(q), _mm_castsi128_ps(q)),
                                            _mm_castsi128_ps(_mm_shuffle_epi32(v17, 245)))),
                                        99)))),
                                210));

                        if (sizeIndicesBuf < (0x4 * (transformIndex + 1)))
                        {
                            free(pMatriciesBuf);
                            free(pIndicesBuf);
                            return Quaternion();
                        }

                        transformIndex = *(int*)(uintptr_t(pIndicesBuf) + 0x4 * transformIndex);
                    }
                    free(pMatriciesBuf);
                    free(pIndicesBuf);
                }
            }
            const auto fl_res = _mm_castsi128_ps(result);
            return Quaternion(fl_res.m128_f32[0], fl_res.m128_f32[1], fl_res.m128_f32[2], fl_res.m128_f32[3]);
        }
        
        auto position(int index = 0)
        {
            if (!(QWORD)this)
                return Vec3();
            __m128 result = { 0 };
            const __m128 mulVec0 = { -2.00, 2.000, -2.00, 0.000 };
            const __m128 mulVec1 = { 2.000, -2.00, -2.00, 0.000 };
            const __m128 mulVec2 = { -2.00, -2.00, 2.000, 0.000 };

            TransformAccessReadOnly pTransformAccessReadOnly = read<TransformAccessReadOnly>((QWORD)this + 0x38);
            if (!pTransformAccessReadOnly.pTransformData)
                return Vec3();
            TransformData transformData = read<TransformData>((QWORD)pTransformAccessReadOnly.pTransformData + 0x18);

            if (!transformData.pTransformArray)
                return Vec3();
            SIZE_T sizeMatriciesBuf = sizeof(Matrix34) * pTransformAccessReadOnly.index + sizeof(Matrix34);
            SIZE_T sizeIndicesBuf = sizeof(int) * pTransformAccessReadOnly.index + sizeof(int);

            PVOID pMatriciesBuf = malloc(sizeMatriciesBuf);
            PVOID pIndicesBuf = malloc(sizeIndicesBuf);
            if (pMatriciesBuf && pIndicesBuf)
            {
                memset(pMatriciesBuf, 0, sizeMatriciesBuf);
                memset(pIndicesBuf, 0, sizeIndicesBuf);
                if (pMatriciesBuf && pIndicesBuf)
                {
                    if (!read((QWORD)transformData.pTransformArray, (PBYTE)pMatriciesBuf, (DWORD)sizeMatriciesBuf))
                    {
                        free(pMatriciesBuf);
                        free(pIndicesBuf);
                        return Vec3();
                    }
                    if (!read((QWORD)transformData.pTransformIndices, (PBYTE)pIndicesBuf, (DWORD)sizeIndicesBuf))
                    {
                        free(pMatriciesBuf);
                        free(pIndicesBuf);
                        return Vec3();
                    }

                    result = *(__m128*)((QWORD)pMatriciesBuf + 0x30 * pTransformAccessReadOnly.index);
                    int transformIndex = *(int*)((QWORD)pIndicesBuf + 0x4 * pTransformAccessReadOnly.index) + index;

                    while (transformIndex >= 0)
                    {
                        if (0x30 * transformIndex >= sizeMatriciesBuf)
                        {
                            free(pMatriciesBuf);
                            free(pIndicesBuf);
                            return Vec3();
                        }
                        if (0x4 * transformIndex >= sizeIndicesBuf)
                        {
                            free(pMatriciesBuf);
                            free(pIndicesBuf);
                            return Vec3();
                        }

                        Matrix34 matrix34 = *(Matrix34*)((QWORD)pMatriciesBuf + 0x30 * transformIndex);
                        __m128 xxxx = _mm_castsi128_ps(_mm_shuffle_epi32(*(__m128i*)(&matrix34.vec1), 0x00));
                        __m128 yyyy = _mm_castsi128_ps(_mm_shuffle_epi32(*(__m128i*)(&matrix34.vec1), 0x55));
                        __m128 zwxy = _mm_castsi128_ps(_mm_shuffle_epi32(*(__m128i*)(&matrix34.vec1), 0x8E));
                        __m128 wzyw = _mm_castsi128_ps(_mm_shuffle_epi32(*(__m128i*)(&matrix34.vec1), 0xDB));
                        __m128 zzzz = _mm_castsi128_ps(_mm_shuffle_epi32(*(__m128i*)(&matrix34.vec1), 0xAA));
                        __m128 yxwy = _mm_castsi128_ps(_mm_shuffle_epi32(*(__m128i*)(&matrix34.vec1), 0x71));
                        __m128 tmp7 = _mm_mul_ps(*(__m128*)(&matrix34.vec2), result);

                        result = _mm_add_ps(
                            _mm_add_ps(
                                _mm_add_ps(
                                    _mm_mul_ps(
                                        _mm_sub_ps(
                                            _mm_mul_ps(_mm_mul_ps(xxxx, mulVec1), zwxy),
                                            _mm_mul_ps(_mm_mul_ps(yyyy, mulVec2), wzyw)),
                                        _mm_castsi128_ps(_mm_shuffle_epi32(_mm_castps_si128(tmp7), 0xAA))),
                                    _mm_mul_ps(
                                        _mm_sub_ps(
                                            _mm_mul_ps(_mm_mul_ps(zzzz, mulVec2), wzyw),
                                            _mm_mul_ps(_mm_mul_ps(xxxx, mulVec0), yxwy)),
                                        _mm_castsi128_ps(_mm_shuffle_epi32(_mm_castps_si128(tmp7), 0x55)))),
                                _mm_add_ps(
                                    _mm_mul_ps(
                                        _mm_sub_ps(
                                            _mm_mul_ps(_mm_mul_ps(yyyy, mulVec0), yxwy),
                                            _mm_mul_ps(_mm_mul_ps(zzzz, mulVec1), zwxy)),
                                        _mm_castsi128_ps(_mm_shuffle_epi32(_mm_castps_si128(tmp7), 0x00))),
                                    tmp7)), *(__m128*)(&matrix34.vec0));
                        transformIndex = *(int*)((QWORD)pIndicesBuf + 0x4 * transformIndex);
                    }
                    free(pMatriciesBuf);
                    free(pIndicesBuf);
                }
            }
            return Vec3(result.m128_f32[0], result.m128_f32[1], result.m128_f32[2]);
        }
        
        auto name() {
            if (!(QWORD)this)
                return std::string();
            QWORD addr = read<QWORD>({ (QWORD)this + 0x30, 0x60 });
            return read<std::string>(addr);
        }

        auto parent() { 
            if (!(QWORD)this) 
                return (Transform*)nullptr;
            return read<Transform*>((QWORD)this + 0x90);
        }

        auto child(int index = 0) { 
            if (!(QWORD)this)
                return (Transform*)nullptr;
            return read<Transform*>({ (QWORD)this + 0x70, (QWORD)index * 0x8 }); 
        }

        auto child(const char* symbol) {
            for (int i = 0; i < 0xFF; i++)
            {
                auto results = ((Transform*)this)->child(i);
                auto txt = results->name();
                if (!txt.size())
                    break;
                else if (txt._Equal(symbol))
                    return results;
            }
            return (Transform*)nullptr;
        }
    };
    struct TransformPtr {
        auto m_CachedPtr() { return read<Transform*>((QWORD)this + 0x10); }
    };

    struct Camera {
        auto _isActive() { return read<bool>({ (QWORD)this + 0x10, 0x38 }); }
        auto Matrix() { return read<unity::Matrix>({ (QWORD)this + 0x10, 0xDC }); }
        auto position() { return read<Vector3>({ (QWORD)this + 0x10, 0x42C }); }
    };
};