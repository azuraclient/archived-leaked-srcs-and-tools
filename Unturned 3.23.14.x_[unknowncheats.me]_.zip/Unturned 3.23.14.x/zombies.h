#pragma once
#define clamp(data, min, max)if (data < min){ data = min; } else if (data > max) { data = max; }

class ZombieList
{
private:
    unity::Matrix* matrix;
    Graphics* draw = nullptr;
    Vec3 camPoint;

    struct Skeleton
    {
        Vec3 Skeleton,
            Left_Hip,
            Left_Leg,
            Left_Foot,
            Right_Hip,
            Right_Leg,
            Right_Foot,
            Spine,
            Skull,
            Spot,
            Left_Shoulder,
            Left_Arm,
            Left_Hand,
            Left_Hook,
            Right_Shoulder,
            Right_Arm,
            Right_Hand,
            Right_Hook;
    };

    struct zombie
    {
        std::string zombieType;
        Skeleton bones;
        Vec3 velocity;
        Vec2 angles;
        float distance = 0.f;

        void clear()
        {
            zombieType.clear();
            distance = 0.f;
        }
        zombie()
        {
            distance = 0.f;
        }
    };

    Vec2 WorldToScreen(Vec3 WorldPos)
    {
        if (WorldPos == 0)
            return -1;
        float width = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(WorldPos) + matrix->translation.w;
        Vec2 pos = Vec2(Vec3(matrix->right.x, matrix->up.x, matrix->forward.x).dot(WorldPos) + matrix->translation.x, Vec3(matrix->right.y, matrix->up.y, matrix->forward.y).dot(WorldPos) + matrix->translation.y);
        if (width < 0.098)
            return -1;
        Vec2 point = Vec2((draw->canvasSize.x / 2) * (1 + pos.x / width), (draw->canvasSize.y / 2) * (1 - pos.y / width));
        if (point.x > 0 && point.y > 0 && point.x < draw->canvasSize.x && point.y < draw->canvasSize.y)
            return point;
        return -1;
    }

    bool getSkeleton(unity::Transform* skeleton, Skeleton* bones)
    {
        int count = 0;
        auto Skeleton = skeleton;
        if (!Skeleton) { return 0; }
        auto Left_Hip = Skeleton->child(0);
        if (!Left_Hip) { return 0; }
        auto Left_Leg = Left_Hip->child(0);
        if (!Left_Leg) { return 0; }
        auto Left_Foot = Left_Leg->child(0);
        if (!Left_Foot) { return 0; }
        auto Right_Hip = Skeleton->child(1);
        if (!Right_Hip) { return 0; }
        auto Right_Leg = Right_Hip->child(0);
        if (!Right_Leg) { return 0; }
        auto Right_Foot = Right_Leg->child(0);
        if (!Right_Foot) { return 0; }
        auto Spine = Skeleton->child(2);
        if (!Spine) { return 0; }
        auto Skull = Spine->child(XORS("Skull"));
        if (!Skull) { return 0; }
        auto Spot = Skull->child(0);
        if (!Spot) { return 0; }
        auto Left_Shoulder = Spine->child(XORS("Left_Shoulder"));
        if (!Left_Shoulder) { return 0; }
        auto Left_Arm = Left_Shoulder->child(0);
        if (!Left_Arm) { return 0; }
        auto Left_Hand = Left_Arm->child(0);
        if (!Left_Hand) { return 0; }
        auto Left_Hook = Left_Hand->child(0);
        if (!Left_Hook) { return 0; }
        auto Right_Shoulder = Spine->child(XORS("Right_Shoulder"));
        if (!Right_Shoulder) { return 0; }
        auto Right_Arm = Right_Shoulder->child(0);
        if (!Right_Arm) { return 0; }
        auto Right_Hand = Right_Arm->child(0);
        if (!Right_Hand) { return 0; }
        auto Right_Hook = Right_Hand->child(0);
        if (!Right_Hook) { return 0; }

        bones->Skeleton = Skeleton->position();
        bones->Left_Hip = Left_Leg->position();
        bones->Left_Leg = Left_Leg->position(1);
        bones->Left_Foot = Left_Foot->position(1);
        bones->Right_Hip = Right_Leg->position();
        bones->Right_Leg = Right_Leg->position(1);
        bones->Right_Foot = Right_Foot->position(1);
        bones->Spine = Spine->position();
        bones->Skull = Skull->position();
        bones->Spot = Spot->position();
        bones->Left_Shoulder = Left_Arm->position(0);
        bones->Left_Arm = Left_Arm->position(1);
        bones->Left_Hand = Left_Hand->position(1);
        bones->Left_Hook = Left_Hook->position();
        bones->Right_Shoulder = Right_Arm->position(0);
        bones->Right_Arm = Right_Arm->position(1);
        bones->Right_Hand = Right_Hand->position(1);
        bones->Right_Hook = Right_Hook->position();


        return true;
    }

    void drawSkeleton(ZombieList::Skeleton bones, fColor color, UCHAR thickness = 2)
    {
        draw->line(WorldToScreen(bones.Spot), WorldToScreen(bones.Skull), thickness, color);
        draw->line(WorldToScreen(bones.Right_Shoulder), WorldToScreen(bones.Skull), thickness, color);
        draw->line(WorldToScreen(bones.Left_Shoulder), WorldToScreen(bones.Skull), thickness, color);
        draw->line(WorldToScreen(bones.Right_Arm), WorldToScreen(bones.Right_Shoulder), thickness, color);
        draw->line(WorldToScreen(bones.Left_Arm), WorldToScreen(bones.Left_Shoulder), thickness, color);
        draw->line(WorldToScreen(bones.Right_Hand), WorldToScreen(bones.Right_Arm), thickness, color);
        draw->line(WorldToScreen(bones.Left_Hand), WorldToScreen(bones.Left_Arm), thickness, color);
        draw->line(WorldToScreen(bones.Spine), WorldToScreen(bones.Skull), thickness, color);
        draw->line(WorldToScreen(bones.Spine), WorldToScreen(bones.Right_Hip), thickness, color);
        draw->line(WorldToScreen(bones.Spine), WorldToScreen(bones.Left_Hip), thickness, color);
        draw->line(WorldToScreen(bones.Right_Hip), WorldToScreen(bones.Right_Leg), thickness, color);
        draw->line(WorldToScreen(bones.Left_Hip), WorldToScreen(bones.Left_Leg), thickness, color);
        draw->line(WorldToScreen(bones.Right_Leg), WorldToScreen(bones.Right_Foot), thickness, color);
        draw->line(WorldToScreen(bones.Left_Leg), WorldToScreen(bones.Left_Foot), thickness, color);
    }

    std::vector<zombie> zombies;
public:
    struct Target
    {
        Vec3 point;
        Vec3 velocity;
    };

    void update(Vec3 camPoint)// updates players based on Settings
    {
        this->camPoint = camPoint;
        auto regions = ZombieManager->regions();
        zombies.clear();

        for (auto region : regions)
        {
            auto _zombies = region->_zombies();
            for (int i = 0; i < _zombies.size(); i++)
            {
                zombie zomb;
                auto _zombie = _zombies.at(i);
                auto _skeleton = _zombie->skeleton();
                zomb.distance = _skeleton->position().distance(camPoint);
                if (_zombie->isDead() || zomb.distance > Settings::Zombie::renderDistance * 750.f)
                    continue;
                    
                while (!getSkeleton(_skeleton, &zomb.bones)) {};

                switch (_zombie->speciality())
                {
                case  SDK::EZombieSpeciality::NORMAL:
                    zomb.zombieType = XORS("Normal");
                    break;
                case  SDK::EZombieSpeciality::MEGA:
                    zomb.zombieType = XORS("Mega");
                    break;
                case  SDK::EZombieSpeciality::CRAWLER:
                    zomb.zombieType = XORS("Crawler");
                    break;
                case  SDK::EZombieSpeciality::SPRINTER:
                    zomb.zombieType = XORS("Sprinter");
                    break;
                case  SDK::EZombieSpeciality::FLANKER_FRIENDLY:
                    zomb.zombieType = XORS("Flanker");
                    break;
                case  SDK::EZombieSpeciality::FLANKER_STALK:
                    zomb.zombieType = XORS("Flanker");
                    break;
                case  SDK::EZombieSpeciality::BURNER:
                    zomb.zombieType = XORS("Burner");
                    break;
                case  SDK::EZombieSpeciality::ACID:
                    zomb.zombieType = XORS("Acid");
                    break;
                case  SDK::EZombieSpeciality::BOSS_ELECTRIC:
                    zomb.zombieType = XORS("Eletric Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_WIND:
                    zomb.zombieType = XORS("Wind Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_MAGMA:
                    zomb.zombieType = XORS("Magma Boss");
                    break;
                case  SDK::EZombieSpeciality::SPIRIT:
                    zomb.zombieType = XORS("Spirit");
                    break;
                case  SDK::EZombieSpeciality::BOSS_SPIRIT:
                    zomb.zombieType = XORS("Spirit Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_NUCLEAR:
                    zomb.zombieType = XORS("Nuclear Boss");
                    break;
                case  SDK::EZombieSpeciality::DL_RED_VOLATILE:
                    zomb.zombieType = XORS("Red Volatile");
                    break;
                case  SDK::EZombieSpeciality::DL_BLUE_VOLATILE:
                    zomb.zombieType = XORS("Blue Volatile");
                    break;
                case  SDK::EZombieSpeciality::BOSS_ELVER_STOMPER:
                    zomb.zombieType = XORS("Stomper Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_KUWAIT:
                    zomb.zombieType = XORS("Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_BUAK_ELECTRIC:
                    zomb.zombieType = XORS("Electric Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_BUAK_WIND:
                    zomb.zombieType = XORS("Wind Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_BUAK_FIRE:
                    zomb.zombieType = XORS("Fire Boss");
                    break;
                case  SDK::EZombieSpeciality::BOSS_BUAK_FINAL:
                    zomb.zombieType = XORS("Final Boss");
                    break;
                default:
                    break;
                }

                
                zomb.velocity = (_skeleton->position() - _zombie->lastUpdatedPos()).normalized();

                auto angle = _skeleton->root_rotation().toEulerAngles();
                zomb.angles = { angle.x, angle.z};
                zombies.push_back(zomb);

                for (int index = 0; index < zombies.size(); index++)
                {
                    if (zombies.at(index).distance > zomb.distance)
                    {
                        zombies.insert(zombies.begin() + index, zomb);
                        zombies.pop_back();
                        break;
                    }
                }
            }
        }
    }

    void render(unity::Matrix* matrix)
    {
        this->matrix = matrix;

        for (int index = (int)zombies.size() - 1; index >= 0; index--)
        {
            auto _zombie = zombies.at(index);
            if (!_zombie.distance)
                continue;

            float scale = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(_zombie.bones.Skeleton) + matrix->translation.w;
            clamp(scale, 1.f, 10.f);

            fColor color = { 0.5, 0.5 , 0.75 , 0.4 };
            drawSkeleton(_zombie.bones, color, 1);
            draw->line(WorldToScreen(_zombie.bones.Spot), WorldToScreen(_zombie.bones.Spot - (_zombie.velocity * 3.f)), 1, color);
            draw->text(WorldToScreen(_zombie.bones.Skeleton) + Vec2(0, (95.f / scale) * 1), CENTER, 95.f / scale, 0, color, _zombie.zombieType.c_str());
        }
    }
    
    Target best_target(Settings::EAimbotBones target)
    {
        Target best = { 0 };
        float min_distance = 100000.f;
        for (auto zombie : zombies)
        {
            Vec3 bone;
            if (target == Settings::Head) {
                bone = zombie.bones.Spot;
            }
            else if (target == Settings::Neck) {
                bone = (zombie.bones.Spot - ((zombie.bones.Spot - zombie.bones.Skull) * 0.5f)); ;
            }
            else if (target == Settings::Chest) {
                bone = (zombie.bones.Spine - ((zombie.bones.Spine - zombie.bones.Skull) * 0.85f));
            }
            else if (target == Settings::Pelvis) {
                bone = zombie.bones.Spine;
            }

            float scale = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(bone) + matrix->translation.w;

            float pxDist = WorldToScreen(bone).distance(draw->canvasSize / 2);

            if (pxDist < Settings::Aimbot::fov * (draw->canvasSize.y / 2) && pxDist * scale < min_distance)
            {
                min_distance = pxDist * scale;
                best.point = bone;
                best.velocity = zombie.velocity;
            }
        }
        return best;
    }

    ZombieList(Graphics* draw) { this->draw = draw; }
};
#undef clamp