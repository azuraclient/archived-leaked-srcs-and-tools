#pragma once
#define clamp(data, min, max)if (data < min){ data = min; } else if (data > max) { data = max; }
class PlayerList
{
private:
    unity::Matrix* matrix;
    Graphics* draw = nullptr;
    Vec3 camPoint;

    struct Skeleton
    {
        Vec3 Skeleton,
            Left_Hip,
            Left_Leg,
            Left_Foot,
            Right_Hip,
            Right_Leg,
            Right_Foot,
            Spine,
            Skull,
            Spot,
            Left_Shoulder,
            Left_Arm,
            Left_Hand,
            Left_Hook,
            Right_Shoulder,
            Right_Arm,
            Right_Hand,
            Right_Hook;
    };
    
    struct player
    {
        std::wstring charaterName, itemName;
        bool isSafe;
        Skeleton bones;

        Vec3 velocity;
        Vec2 angles;
        DWORD reputation;
        QWORD steamID;
        float range, distance = 0.f;

        void clear()
        {
            charaterName.clear();
            itemName.clear();
            steamID = 0;
            isSafe = false;
            reputation = 0x0;
            steamID = 0x0;
            range = 0.f;
            distance = 0.f;
        }
        player()
        {
            isSafe = false;
            reputation = 0x0;
            steamID = 0x0;
            range = 0.f;
            distance = 0.f;
        }
    };

    Vec2 WorldToScreen(Vec3 WorldPos)
    {
        if (WorldPos == 0)
            return -1;
        float width = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(WorldPos) + matrix->translation.w;
        Vec2 pos = Vec2(Vec3(matrix->right.x, matrix->up.x, matrix->forward.x).dot(WorldPos) + matrix->translation.x, Vec3(matrix->right.y, matrix->up.y, matrix->forward.y).dot(WorldPos) + matrix->translation.y);
        if (width < 0.098)
            return -1;
        Vec2 point = Vec2((draw->canvasSize.x / 2) * (1 + pos.x / width), (draw->canvasSize.y / 2) * (1 - pos.y / width));
        if (point.x > 0 && point.y > 0 && point.x < draw->canvasSize.x && point.y < draw->canvasSize.y)
            return point;
        return -1;
    }

    bool getSkeleton(unity::Transform* skeleton, Skeleton* bones)
    {
        int count = 0;
        auto Skeleton = skeleton;
        if (!Skeleton) { return 0; }
        auto Left_Hip = Skeleton->child(0);
        if (!Left_Hip) { return 0; }
        auto Left_Leg = Left_Hip->child(0);
        if (!Left_Leg) { return 0; }
        auto Left_Foot = Left_Leg->child(0);
        if (!Left_Foot) { return 0; }
        auto Right_Hip = Skeleton->child(1);
        if (!Right_Hip) { return 0; }
        auto Right_Leg = Right_Hip->child(0);
        if (!Right_Leg) { return 0; }
        auto Right_Foot = Right_Leg->child(0);
        if (!Right_Foot) { return 0; }
        auto Spine = Skeleton->child(2);
        if (!Spine) { return 0; }
        auto Skull = Spine->child(XORS("Skull"));
        if (!Skull) { return 0; }
        auto Spot = Skull->child(0);
        if (!Spot) { return 0; }
        auto Left_Shoulder = Spine->child(XORS("Left_Shoulder"));
        if (!Left_Shoulder) { return 0; }
        auto Left_Arm = Left_Shoulder->child(0);
        if (!Left_Arm) { return 0; }
        auto Left_Hand = Left_Arm->child(0);
        if (!Left_Hand) { return 0; }
        auto Left_Hook = Left_Hand->child(0);
        if (!Left_Hook) { return 0; }
        auto Right_Shoulder = Spine->child(XORS("Right_Shoulder"));
        if (!Right_Shoulder) { return 0; }
        auto Right_Arm = Right_Shoulder->child(0);
        if (!Right_Arm) { return 0; }
        auto Right_Hand = Right_Arm->child(0);
        if (!Right_Hand) { return 0; }
        auto Right_Hook = Right_Hand->child(0);
        if (!Right_Hook) { return 0; }

        bones->Skeleton = Skeleton->position();
        bones->Left_Hip = Left_Leg->position();
        bones->Left_Leg = Left_Leg->position(1);
        bones->Left_Foot = Left_Foot->position(1);
        bones->Right_Hip = Right_Leg->position();
        bones->Right_Leg = Right_Leg->position(1);
        bones->Right_Foot = Right_Foot->position(1);
        bones->Spine = Spine->position();
        bones->Skull = Skull->position();
        bones->Spot = Spot->position();
        bones->Left_Shoulder = Left_Arm->position(0);
        bones->Left_Arm = Left_Arm->position(1);
        bones->Left_Hand = Left_Hand->position(1);
        bones->Left_Hook = Left_Hook->position();
        bones->Right_Shoulder = Right_Arm->position(0);
        bones->Right_Arm = Right_Arm->position(1);
        bones->Right_Hand = Right_Hand->position(1);
        bones->Right_Hook = Right_Hook->position();


        return true;
    }
    
    void drawSkeleton(PlayerList::Skeleton bones, fColor color, UCHAR thickness = 2)
    {
        draw->line2(WorldToScreen(bones.Spot), WorldToScreen(bones.Skull), thickness, color);
        draw->line2(WorldToScreen(bones.Right_Shoulder), WorldToScreen(bones.Skull), thickness, color);
        draw->line2(WorldToScreen(bones.Left_Shoulder), WorldToScreen( bones.Skull), thickness, color);
        draw->line2(WorldToScreen(bones.Right_Arm), WorldToScreen( bones.Right_Shoulder), thickness, color);
        draw->line2(WorldToScreen(bones.Left_Arm), WorldToScreen( bones.Left_Shoulder), thickness, color);
        draw->line2(WorldToScreen(bones.Right_Hand), WorldToScreen( bones.Right_Arm), thickness, color);
        draw->line2(WorldToScreen(bones.Left_Hand), WorldToScreen( bones.Left_Arm), thickness, color);
        draw->line2(WorldToScreen(bones.Spine), WorldToScreen( bones.Skull), thickness, color);
        draw->line2(WorldToScreen(bones.Spine), WorldToScreen( bones.Right_Hip), thickness, color);
        draw->line2(WorldToScreen(bones.Spine), WorldToScreen( bones.Left_Hip), thickness, color);
        draw->line2(WorldToScreen(bones.Right_Hip), WorldToScreen( bones.Right_Leg), thickness, color);
        draw->line2(WorldToScreen(bones.Left_Hip), WorldToScreen( bones.Left_Leg), thickness, color);
        draw->line2(WorldToScreen(bones.Right_Leg), WorldToScreen( bones.Right_Foot), thickness, color);
        draw->line2(WorldToScreen(bones.Left_Leg), WorldToScreen( bones.Left_Foot), thickness, color);
    }

    std::vector<player> players;
public:
    struct Target
    {
        Vec3 point;
        Vec3 velocity;
    };

    SDK::SteamPlayer* LocalPlayer = nullptr;

	void update(Vec3 camPoint)// updates players based on Settings
	{
        this->camPoint = camPoint;
        auto _clients = Provider->_clients();
        //players.clear();
        if(players.size() != _clients.size())
            players.resize(_clients.size());

        for (int i = 0; i < _clients.size(); i++) // Loop client list
        {
            auto _client = _clients.at(i);
            player* instance = &players.at(i);
            instance->clear();
            auto _player    = _client->_player();
            auto _movement  = _player->_movement();

            // skips local and far players
            instance->distance = camPoint.distance(_client->_model()->child(1)->position());
            if (_player->_isLocal())
            {
                LocalPlayer = _clients.at(i);
                instance->distance = 0;
                continue;
            }
            else if (instance->distance > Settings::Player::renderDistance * 2000.f || _player->_life()->_isDead())
            {
                instance->distance = 0;
                continue;
            }

            auto _playerID = _client->_playerID();

            // get player managers
            auto _skills    = _player->_skills();
            auto _stance    = _player->_stance();
            auto _look      = _player->_look();
            auto _equipment = _player->_equipment();
            
            // get _playerID data
            auto _steamID = _playerID->_steamID();
            auto _charaterName = _playerID->_characterName();

            // get _player data
            auto _skeleton = _client->skeleton();
            Vec2 _angles = {
                _look->_pitch(),
                _look->_yaw() };
            auto _isSafe = _movement->_isSafe();
            auto _repuation = _skills->_reputation();

            //populate Player struct
            instance->velocity = _movement->calcuate_velocity(_skeleton, _skills->_skills(0, 4)->mastery(), _skills->_skills(0, 5)->mastery(), _stance->_stance());
            while (!getSkeleton(_skeleton, &instance->bones)) { };
            instance->angles = _angles;
            instance->charaterName = _charaterName;
            instance->steamID = _steamID;
            instance->isSafe = _isSafe;
            instance->reputation = _repuation;

            // adds equipment info is populated
            if (_equipment)
            {
                if (auto _asset = _equipment->_asset())
                {
                    if (_asset->type() == SDK::EItemType::GUN)
                    {
                        instance->itemName = _asset->_itemName();
                        instance->range = ((SDK::ItemWeaponAsset*)_asset)->range();
                    }
                    else
                    {
                        instance->itemName = _asset->_itemName();
                        instance->range = 0.f;
                    }
                }
                else
                {
                    instance->itemName.clear();
                    instance->range = 0.f;
                }
            }
            else
            {
                instance->itemName.clear();
                instance->range = 0.f;
            }
                

            // sorts players by distance for drawing
            for (int index = 0; index < players.size(); index++)
            {
                if (players.at(index).distance > instance->distance)
                {
                    players.insert(players.begin() + index, *instance);
                    players.pop_back();
                    break;
                }
            }
        }
	}
    
    void render(unity::Matrix* matrix)
    {
        this->matrix = matrix;

        float font_scale = 0;
        
        for (auto player : players)
        {
            if (!player.distance || player.distance > 500.f)
                continue;
            fColor cLine;
            Vec3 aimLine = Vector3::rotatey(player.bones.Spot, Vector3::rotatex(player.bones.Spot, player.bones.Spot + Vec3(0, 0, 5.f), (player.angles.x / 57.2957795131f) - 1.57079632679f), player.angles.y / 57.2957795131f);
            float dist = camPoint.distance(player.bones.Spot) - camPoint.distance(aimLine);
            float lineSize = player.bones.Spot.distance(aimLine);
            if (dist < 0)
                cLine = { 0.f, 1.f - (-dist / lineSize), (-dist / lineSize), 1.f };
            else
                cLine = { 1.f * (dist / lineSize), 1.f - (dist / lineSize), 0.f, 1.f };
            if (Settings::Game::alertClosePlayers)
                draw->text2(Vec2(draw->canvasSize.x, font_scale), TOPRIGHT, ((500.f - player.distance) / 500.f) * 20.f + 8.f, 0, cLine, XORS(L"%s [%i] %.1fm"), player.charaterName.c_str(), player.reputation, player.distance);
            fRect test = draw->textRect(Vec2(draw->canvasSize.x, font_scale), TOPRIGHT, ((500.f - player.distance) / 500.f) * 20.f + 8.f, 0, XORS(L"%s [%i] %.1fm"), player.charaterName.c_str(), player.reputation, player.distance);
            font_scale += test.size().y;
        }
        for (int index = (int)players.size() - 1; index >= 0; index--)
        {
            auto player = players.at(index);
            if (!player.distance)
                continue;

            float scale = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(player.bones.Skeleton) + matrix->translation.w;
            clamp(scale, 1.f, 10.f);

            Vec3 aimLine = Vector3::rotatey(player.bones.Spot, Vector3::rotatex(player.bones.Spot, player.bones.Spot + Vec3(0, 0, 5.f), (player.angles.x / 57.2957795131f) - 1.57079632679f), player.angles.y / 57.2957795131f);

            fColor cLine;
            float dist = camPoint.distance(player.bones.Spot) - camPoint.distance(aimLine);
            float lineSize = player.bones.Spot.distance(aimLine);
            if (dist < 0)
                cLine = { 0.f, 1.f - (-dist / lineSize), (-dist / lineSize), 1.f };
            else
                cLine = { 1.f * (dist / lineSize), 1.f - (dist / lineSize), 0.f, 1.f };

            drawSkeleton(player.bones, WHITE, 2);
            draw->line(WorldToScreen(player.bones.Spot), WorldToScreen(aimLine), 3, cLine);
            draw->text2(WorldToScreen(player.bones.Skeleton) + Vec2(0, (95.f / scale) * 1), CENTER, 95.f / scale, 0, WHITE, XORS(L"%s [%i] %.1fm"), player.charaterName.c_str(), player.reputation, player.distance);
            if (!player.itemName.size())
                continue;
            if (player.range)
                draw->text2(WorldToScreen(player.bones.Skeleton) + Vec2(0, (95.f / scale) * 2), CENTER, 95.f / scale, 0, WHITE, XORS(L"%s (%.0fm)"), player.itemName.c_str(), player.range);
            else
                draw->text2(WorldToScreen(player.bones.Skeleton) + Vec2(0, (95.f / scale) * 2), CENTER, 95.f / scale, 0, WHITE, XORS(L"%s"), player.itemName.c_str());
        }
    }

    Target best_target(Settings::EAimbotBones target)
    {
        Target best = { 0 };
        float min_distance = 100000.f;
        for (auto _player : players)
        {
            if (!_player.distance || _player.isSafe)
                continue;
            Vec3 bone;
            if (target == Settings::Head) {
                bone = _player.bones.Spot;
            }else if (target == Settings::Neck) {
                bone = (_player.bones.Spot - ((_player.bones.Spot - _player.bones.Skull) * 0.5f)); ;
            }else if (target == Settings::Chest) {
                bone = (_player.bones.Spine - ((_player.bones.Spine - _player.bones.Skull) * 0.85f));
            } else if (target == Settings::Pelvis) {
                bone = _player.bones.Spine;
            }

            float scale = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(bone) + matrix->translation.w;

            float pxDist = WorldToScreen(bone).distance(draw->canvasSize / 2);
            
            if (pxDist < Settings::Aimbot::fov * (draw->canvasSize.y / 2) && pxDist * scale < min_distance)
            {
                min_distance = pxDist * scale;
                best.point = bone;
                best.velocity = _player.velocity;
            }
        }
        return best;
    }

	PlayerList(Graphics* draw) { this->draw = draw; }
};
#undef clamp