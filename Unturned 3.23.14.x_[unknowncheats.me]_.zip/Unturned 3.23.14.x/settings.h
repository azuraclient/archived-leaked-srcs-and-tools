#pragma once

namespace Settings
{
	enum EAimbotBones
	{
		Head,
		Neck,
		Chest,
		Pelvis
	};
	namespace Game
	{
		bool satellite;
		bool chart;
		bool compass;
		bool overideSalvage;
		bool freeCamera;
		bool alertClosePlayers = 1;
		float exitTimer;
		float recoil = 0.5f;
		float spread = 0.25f;
		float salvageTime;
	}
	namespace Player
	{
		float renderDistance = 0.25f;
	};
	namespace Zombie
	{
		float renderDistance = 0.133f;
	};
	namespace Vehicle
	{
		float renderDistance = 0.4f;
	};
	namespace Loot
	{
		float renderDistance = 0.2f;
	};
	namespace Aimbot
	{
		float fov = 1.0f;
		float smoothing = 0.0f;
		EAimbotBones bone = Head;
		Vec3 target;
		bool targetZombies = 0;
		bool targetAnimals = 0;
		bool targetPlayers = 1;
	};
};