#pragma once
#include "settings.h"

class g_subRect
{
private:
	Graphics* draw;
	void p_slider(fRect rect, float* progress, Graphics::DragableSurface* DragableSurface, bool dbg = false)
	{
		DragableSurface->anchor(rect.position())->rect.size({ 10, rect.size().y });
		draw->dragable(DragableSurface, dbg);
		if (!DragableSurface->isMoving)
			DragableSurface->rect.position({ rect.position().x + ((rect.size().x - 10.f) * *progress), rect.position().y }).size({ 10, rect.size().y });
		fRect handle = DragableSurface->rect;
		if (handle.position().x < rect.position().x)
			handle.position({ rect.position().x, rect.position().y });
		else if (handle.position().x > rect.position().x + rect.size().x - handle.size().x)
			handle.position({ rect.position().x + rect.size().x - handle.size().x, rect.position().y });
		handle.position({ handle.position().x, rect.position().y });
		*progress = (handle.position().x - rect.position().x) / (rect.size().x - 10.f);
		if (!DragableSurface->isMoving)
			DragableSurface->rect = handle;
		fRect bar = fRect().position(rect.position() + Vec2(0, rect.size().y * 0.375f)).size({ rect.size().x, rect.size().y / 4.f });
		draw->rect(bar, bar.size().y / 2, WHITE);
		draw->rect(fRect().position({ bar.position().x + bar.size().x * *progress, bar.position().y }).size({ bar.size().x * (1.f - *progress), bar.size().y }), bar.size().y / 2, BLACK);
		draw->rect(fRect().position(bar.position()).size({ bar.size().x * *progress, bar.size().y }), bar.size().y / 2, WHITE);

		fColor c;
		if (DragableSurface->isMoving)
		{
			c = { 0.65f, 0.65f, 0.65f, 1.f };
		}
		else
		{
			switch (draw->captureMouse(handle))
			{
			case Graphics::HOVERING:
				c = { 0.78f, 0.78f, 0.78f, 1.f };
				break;
			default:
				c = { 0.7f, 0.7f, 0.7f, 1.f };
				break;
			}
		}

		draw->rect(handle, handle.size().x / 2, c);
		if (dbg)
		{
			fRect txtDdg = draw->textRect(rect.position(), TOPLEFT, rect.size().y, 0, XORS(L"%.1f%%"), *progress * 100.f);
			draw->rect(txtDdg, 0, { 0,0,0,0.4f });
			draw->text(txtDdg, rect.size().y, 0, { 1, 1, 1, 0.25f }, XORS(L"%.1f%%"), *progress * 100.f);
		}
	}

	std::vector<Graphics::DragableSurface>* v_ds;
	DWORD* v_ds_count;
public:
	fRect f_rect;
	Vec2 roundness;
	fColor color = CLEAR;

	g_subRect(Graphics* draw, fRect parent, std::vector<Graphics::DragableSurface>* v_ds, DWORD* v_ds_count, fRect child, Vec2 roundness, fColor color) : draw(draw), v_ds(v_ds), v_ds_count(v_ds_count), roundness(roundness), color(color) { f_rect.position(parent.position() + child.position()).size(child.size()); draw->rect(f_rect, roundness, color); }

	bool slider(Vec2 point, Vec2 size, float* progress, bool dbg = false)
	{
		fRect rect = fRect().position(point).size(size);
		rect.position(this->f_rect.position() + rect.position()).size(rect.size());

		if (v_ds->size() == *v_ds_count)
			v_ds->resize(*v_ds_count + 1);
		p_slider(rect, progress, &v_ds->at(*v_ds_count), dbg);
		bool isMoving = v_ds->at(*v_ds_count).isMoving;
		*v_ds_count = *v_ds_count + 1;
		return isMoving;
	}

	bool button(Vec2 point, Vec2 size, const char* text = "", bool dbg = false)
	{
		fRect rect = fRect().position(point).size(size);
		rect.position(this->f_rect.position() + rect.position()).size(rect.size());

		bool status = false;
		auto cursor = draw->captureMouse(rect);
		fColor c1, c2;
		switch (cursor)
		{
		case Graphics::HOVERING:
			c1 = { 0.3f, 0.3f, 0.3f, 1.f };
			c2 = { 0.08f, 0.08f, 0.08f, 1.f };
			break;
		case Graphics::LEFT_HOLDING:
			c1 = { 0.24f, 0.24f, 0.24f, 1.f };
			c2 = { 0.24f, 0.24f, 0.24f, 1.f };
			break;
		case Graphics::LEFT_CLICKING:
			c1 = { 0.24f, 0.24f, 0.24f, 1.f };
			c2 = { 0.24f, 0.24f, 0.24f, 1.f };
			status = true;
			break;
		default:
			c1 = { 0.26f, 0.26f, 0.26f, 1.f };
			c2 = BLACK;
			break;
		}
		draw->rect(rect, rect.size().y / 5, c1);
		draw->rect((rect + 1).size(rect.size() - 2), rect.size().y / 5, c2);
		draw->text(rect.position() + (rect.size() / 2), CENTER, rect.size().y * 0.8f, 0, { .8, .8, .8, 1 }, text);
		if (dbg)
		{
			draw->rect(rect, 0, { 0,0,0,0.4f });
		}
		return status;
	}

	void checkBox(Vec2 point, Vec2 size, bool* state)
	{
		fRect rect = fRect().position(point).size(size);
		rect.position(this->f_rect.position() + rect.position()).size(rect.size());

		auto cursor = draw->captureMouse(rect);
		fColor c1, c2;
		switch (cursor)
		{
		case Graphics::HOVERING:
			c1 = { 0.3f, 0.3f, 0.3f, 1.f };
			c2 = { 0.08f, 0.08f, 0.08f, 1.f };
			break;
		case Graphics::LEFT_CLICKING:
			*state = !*state;
			break;
		default:
			c1 = { 0.26f, 0.26f, 0.26f, 1.f };
			c2 = BLACK;
			break;
		}
		draw->rect(rect, 0, c1);
		draw->rect(rect.position(rect.position() + 1).size(rect.size() - 2), 0, c2);
		if (*state)
		{
			draw->line(rect.position() + 2, rect.position() + rect.size() - 2, 1, { 0.7, 0.7, 0.7, 1 });
			draw->line(Vec2({ rect.right - 2, rect.top + 2 }), Vec2({ rect.left + 2, rect.bottom - 2 }), 1, { 0.7, 0.7, 0.7, 1 });
		}

	}

	bool textBox(Vec2 point, Vec2 size, char* text, const char* defaultText)
	{
		fRect rect = fRect().position(point).size(size);
		rect.position(this->f_rect.position() + rect.position()).size(rect.size());

		if (v_ds->size() == *v_ds_count)
			v_ds->resize(*v_ds_count + 1);
		draw->rect(rect, 0, { 0.3f, 0.3f, 0.3f, 1.f });
		if (v_ds->at(*v_ds_count).other)
			draw->rect(rect.position(rect.position() + 1).size(rect.size() - 2), 0, { 0.09f, 0.09f, 0.09f, 1.f });
		else
			draw->rect(rect.position(rect.position() + 1).size(rect.size() - 2), 0, { 0.06f, 0.06f, 0.06f, 1.f });
		bool state = draw->captureKeyboard(rect, rect.size().y * 0.8f, 0, { 0.7f, 0.7f, 0.7f, 1.f }, text, defaultText, &v_ds->at(*v_ds_count).other);
		*v_ds_count = *v_ds_count + 1;
		return state;
	}

	void text(Vec2 point, TextCenter center, float size, const char* format, ...)
	{
		point += this->f_rect.position();

		char* buffer = (char*)malloc(0xFF);
		memset(buffer, 0, 0xFF);
		if (!buffer)
			return;
		va_list args;
		va_start(args, format);
		int written = vsnprintf(buffer, 0xFF, format, args);

		va_end(args);
		draw->text(point, center, size, 0, { 0.7f, 0.7f, 0.7f, 1.f }, buffer);
		free(buffer);
	}

	void rect(Vec2 point, Vec2 size, Vec2 roundness, fColor color)
	{
		fRect rect = fRect().position(point).size(size);
		rect.position(this->f_rect.position() + rect.position()).size(rect.size());

		draw->rect(rect, roundness, color);
	}

	g_subRect* subRect(Vec2 point, Vec2 size, Vec2 roundness, fColor color)
	{
		return new g_subRect(draw, this->f_rect, v_ds, v_ds_count, fRect().position(point).size(size), roundness, color);
	}
};

class g_gui
{
private:
	Graphics* draw;
	Graphics::DragableSurface ds;
	std::vector<Graphics::DragableSurface> v_ds;
	DWORD v_ds_count = 0;
public:
	fRect rect;
	fColor color = CLEAR;
	Vec2 roundness;
	g_subRect* subRect(Vec2 point, Vec2 size, Vec2 roundness, fColor color) { return new g_subRect(draw, this->rect, &v_ds, &v_ds_count, fRect().position(point).size(size), roundness, color); }
	bool start()
	{
		draw->dragable(&ds);
		rect.position(ds.rect.position());
		draw->rect(rect, 0, color, { 0.5,0.5,0.5,0.2f });
		draw->text(rect.position() + Vec2({ rect.size().x / 2, 2 }), TOPCENTER, 15, 0, { 0.9f, 0.9f, 0.9f, 1.f }, XORS(L"Hime7864's Trash Heap"));
		fRect closeButton = fRect().position(rect.position() + Vec2({ rect.size().x - 20, 0 })).size({ 20, 20 });
		switch (draw->captureMouse(closeButton))
		{
		case Graphics::MouseState::HOVERING:
			draw->text(rect.position() + Vec2({ rect.size().x - 20, -5 }), TOPLEFT, 22, 0, { 0.9f, 0.1f, 0.1f, 1.f }, "x");
			break;
		case Graphics::LEFT_CLICKING:
			return 0;
		default:
			draw->text(rect.position() + Vec2({ rect.size().x - 20, -5 }), TOPLEFT, 22, 0, { 0.9f, 0.9f, 0.9f, 1.f }, "x");
		}
		v_ds_count = 0;
		return 1;
	}
	g_gui(Graphics* draw, Vec2 point, Vec2 size) : draw(draw), rect(fRect().position(point).size(size)) { ds.rect = fRect().position(rect.position()).size({ rect.size().x, 20 }); v_ds.resize(0); v_ds_count = 0; }
	~g_gui()
	{
		v_ds.resize(0);
	}
};

class Menu
{
private:
	Graphics* draw = nullptr;
	g_gui* gui = nullptr;
	std::vector<std::string> boneTarget = { std::string(XORS("Head")), std::string(XORS("Neck")), std::string(XORS("Chest")), std::string(XORS("Pelvis")) };
public:
	Menu(Graphics* draw)
	{
		this->draw = draw;
		gui = new g_gui(draw, { (rand() % 100) + 10, (rand() % 120) + 10 }, { 240, 380 });
	}

	~Menu()
	{
		delete gui;
	}

	bool update()
	{
		

		if (!gui->start())
			return 0;
		gui->color = BLACK;
		auto Sub0 = gui->subRect({ 5, 25 }, { 230, 93 }, 5, { 0.07f, 0.07f, 0.07f, 1.f });
		Sub0->text({ Sub0->f_rect.size().x * .5f, 5 }, TOPCENTER, 14, XORS("Player Aimbot"));
		Sub0->rect({ 5, 30 }, { Sub0->f_rect.size().x - 10, 1 }, 0, GRAY);
		Sub0->text({ 110, 46 }, CENTERLEFT, 10, XORS("Fov Circle"));
		if (Sub0->slider({ 160, 42 }, { 60, 10 }, &Settings::Aimbot::fov))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS("%.0fpx"), Settings::Aimbot::fov * (draw->canvasSize.y / 2));
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS("%.0fpx"), Settings::Aimbot::fov * (draw->canvasSize.y / 2));
		}
		Sub0->text({ 108, 61 }, CENTERLEFT, 10, XORS("Smoothing"));
		if (Sub0->slider({ 160, 57 }, { 60, 10 }, &Settings::Aimbot::smoothing))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.0f%%"), Settings::Aimbot::smoothing * 100.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.0f%%"), Settings::Aimbot::smoothing * 100.f);
		}
		if (Sub0->button({ 156, 70 }, { 13, 13 }, "<"))
			(*(int*)&Settings::Aimbot::bone)--;
		if (Sub0->button({ 206, 70 }, { 13, 13 }, ">"))
			(*(int*)&Settings::Aimbot::bone)++;
		if ((*(int*)&Settings::Aimbot::bone) < 0)
			(*(int*)&Settings::Aimbot::bone) = (int)boneTarget.size() - 1;
		else if ((*(int*)&Settings::Aimbot::bone) >= boneTarget.size())
			(*(int*)&Settings::Aimbot::bone) = 0;
		Sub0->text({ 187, 76 }, CENTER, 10, boneTarget.at((*(int*)&Settings::Aimbot::bone)).c_str());
		Sub0->text({ 118, 76 }, CENTERLEFT, 10, XORS("Target"));

		Sub0->checkBox({ 5, 40 }, { 12, 12 }, &Settings::Aimbot::targetPlayers);
		Sub0->text({ 22, 46 }, CENTERLEFT, 10, XORS("Target Players"));
		Sub0->checkBox({ 5, 55 }, { 12, 12 }, &Settings::Aimbot::targetZombies);
		Sub0->text({ 22, 61 }, CENTERLEFT, 10, XORS("Zombie Players"));
		Sub0->checkBox({ 5, 70 }, { 12, 12 }, &Settings::Aimbot::targetAnimals);
		Sub0->text({ 22, 76 }, CENTERLEFT, 10, XORS("Animal Players"));

		auto Sub1 = gui->subRect({ 5, 123 }, { gui->rect.size().x / 2 - 5, 62 }, 5, { 0.07f, 0.07f, 0.07f, 1.f });
		Sub1->text({ Sub1->f_rect.size().x * .5f, 5 }, TOPCENTER, 14, XORS("Player ESP"));
		Sub1->rect({ 5, 30 }, { Sub1->f_rect.size().x - 10, 1 }, 0, GRAY);
		Sub1->text({ 5, 46 }, CENTERLEFT, 10, XORS("Distance"));
		if (Sub1->slider({ 50, 42 }, { 55, 10 }, &Settings::Player::renderDistance))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.1fm"), Settings::Player::renderDistance * 2000.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.1fm"), Settings::Player::renderDistance * 2000.f);
		}


		auto Sub2 = gui->subRect({ gui->rect.size().x / 2 + 5, 123 }, { gui->rect.size().x / 2 - 10, 62 }, 5, { 0.07f, 0.07f, 0.07f, 1.f });
		Sub2->text({ Sub2->f_rect.size().x * .5f, 5 }, TOPCENTER, 14, XORS("Zombie ESP"));
		Sub2->rect({ 5, 30 }, { Sub2->f_rect.size().x - 10, 1 }, 0, GRAY);
		Sub2->text({ 5, 46 }, CENTERLEFT, 10, XORS("Distance"));
		if (Sub2->slider({ 50, 42 }, { 55, 10 }, &Settings::Zombie::renderDistance))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.0fm"), Settings::Zombie::renderDistance * 750.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.0fm"), Settings::Zombie::renderDistance * 750.f);
		}

		auto Sub3 = gui->subRect({ 5, 190 }, { gui->rect.size().x / 2 - 5, 62 }, 5, { 0.07f, 0.07f, 0.07f, 1.f });
		Sub3->text({ Sub3->f_rect.size().x * .5f, 5 }, TOPCENTER, 14, XORS("Vehicle ESP"));
		Sub3->rect({ 5, 30 }, { Sub3->f_rect.size().x - 10, 1 }, 0, GRAY);
		Sub3->text({ 5, 46 }, CENTERLEFT, 10, XORS("Distance"));
		if (Sub3->slider({ 50, 42 }, { 55, 10 }, &Settings::Vehicle::renderDistance))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.1fm"), Settings::Vehicle::renderDistance * 2500.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.1fm"), Settings::Vehicle::renderDistance * 2500.f);
		}


		auto Sub4 = gui->subRect({ gui->rect.size().x / 2 + 5, 190 }, { gui->rect.size().x / 2 - 10, 62 }, 5, { 0.07f, 0.07f, 0.07f, 1.f });
		Sub4->text({ Sub4->f_rect.size().x * .5f, 5 }, TOPCENTER, 14, XORS("Loot ESP"));
		Sub4->rect({ 5, 30 }, { Sub4->f_rect.size().x - 10, 1 }, 0, GRAY);
		Sub4->text({ 5, 46 }, CENTERLEFT, 10, XORS("Distance"));
		if (Sub4->slider({ 50, 42 }, { 55, 10 }, &Settings::Loot::renderDistance))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.0fm"), Settings::Loot::renderDistance * 400.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.0fm"), Settings::Loot::renderDistance * 400.f);
		}

		auto Sub5 = gui->subRect({ 5, 257 }, { gui->rect.size().x - 10, 118 }, 5, { 0.07f, 0.07f, 0.07f, 1.f });
		Sub5->text({ Sub5->f_rect.size().x * .5f, 5 }, TOPCENTER, 14, XORS("Game Config"));
		Sub5->rect({ 5, 30 }, { Sub5->f_rect.size().x - 10, 1 }, 0, GRAY);
		Sub5->text({ 110, 46 }, CENTERLEFT, 10, XORS("Exit Timer"));
		if (Sub5->slider({ 160, 42 }, { 60, 10 }, &Settings::Game::exitTimer))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS("%.0fs"), Settings::Game::exitTimer * 20);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS("%.0fs"), Settings::Game::exitTimer * 20);
		}
		Sub5->text({ 108, 59 }, CENTERLEFT, 10, XORS("Svlg Time"));
		if (Sub5->slider({ 160, 55 }, { 60, 10 }, &Settings::Game::salvageTime))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.1fs"), (Settings::Game::salvageTime * 100.f) / 10.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.1fs"), (Settings::Game::salvageTime * 100.f) / 10.f);
		}
		Sub5->text({ 108, 72 }, CENTERLEFT, 10, XORS("Recoil"));
		if (Sub5->slider({ 160, 68 }, { 60, 10 }, &Settings::Game::recoil))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.1f%%"), Settings::Game::recoil * 100.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.1f%%"), Settings::Game::recoil * 100.f);
		}
		Sub5->text({ 108, 85 }, CENTERLEFT, 10, XORS("Spread"));
		if (Sub5->slider({ 160, 81 }, { 60, 10 }, &Settings::Game::spread))
		{
			fRect slider_0 = draw->textRect(draw->getCursor()->point, BOTTOMRIGHT, 10, 0, XORS(L"%.1f%%"), Settings::Game::spread * 100.f);
			draw->rect(slider_0, 2, { 0.07f, 0.07f, 0.07f, 0.45f });
			draw->text(slider_0, 10, 0, { 0.7f, 0.7f, 0.7f, 1.f }, XORS(L"%.1f%%"), Settings::Game::spread * 100.f);
		}

		Sub5->checkBox({ 5, 40 }, { 12, 12 }, &Settings::Game::compass);
		Sub5->text({ 22, 46 }, CENTERLEFT, 10, XORS("Compass"));
		Sub5->checkBox({ 5, 55 }, { 12, 12 }, &Settings::Game::chart);
		Sub5->text({ 22, 61 }, CENTERLEFT, 10, XORS("Chart"));
		Sub5->checkBox({ 5, 70 }, { 12, 12 }, &Settings::Game::satellite);
		Sub5->text({ 22, 76 }, CENTERLEFT, 10, XORS("Satellite"));
		Sub5->checkBox({ 5, 85 }, { 12, 12 }, &Settings::Game::overideSalvage);
		Sub5->text({ 22, 91 }, CENTERLEFT, 10, XORS("Salvage"));
		Sub5->checkBox({ 5, 100 }, { 12, 12 }, &Settings::Game::alertClosePlayers);
		Sub5->text({ 22, 106 }, CENTERLEFT, 10, XORS("Danger Radius"));
		delete Sub0;
		delete Sub1;
		delete Sub2;
		delete Sub3;
		delete Sub4;
		delete Sub5;
		return 1;
	}
};