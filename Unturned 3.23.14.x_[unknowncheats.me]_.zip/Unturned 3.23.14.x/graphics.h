#pragma once
#include <windows.h>
#include <dwmapi.h> 
#pragma comment(lib, "dwmapi.lib")
#include <d2d1.h>
#pragma comment(lib, "d2d1")
#include <dwrite.h>
#pragma comment(lib, "Dwrite")

#include <stdio.h>

#include "vector.h"
#include "xorstr.h"

#include <winternl.h>

#define FCOLOR_V2V(op) this->x op data.x, this->y op data.y, this->z op data.z, this->w op data.w
#define FCOLOR_V2F(op) this->x op data, this->y op data, this->z op data, this->w op data
#define FCOLOR_DefineOperator(type) void operator type=(VECTOR::Vector4 data){FCOLOR_V2V(type=);}\
 void operator type=(float data){FCOLOR_V2F(type=);}\
 VECTOR::FCOLOR operator type(VECTOR::Vector4 data) { return {FCOLOR_V2V(type)}; }\
 VECTOR::FCOLOR operator type(float data) { return {FCOLOR_V2F(type)}; }

class fColor
{
public:
	float r, g, b, a;
	fColor operator +(fColor data) {
		return {
			(this->r + data.r) * 0.5f,
			(this->g + data.g) * 0.5f,
			(this->b + data.b) * 0.5f,
			(this->a + data.a) * 0.5f
		};
	}

	bool operator !=(fColor data) {
		return (r != data.r || g != data.g || b != data.b );
	}

	fColor complementary()
	{
		return {
			max(0.0f, min(1.0f, (1.f - r))),
			max(0.0f, min(1.0f, (1.f - g))),
			max(0.0f, min(1.0f, (1.f - b))),
			max(0.0f, min(1.0f, (a)))
		};
	}
};

fColor CLEAR = { 0.f, 0.f, 0.f, 0.f };
fColor BLACK = { 0.f, 0.f, 0.f, 1.f };
fColor GRAY = { 0.5f, 0.5f, 0.5f, 1.f };
fColor WHITE = { 1.f, 1.f, 1.f, 1.f };
fColor RED = { 1.f, 0.f, 0.f, 1.f };
fColor GREEN = { 0.f, 1.f, 0.f, 1.f };
fColor BLUE = { 0.f, 0.f, 1.f, 1.f };
fColor YELLOW = { 1.f, 1.f, 0.f, 1.f };
fColor PURPLE = { 0.5f, 0.f, 0.5f, 1.f };
fColor PINK = { 1.f, 0.f, 1.f, 1.f };
fColor ORANGE = { 1.f, 0.5f, 0.f, 1.f };
fColor BROWN = { 0.5f, 0.25f, 0.25f, 1.f };

enum TextCenter
{
	TOPCENTER,
	TOPLEFT,
	TOPRIGHT,
	CENTER,
	CENTERLEFT,
	CENTERRIGHT,
	BOTTOMCENTER,
	BOTTOMLEFT,
	BOTTOMRIGHT
};

namespace RENDERER
{
	typedef NTSTATUS(WINAPI* pfnNtQueryInformationProcess)(
		HANDLE ProcessHandle,
		DWORD ProcessInformationClass,
		PVOID ProcessInformation,
		ULONG ProcessInformationLength,
		PULONG ReturnLength
		);

	void SetDebugBit(bool isBeingDebugged) {
		PVOID peb = nullptr;
		PROCESS_BASIC_INFORMATION pbi;
		ULONG returnLength = 0;
		pfnNtQueryInformationProcess NtQueryInformationProcess =
			(pfnNtQueryInformationProcess)GetProcAddress(GetModuleHandle(XORS(L"ntdll.dll")), XORS("NtQueryInformationProcess"));

		if (NtQueryInformationProcess != nullptr) {
			NTSTATUS status = NtQueryInformationProcess(GetCurrentProcess(), ProcessBasicInformation, &pbi, sizeof(pbi), &returnLength);

			if (NT_SUCCESS(status)) {
				peb = pbi.PebBaseAddress;
			}
		}
		((PBYTE)peb)[2] = isBeingDebugged;
	}

	HANDLE rendererHandle = INVALID_HANDLE_VALUE;
	HANDLE hookHandle = INVALID_HANDLE_VALUE;
	DWORD renderThreadId = NULL;
	DWORD hookThreadId = NULL;

	MSG renderMSG = { };
	HWND renderHWND = 0;

	ID2D1HwndRenderTarget* renderTarget = NULL;
	IDWriteFactory* renderFactory = NULL;
	IDWriteTextFormat* renderFormat = NULL;

	HHOOK g_hKeyboardHook;
	HHOOK g_hMouseHook;

	struct Key { bool up, down; }Keys[255];

	class UserInput
	{
	public:
		POINT CursorPos;
		bool LCursorDown, RCursorDown, RCursorUp, LCursorUp;

		bool wasLCursorDown()
		{
			bool results = LCursorDown;
			LCursorDown = false;
			return results;
		}
		bool wasLCursorUp()
		{
			bool results = LCursorUp;
			LCursorUp = false;
			return results;
		}
		bool wasRCursorDown()
		{
			bool results = RCursorDown;
			RCursorDown = false;
			return results;
		}
		bool wasRCursorUp()
		{
			bool results = RCursorUp;
			RCursorUp = false;
			return results;
		}
		bool wasKeyDown(UCHAR vk)
		{
			bool results = Keys[vk].down;
			Keys[vk].down = false;
			return results;
		}
		bool wasKeyUp(UCHAR vk)
		{
			bool results = Keys[vk].up;
			Keys[vk].up = false;
			return results;
		}

		void clearInput()
		{
			CursorPos = { 0 };
			LCursorDown = false;
			RCursorDown = false;
			RCursorUp = false;
			LCursorUp = false;
			for (int i = 0; i < 255; i++)
				Keys[i] = { 0 };
		}

		UserInput()
		{
			clearInput();
		}
	};
	UserInput* hooks = nullptr;

	LRESULT CALLBACK MouseHookProc(int nCode, WPARAM wParam, LPARAM lParam) {
		if (!hooks)
			return CallNextHookEx(g_hMouseHook, nCode, wParam, lParam);
		if (nCode == HC_ACTION) {
			if (wParam == WM_MOUSEMOVE) {
				MSLLHOOKSTRUCT* pMouseInfo = (MSLLHOOKSTRUCT*)lParam;
				hooks->CursorPos = { pMouseInfo->pt.x, pMouseInfo->pt.y };
			}
			else if (wParam == WM_LBUTTONDOWN) {
				hooks->LCursorDown = true;
			}
			else if (wParam == WM_LBUTTONUP) {
				hooks->LCursorUp = true;
			}
			else if (wParam == WM_RBUTTONDOWN) {
				hooks->RCursorDown = true;
			}
			else if (wParam == WM_RBUTTONUP) {
				hooks->RCursorUp = true;
			}
		}
		return CallNextHookEx(g_hMouseHook, nCode, wParam, lParam);
	}

	LRESULT CALLBACK KeyboardHookProc(int nCode, WPARAM wParam, LPARAM lParam) {
		if (!hooks)
			return CallNextHookEx(g_hKeyboardHook, nCode, wParam, lParam);
		if (nCode == HC_ACTION) {
			if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
				KBDLLHOOKSTRUCT* pKeyInfo = (KBDLLHOOKSTRUCT*)lParam;
				Keys[(UCHAR)pKeyInfo->vkCode].down = true;
			}
			else if (wParam == WM_KEYUP || wParam == WM_SYSKEYUP) {
				KBDLLHOOKSTRUCT* pKeyInfo = (KBDLLHOOKSTRUCT*)lParam;
				Keys[(UCHAR)pKeyInfo->vkCode].up = true;
			}
		}

		// Call the next hook in the chain
		return CallNextHookEx(g_hKeyboardHook, nCode, wParam, lParam);
	}
	void HookLoop()
	{
		g_hKeyboardHook = SetWindowsHookExA(WH_KEYBOARD_LL, (HOOKPROC)KeyboardHookProc, NULL, 0);
		g_hMouseHook = SetWindowsHookExA(WH_MOUSE_LL, (HOOKPROC)MouseHookProc, GetModuleHandle(NULL), 0);
		MSG msg;
		GetMessageA(&msg, renderHWND, 0, 0);
	}

	void RenderLoop()
	{
		SYSTEMTIME st;
		GetSystemTime(&st);
		srand(st.wMilliseconds + st.wSecond + st.wMinute + st.wHour + st.wDay + st.wYear);
		int windowTitleSize = 16;
		auto windowTitle = malloc(windowTitleSize);
		memset(windowTitle, 0, windowTitleSize);
		do
		{
			const char* bank = XORS("AZaz09");
			char c = (char)rand();
			if ((c >= bank[0] && c <= bank[1]) || (c >= bank[2] && c <= bank[3]) || (c >= bank[4] && c <= bank[5]))
			{
				*(char*)((unsigned long long)windowTitle + (windowTitleSize - 1)) = c;
				windowTitleSize--;
			}
		} while (windowTitleSize);
		WNDCLASSEXA wc;
		wc.cbSize = sizeof(WNDCLASSEXA);
		wc.lpfnWndProc = DefWindowProc;
		wc.lpszClassName = (LPCSTR)windowTitle;
		RegisterClassExA(&wc);
		if (renderHWND = CreateWindowExA(0, (LPCSTR)windowTitle, 0, WS_POPUP | WS_VISIBLE, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), 0, 0, 0, 0))
		{
			SetCursor(LoadCursorW(NULL, IDC_ARROW));
			DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(&renderFactory));
			ID2D1Factory* factory = NULL;
			D2D1CreateFactory(D2D1_FACTORY_TYPE_MULTI_THREADED, &factory);
			factory->CreateHwndRenderTarget(
				D2D1::RenderTargetProperties(
					D2D1_RENDER_TARGET_TYPE_HARDWARE,
					D2D1::PixelFormat(
						DXGI_FORMAT_UNKNOWN,
						D2D1_ALPHA_MODE_PREMULTIPLIED
					)
				),
				D2D1::HwndRenderTargetProperties(
					renderHWND,
					D2D1::SizeU(
						GetSystemMetrics(SM_CXSCREEN),
						GetSystemMetrics(SM_CYSCREEN)
					),
					D2D1_PRESENT_OPTIONS_IMMEDIATELY
				),
				&renderTarget
			);
			renderFactory->CreateTextFormat(XORS(L"Uni Sans"), NULL, DWRITE_FONT_WEIGHT_NORMAL, DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_STRETCH_NORMAL, 10.0f, XORS(L"en-us"), &renderFormat);
			factory->Release();
			factory = nullptr;

			const MARGINS margins = { -1 ,-1, -1, -1 };
			SetLayeredWindowAttributes(renderHWND, RGB(0, 0, 0), -1, LWA_ALPHA);
			DwmExtendFrameIntoClientArea(renderHWND, &margins);

			SetWindowLong(renderHWND, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_PALETTEWINDOW);
			ShowWindow(renderHWND, SW_SHOW);
			do
			{
				if (renderMSG.message == 0x113)
					break;
				SetWindowPos(renderHWND, nullptr, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
				SetWindowPos(renderHWND, nullptr, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), SWP_NOMOVE | SWP_NOZORDER);
				ShowWindow(renderHWND, SW_RESTORE);
				SetWindowPos(renderHWND, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
				SetWindowPos(renderHWND, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
				Sleep(25);
			} while (GetMessageA(&renderMSG, 0, 0, 0) > 0);
			DestroyWindow(renderHWND);
		}
		free(windowTitle);
	}
};

class fRect
{
private:
#define OperatorRA(op)	fRect operator op	(const  fRect& data) { return { left op data.left			, top op data.top		, right op data.right		, bottom op data.bottom		 };}
#define OperatorRB(op)	fRect operator op= (const fRect& data) { return { left op= data.left			, top op= data.top		, right op= data.right		, bottom op= data.bottom		 };}
#define OperatorPowRA	fRect operator ^	(const  fRect& data) { return { powf(left, data.left)		, powf(top, data.top)	, powf(right, data.right)	, powf(bottom, data.bottom)	 };}
#define OperatorPowRB	fRect operator ^=	(const  fRect& data) { return { left = powf(left, data.left)	, top = powf(top, data.top), right = powf(right, data.right), bottom = powf(bottom, data.bottom) };}
#define VecDefR(op) OperatorRA(op) OperatorRB(op)
#define VecDefPowR OperatorPowRA OperatorPowRB
public:
	float left = 0.f, top = 0.f, right = 0.f, bottom = 0.f;
	fRect() {}
	fRect(const Vec4& data) { left = data.x; top = data.y; right = data.z; bottom = data.w; }
	template <class T1>
	fRect(T1 left) : left(static_cast<float>(left)), top(static_cast<float>(left)), right(static_cast<float>(left)), bottom(static_cast<float>(left)) {}
	template <class T1, class T2, class T3, class T4>
	fRect(T1 left, T2 top, T3 right, T4 bottom) : left(static_cast<float>(left)), top(static_cast<float>(top)), right(static_cast<float>(right)), bottom(static_cast<float>(bottom)) {}
	template <class T1, class T2>
	fRect(T1 lefttop, T2 rightbottom)
	{
		this->left = static_cast<float>(lefttop);
		this->top = static_cast<float>(lefttop);
		this->right = static_cast<float>(rightbottom);
		this->bottom = static_cast<float>(rightbottom);
	}
	fRect(Vec2 lefttop, Vec2 rightbottom)
	{
		this->left = static_cast<float>(lefttop.x);
		this->top = static_cast<float>(lefttop.y);
		this->right = static_cast<float>(rightbottom.x);
		this->bottom = static_cast<float>(rightbottom.y);
	}
	template <class T1>
	fRect(T1 lefttop, Vec2 rightbottom)
	{
		this->left = static_cast<float>(lefttop);
		this->top = static_cast<float>(lefttop);
		this->right = static_cast<float>(rightbottom.x);
		this->bottom = static_cast<float>(rightbottom.y);
	}
	template <class T1>
	fRect(Vec2 lefttop, T1 rightbottom)
	{
		this->left = static_cast<float>(lefttop.x);
		this->top = static_cast<float>(lefttop.y);
		this->right = static_cast<float>(rightbottom);
		this->bottom = static_cast<float>(rightbottom);
	}

	OperatorRA(= );
	VecDefR(+);
	VecDefR(-);
	VecDefR(*);
	VecDefR(/ );
	VecDefPowR;

	Vec2 position()
	{
		return { this->left, this->top };
	}
	Vec2 size()
	{
		return { this->right - this->left, this->bottom - this->top };
	}
	fRect& position(Vec2 point)
	{
		Vec2 s = size();
		*this = { Vec2(point.x, point.y), Vec2(point.x, point.y) + s };
		return *this;
	}
	fRect& size(Vec2 size)
	{
		*this = { Vec2(this->left, this->top), Vec2(this->left, this->top) + Vec2(size.x, size.y) };
		return *this;
	}
};

class Graphics
{
public:
	struct CursorInfo
	{
		Vec2 point = 0;

		bool leftUp = false,
			leftDown = false,
			rightUp = false,
			rightDown = false;

		bool left = false,
			right = false;
	};
	struct KeyboardInfo
	{
		bool Up = false,
			Down = false;
		bool hold = false;
	};

	struct DragableSurface
	{
	private:
		Vec2 oldOrigin = 0;
	public:
		fRect setRect, rect;
		Vec2 offset, origin;
		bool isMoving = false, other;
		DragableSurface() {}
		DragableSurface(fRect rect) : rect(rect) {}

		DragableSurface* anchor(Vec2 point)
		{
			origin = point;
			if (oldOrigin != origin)
			{
				Vec2 differance = origin - oldOrigin;
				rect.left += differance.x;
				rect.top += differance.y;
				rect.right += differance.x;
				rect.bottom += differance.y;
				oldOrigin = origin;
			}
			return this;
		}

		void operator = (const fRect& data) {
			rect = data;
		};
	};

	enum MouseState
	{
		NOTHING,
		HOVERING,
		LEFT_HOLDING,
		LEFT_CLICKING,
		RIGHT_HOLDING,
		RIGHT_CLICKING
	};
private:
	bool focusState = false;
	CursorInfo* cursorInfo = nullptr;
	KeyboardInfo* keyboardInfo[255] = { nullptr };
	void retrieveInput()
	{
		if (!RENDERER::hooks)
			return;
		cursorInfo->point = RENDERER::hooks->CursorPos;
		cursorInfo->leftDown = RENDERER::hooks->wasLCursorDown();
		cursorInfo->leftUp = RENDERER::hooks->wasLCursorUp();
		if (cursorInfo->leftDown)
			cursorInfo->left = true;
		if (cursorInfo->leftUp)
			cursorInfo->left = false;

		cursorInfo->rightDown = RENDERER::hooks->wasRCursorDown();
		cursorInfo->rightUp = RENDERER::hooks->wasRCursorUp();
		if (cursorInfo->rightDown)
			cursorInfo->right = true;
		if (cursorInfo->rightUp)
			cursorInfo->right = false;

		for (int i = 0; i < 255; i++)
		{
			keyboardInfo[i]->Down = RENDERER::hooks->wasKeyDown(i);
			keyboardInfo[i]->Up = RENDERER::hooks->wasKeyUp(i);
			if (keyboardInfo[i]->Down)
				keyboardInfo[i]->hold = true;
			if (keyboardInfo[i]->Up)
				keyboardInfo[i]->hold = false;
		}
	}
public:
	fRect canvas;
	Vec2 canvasSize;

	void begin();
	void end();
	void toggleFocus();
	bool getFocus() { return focusState; }
	CursorInfo* getCursor();
	KeyboardInfo* getKey(UCHAR vk);
	MouseState captureMouse(fRect rect, bool dbg = false);
	bool captureKeyboard(fRect rect, float size, float padding, fColor color, char* words, const char* defaultText, bool* active);

	fRect textRect(Vec2 point, TextCenter center, float size, float padding, const wchar_t* format, ...);
	fRect textRect(Vec2 point, TextCenter center, float size, float padding, const char* format, ...);
	void text(Vec2 point, TextCenter center, float size, float padding, fColor color, const wchar_t* format, ...);
	void text(Vec2 point, TextCenter center, float size, float padding, fColor color, const char* format, ...);
	void text(fRect rect, float size, float padding, fColor color, const wchar_t* format, ...);
	void text(fRect rect, float size, float padding, fColor color, const char* format, ...);

	void text2(Vec2 point, TextCenter center, float size, float padding, fColor color, const char* format, ...);
	void text2(Vec2 point, TextCenter center, float size, float padding, fColor color, const wchar_t* format, ...);

	void line(Vec2 p1, Vec2 p2, float thickness, fColor color);
	void line2(Vec2 p1, Vec2 p2, float thickness, fColor color);
	void rect(fRect rect, Vec2 roundness, fColor bkgColor);
	void rect(fRect rect, Vec2 roundness, fColor bkgColor, fColor edgeColor, float thickness = 1.f);
	void circle(Vec2 point, Vec2 size, fColor bkgColor, bool outline = false, fColor olnColor = CLEAR, float thickness = 1.f);

	DragableSurface* dragable(DragableSurface* surface, bool dbg = false);

	Graphics()
	{
		RENDERER::hooks = new RENDERER::UserInput();
		canvas = { 0,0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN) };
		canvasSize = Vec2(canvas.right, canvas.bottom);
		RENDERER::rendererHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)RENDERER::RenderLoop, 0, 0, &RENDERER::renderThreadId);
		while (RENDERER::renderMSG.message != 0xf) { Sleep(5); }
		RENDERER::hookHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)RENDERER::HookLoop, 0, 0, &RENDERER::hookThreadId);
		RENDERER::hooks->clearInput();
		RENDERER::SetDebugBit(true);

		cursorInfo = new CursorInfo();
		for (int i = 0; i < 255; i++)
			keyboardInfo[i] = new KeyboardInfo();
	}
	~Graphics()
	{
		SendMessageA(RENDERER::renderHWND, WM_CLOSE, 0, 0);
		WaitForSingleObject(RENDERER::rendererHandle, INFINITE);
		CloseHandle(RENDERER::rendererHandle);
		UnhookWindowsHookEx(RENDERER::g_hKeyboardHook);
		UnhookWindowsHookEx(RENDERER::g_hMouseHook);
		TerminateThread(RENDERER::hookHandle, 0);
		WaitForSingleObject(RENDERER::hookHandle, INFINITE);
		CloseHandle(RENDERER::hookHandle);
		delete RENDERER::hooks;

		delete cursorInfo;
		for (int i = 0; i < 255; i++)
			delete keyboardInfo[i];
	}
};

inline void Graphics::begin()
{
	Graphics::retrieveInput();
	RENDERER::renderTarget->BeginDraw();
	RENDERER::renderTarget->Clear(D2D1::ColorF(0, 0, 0, 0));
}

inline void Graphics::end()
{
	RENDERER::renderTarget->EndDraw();
}

inline void Graphics::toggleFocus()
{
	if (!RENDERER::hooks)
		return;
	RENDERER::hooks->clearInput();
	if (focusState = !focusState)
	{
		SetWindowLongA(RENDERER::renderHWND, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_PALETTEWINDOW);
		while (GetForegroundWindow() != RENDERER::renderHWND)
			SetForegroundWindow(RENDERER::renderHWND);
	}
	else
		SetWindowLongA(RENDERER::renderHWND, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_PALETTEWINDOW);
}

inline Graphics::CursorInfo* Graphics::getCursor()
{
	return cursorInfo;
}

inline Graphics::KeyboardInfo* Graphics::getKey(UCHAR vk)
{
	return keyboardInfo[vk];
}

inline Graphics::MouseState Graphics::captureMouse(fRect rect, bool dbg)
{
	if (cursorInfo->point.x >= rect.left && cursorInfo->point.y >= rect.top && cursorInfo->point.x < rect.right && cursorInfo->point.y < rect.bottom)
	{
		if (cursorInfo->leftDown)
			return MouseState::LEFT_CLICKING;
		else if (cursorInfo->left)
			return MouseState::LEFT_HOLDING;
		if (cursorInfo->rightDown)
			return MouseState::RIGHT_CLICKING;
		else if (cursorInfo->right)
			return MouseState::RIGHT_HOLDING;
		return MouseState::HOVERING;
	}
	if (dbg)
		Graphics::rect(rect, 0, { 1, 1, 1, 0.3f });
	return MouseState::NOTHING;
}

inline bool Graphics::captureKeyboard(fRect rect, float size, float padding, fColor color, char* words, const char* defaultText, bool* active)
{
	if (Graphics::captureMouse(rect) == LEFT_CLICKING)
		*active = true;
	else if (cursorInfo->leftDown)
		*active = false;
	short txtSize = 0;
	for (txtSize = 0; words[txtSize] != 0; txtSize++);
	if (txtSize)
		text(rect.position() + Vec2(0, rect.size().y / 2), CENTERLEFT, rect.size().y * .8f, 0, color, (const char*)words);
	else
		text(rect.position() + Vec2(0, rect.size().y / 2), CENTERLEFT, rect.size().y * .8f, 0, { color.r, color.g, color.b, 0.3f }, defaultText);
	if (!*active)
		return false;
	if (getKey(VK_BACK)->Down && txtSize) { words[txtSize - 1] = 0x0; };
	if (getKey(VK_SPACE)->Down) { words[txtSize] = ' '; }
	if (getKey(VK_OEM_MINUS)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '-' : '_'; }
	if (getKey(VK_OEM_PLUS)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '=' : '+'; }
	if (getKey(VK_OEM_COMMA)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? ',' : '<'; }
	if (getKey(VK_OEM_PERIOD)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '.' : '>'; }
	if (getKey(VK_OEM_1)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? ';' : ':'; }
	if (getKey(VK_OEM_2)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '/' : '?'; }
	if (getKey(VK_OEM_3)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '`' : '~'; }
	if (getKey(VK_OEM_4)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '[' : '{'; }
	if (getKey(VK_OEM_5)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '\\' : '|'; }
	if (getKey(VK_OEM_6)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? ']' : '}'; }
	if (getKey(VK_OEM_7)->Down) { words[txtSize] = !getKey(VK_LSHIFT)->hold ? '\'' : '"'; }

	for (UCHAR vk = 0x30; vk <= 0x5A; vk++)
	{
		if (getKey(VK_LSHIFT)->hold)
		{
			if (getKey(vk)->Down)
			{
				if (vk > 0x39)
					words[txtSize] = vk;
				else
				{
					switch (vk)
					{
					case '1': {words[txtSize] = '!'; break; }
					case '2': {words[txtSize] = '@'; break; }
					case '3': {words[txtSize] = '#'; break; }
					case '4': {words[txtSize] = '$'; break; }
					case '5': {words[txtSize] = '%'; break; }
					case '6': {words[txtSize] = '^'; break; }
					case '7': {words[txtSize] = '&'; break; }
					case '8': {words[txtSize] = '*'; break; }
					case '9': {words[txtSize] = '('; break; }
					case '0': {words[txtSize] = ')'; break; }
					}
				}
			}
		}
		else
		{
			if (getKey(vk)->Down)
			{
				if (vk > 0x39)
					words[txtSize] = (vk + 0x20);
				else
					words[txtSize] = vk;
			}

		}
	}
	if (getKey(VK_RETURN)->Down)
		return true;
	return false;
}

inline fRect Graphics::textRect(Vec2 point, TextCenter center, float size, float padding, const wchar_t* format, ...)
{
	wchar_t* buffer = (wchar_t*)malloc(0xFF * 0x2);
	if (buffer == NULL || format == NULL)
		return fRect();
	memset(buffer, 0, 0xFF * 0x2);
	va_list args;
	va_start(args, format);
	int written = _vsnwprintf_s(buffer, 0xFF * 0x2, 0xFF, format, args);

	va_end(args);

	if (written < 0 || written >= 0xFF)
		return fRect();

	short txtSize = 0;
	for (txtSize = 0; buffer[txtSize] != 0; buffer[txtSize] = buffer[txtSize], txtSize++);

	IDWriteTextLayout* w_layout = NULL;
	if (SUCCEEDED(RENDERER::renderFactory->CreateTextLayout(buffer, txtSize, RENDERER::renderFormat, canvas.right, canvas.bottom, &w_layout)))
	{
		DWRITE_TEXT_RANGE range = { 0, (UINT32)txtSize };
		DWRITE_TEXT_METRICS textMetrics;

		w_layout->SetFontSize(size, range);
		w_layout->GetMetrics(&textMetrics);
		w_layout->Release();
		Vec2 p = { textMetrics.left, textMetrics.top },
			s = { textMetrics.width, textMetrics.height };

		p += point;
		p += (padding * 0.5f);
		s += padding;

		switch (center)
		{
		case TOPCENTER:
			p -= Vec2(s.x * 0.5f, s.y * 0.0f);
			break;
		case TOPLEFT:
			p -= Vec2(s.x * 0.0f, s.y * 0.0f);
			break;
		case TOPRIGHT:
			p -= Vec2(s.x * 1.0f, s.y * 0.0f);
			break;
		case CENTER:
			p -= Vec2(s.x * 0.5f, s.y * 0.5f);
			break;
		case CENTERLEFT:
			p -= Vec2(s.x * 0.0f, s.y * 0.5f);
			break;
		case CENTERRIGHT:
			p -= Vec2(s.x * 1.0f, s.y * 0.5f);
			break;
		case BOTTOMCENTER:
			p -= Vec2(s.x * 0.5f, s.y * 1.0f);
			break;
		case BOTTOMLEFT:
			p -= Vec2(s.x * 0.0f, s.y * 1.0f);
			break;
		case BOTTOMRIGHT:
			p -= Vec2(s.x * 1.0f, s.y * 1.0f);
			break;
		default:
			break;
		};
		free(buffer);
		return { p, p + s };
	}
	free(buffer);
	return fRect();
}

inline fRect Graphics::textRect(Vec2 point, TextCenter center, float size, float padding, const char* format, ...)
{
	char* buffer = (char*)malloc(0xFF);
	memset(buffer, 0, 0xFF);
	if (!buffer)
		return fRect();
	va_list args;
	va_start(args, format);
	int written = vsnprintf(buffer, 0xFF, format, args);

	va_end(args);

	wchar_t* wbuffer = (wchar_t*)malloc(0xFF * 0x2);
	memset(wbuffer, 0, 0xFF * 0x2);
	if (!wbuffer)
		return fRect();
	for (short txtSize = 0; buffer[txtSize] != 0; wbuffer[txtSize] = buffer[txtSize], txtSize++);

	fRect results = Graphics::textRect(point, center, size, padding, wbuffer);
	free(wbuffer);
	free(buffer);
	return results;
}

inline void Graphics::text(Vec2 point, TextCenter center, float size, float padding, fColor color, const wchar_t* format, ...)
{
	wchar_t* buffer = (wchar_t*)malloc(0xFF * 0x2);
	if (buffer == NULL)
		return;
	if (format == NULL)
	{
		free(buffer);
		return;
	}
	memset(buffer, 0, 0xFF * 0x2);
	va_list args;
	va_start(args, format);
	int written = _vsnwprintf_s(buffer, 0xFF * 0x2, 0xFF, format, args);

	va_end(args);

	if (written < 0 || written >= 0xFF)
	{
		free(buffer);
		return;
	}

	short txtSize = 0;
	for (txtSize = 0; buffer[txtSize] != 0; buffer[txtSize] = buffer[txtSize], txtSize++);

	ID2D1SolidColorBrush* solid_brush = NULL;
	IDWriteTextLayout* w_layout = NULL;
	if (SUCCEEDED(RENDERER::renderFactory->CreateTextLayout(buffer, txtSize, RENDERER::renderFormat, canvas.right, canvas.bottom, &w_layout)))
	{
		DWRITE_TEXT_RANGE range = { 0, (UINT32)txtSize };
		DWRITE_TEXT_METRICS textMetrics;

		w_layout->SetFontSize(size, range);
		w_layout->GetMetrics(&textMetrics);

		Vec2 p = { textMetrics.left, textMetrics.top },
			s = { textMetrics.width, textMetrics.height };

		p += point;
		p += (padding * 0.5f);
		s += padding;

		switch (center)
		{
		case TOPCENTER:
			p -= Vec2(s.x * 0.5f, s.y * 0.0f);
			break;
		case TOPLEFT:
			p -= Vec2(s.x * 0.0f, s.y * 0.0f);
			break;
		case TOPRIGHT:
			p -= Vec2(s.x * 1.0f, s.y * 0.0f);
			break;
		case CENTER:
			p -= Vec2(s.x * 0.5f, s.y * 0.5f);
			break;
		case CENTERLEFT:
			p -= Vec2(s.x * 0.0f, s.y * 0.5f);
			break;
		case CENTERRIGHT:
			p -= Vec2(s.x * 1.0f, s.y * 0.5f);
			break;
		case BOTTOMCENTER:
			p -= Vec2(s.x * 0.5f, s.y * 1.0f);
			break;
		case BOTTOMLEFT:
			p -= Vec2(s.x * 0.0f, s.y * 1.0f);
			break;
		case BOTTOMRIGHT:
			p -= Vec2(s.x * 1.0f, s.y * 1.0f);
			break;
		default:
			break;
		};
		RENDERER::renderTarget->CreateSolidColorBrush(D2D1::ColorF(color.r, color.g, color.b, color.a), &solid_brush);
		if (solid_brush)
		{
			if (canvas.left >= p.x || canvas.right <= p.y || canvas.top > p.x || canvas.bottom < p.y)
			{
				w_layout->Release();
				solid_brush->Release();
				free(buffer);
				return;
			}
			RENDERER::renderTarget->DrawTextLayout(D2D1::Point2F(p.x, p.y), w_layout, solid_brush);
			solid_brush->Release();
		}
		w_layout->Release();
	}
	free(buffer);
	return;
}




inline void Graphics::text2(Vec2 point, TextCenter center, float size, float padding, fColor color, const char* format, ...)
{
	char* buffer = (char*)malloc(0xFF);
	if (!buffer)
		return;
	memset(buffer, 0, 0xFF);
	va_list args;
	va_start(args, format);
	int written = vsnprintf(buffer, 0xFF, format, args);

	va_end(args);
	if (color.a == 1.f)
	{
		Graphics::text({ point.x - 1, point.y }, center, size, padding, BLACK, buffer);
		Graphics::text({ point.x + 1, point.y }, center, size, padding, BLACK, buffer);
		Graphics::text({ point.x, point.y - 1 }, center, size, padding, BLACK, buffer);
		Graphics::text({ point.x, point.y + 1 }, center, size, padding, BLACK, buffer);
	}
	else
	{
		Graphics::text({ point.x - 1, point.y }, center, size, padding, {0,0,0,color.a / 2}, buffer);
		Graphics::text({ point.x + 1, point.y }, center, size, padding, {0,0,0,color.a / 2}, buffer);
		Graphics::text({ point.x, point.y - 1 }, center, size, padding, {0,0,0,color.a / 2}, buffer);
		Graphics::text({ point.x, point.y + 1 }, center, size, padding, {0,0,0,color.a / 2}, buffer);
	}
	
	Graphics::text({ point.x, point.y }, center, size, padding, color, buffer);
	free(buffer);
}

inline void Graphics::text2(Vec2 point, TextCenter center, float size, float padding, fColor color, const wchar_t* format, ...)
{
	wchar_t* buffer = (wchar_t*)malloc(0xFF * 0x2);
	if (!buffer)
		return;
	memset(buffer, 0, 0xFF * 0x2);
	va_list args;
	va_start(args, format);
	int written = _vsnwprintf_s(buffer, 0xFF * 0x2, 0xFF, format, args);

	va_end(args);
	Graphics::text({ point.x - 1, point.y }, center, size, padding, BLACK, buffer);
	Graphics::text({ point.x + 1, point.y }, center, size, padding, BLACK, buffer);
	Graphics::text({ point.x, point.y - 1 }, center, size, padding, BLACK, buffer);
	Graphics::text({ point.x, point.y + 1 }, center, size, padding, BLACK, buffer);
	Graphics::text({ point.x, point.y }, center, size, padding, color, buffer);
	free(buffer);
}

inline void Graphics::text(Vec2 point, TextCenter center, float size, float padding, fColor color, const char* format, ...)
{
	char* buffer = (char*)malloc(0xFF);
	memset(buffer, 0, 0xFF);
	if (!buffer)
		return;
	va_list args;
	va_start(args, format);
	int written = vsnprintf(buffer, 0xFF, format, args);

	va_end(args);

	wchar_t* wbuffer = (wchar_t*)malloc(0xFF * 0x2);
	memset(wbuffer, 0, 0xFF * 0x2);
	if (!wbuffer)
		return;
	for (short txtSize = 0; buffer[txtSize] != 0; wbuffer[txtSize] = buffer[txtSize], txtSize++);

	Graphics::text(point, center, size, padding, color, wbuffer);
	free(wbuffer);
	free(buffer);
}

inline void Graphics::text(fRect rect, float size, float padding, fColor color, const wchar_t* format, ...)
{
	wchar_t* buffer = (wchar_t*)malloc(0xFF * 0x2);
	memset(buffer, 0, 0xFF * 0x2);
	if (buffer == NULL || format == NULL)
		return;

	va_list args;
	va_start(args, format);
	int written = _vsnwprintf_s(buffer, 0xFF * 0x2, 0xFF, format, args);

	va_end(args);

	if (written < 0 || written >= 0xFF)
		return;

	short txtSize = 0;
	for (txtSize = 0; buffer[txtSize] != 0; buffer[txtSize] = buffer[txtSize], txtSize++);

	ID2D1SolidColorBrush* solid_brush = NULL;
	IDWriteTextLayout* w_layout = NULL;
	if (SUCCEEDED(RENDERER::renderFactory->CreateTextLayout(buffer, txtSize, RENDERER::renderFormat, canvas.right, canvas.bottom, &w_layout)))
	{

		Vec2 p = { rect.left, rect.top };
		p += (padding * 0.5f);

		RENDERER::renderTarget->CreateSolidColorBrush(D2D1::ColorF(color.r, color.g, color.b, color.a), &solid_brush);
		if (solid_brush)
		{
			DWRITE_TEXT_RANGE range = { 0, (UINT32)txtSize };
			w_layout->SetFontSize(size, range);
			RENDERER::renderTarget->DrawTextLayout(D2D1::Point2F(p.x, p.y), w_layout, solid_brush);
			solid_brush->Release();
		}
		w_layout->Release();
	}
	free(buffer);
	return;
}

inline void Graphics::text(fRect rect, float size, float padding, fColor color, const char* format, ...)
{
	char* buffer = (char*)malloc(0xFF);
	memset(buffer, 0, 0xFF);
	if (!buffer)
		return;
	va_list args;
	va_start(args, format);
	int written = vsnprintf(buffer, 0xFF, format, args);

	va_end(args);

	wchar_t* wbuffer = (wchar_t*)malloc(0xFF * 0x2);
	memset(wbuffer, 0, 0xFF * 0x2);
	if (!wbuffer)
		return;
	for (short txtSize = 0; buffer[txtSize] != 0; wbuffer[txtSize] = buffer[txtSize], txtSize++);

	Graphics::text({ rect.left, rect.top }, TOPLEFT, size, padding, color, wbuffer);
	free(wbuffer);
	free(buffer);
}

inline void Graphics::line(Vec2 p1, Vec2 p2, float thickness, fColor color)
{
	if (canvas.left >= p1.x || canvas.right <= p1.x || canvas.top > p1.y || canvas.bottom < p1.y)
		return;
	if (canvas.left >= p2.x || canvas.right <= p2.x || canvas.top > p2.y || canvas.bottom < p2.y)
		return;
	ID2D1SolidColorBrush* solid_brush = NULL;
	RENDERER::renderTarget->CreateSolidColorBrush(D2D1::ColorF(color.r, color.g, color.b, color.a), &solid_brush);
	if (solid_brush)
		RENDERER::renderTarget->DrawLine(D2D1::Point2F(p1.x, p1.y), D2D1::Point2F(p2.x, p2.y), solid_brush, thickness);
	solid_brush->Release();
}

inline void Graphics::line2(Vec2 p1, Vec2 p2, float thickness, fColor color)
{
	Graphics::line(p1, p2, thickness + 2, color.complementary());
	Graphics::line(p1, p2, thickness, color);
	Graphics::rect({ p1- (thickness / 2), p1 + (thickness / 2) }, (thickness / 2), color);
	Graphics::rect({ p2 - (thickness / 2), p2 + (thickness / 2) }, (thickness / 2), color);
}

inline void Graphics::rect(fRect rect, Vec2 roundness, fColor bkgColor)
{
	Vec2 size = rect.size();
	if (canvas.left > rect.left + size.x || canvas.right <= rect.right - size.x || canvas.top > rect.top + size.y || canvas.bottom <= rect.bottom - size.y)
		return;
	ID2D1SolidColorBrush* solid_brush = NULL;
	D2D1_RECT_F r = D2D1::RectF(rect.left, rect.top, rect.right, rect.bottom);
	if (bkgColor.a)
	{
		RENDERER::renderTarget->CreateSolidColorBrush(D2D1::ColorF(bkgColor.r, bkgColor.g, bkgColor.b, bkgColor.a), &solid_brush);
		if (solid_brush)
		{
			RENDERER::renderTarget->FillRoundedRectangle(D2D1::RoundedRect(r, roundness.x, roundness.y), solid_brush);
			solid_brush->Release();
		}
	}
}

inline void Graphics::rect(fRect rect, Vec2 roundness, fColor bkgColor, fColor edgeColor, float thickness)
{
	ID2D1SolidColorBrush* solid_brush = NULL;
	D2D1_RECT_F r1 = D2D1::RectF(rect.left, rect.top, rect.right, rect.bottom);
	D2D1_RECT_F r2 = D2D1::RectF(
		rect.left + thickness,
		rect.top + thickness,
		rect.right - thickness,
		rect.bottom - thickness
	);
	if (bkgColor.a)
	{
		RENDERER::renderTarget->CreateSolidColorBrush(D2D1::ColorF(edgeColor.r, edgeColor.g, edgeColor.b, edgeColor.a), &solid_brush);
		if (solid_brush)
		{
			RENDERER::renderTarget->FillRoundedRectangle(D2D1::RoundedRect(r1, roundness.x, roundness.y), solid_brush);
			solid_brush->SetColor(D2D1::ColorF(bkgColor.r, bkgColor.g, bkgColor.b, bkgColor.a));
			RENDERER::renderTarget->FillRoundedRectangle(D2D1::RoundedRect(r2, roundness.x, roundness.y), solid_brush);
			solid_brush->Release();
		}
	}
}

inline Graphics::DragableSurface* Graphics::dragable(Graphics::DragableSurface* surface, bool dbg)
{
	if (surface->isMoving)
	{
		surface->rect = fRect(
			surface->setRect.left - (surface->offset.x - (cursorInfo->point.x + surface->origin.x)),
			surface->setRect.top - (surface->offset.y - (cursorInfo->point.y + surface->origin.y)),
			surface->setRect.right - (surface->offset.x - (cursorInfo->point.x + surface->origin.x)),
			surface->setRect.bottom - (surface->offset.y - (cursorInfo->point.y + surface->origin.y))
		);
		if (captureMouse(surface->rect) == MouseState::HOVERING)
			surface->isMoving = false;
	}
	else if (captureMouse(surface->rect) == MouseState::LEFT_CLICKING)
	{
		surface->setRect = surface->rect;
		surface->offset = cursorInfo->point + surface->origin;
		surface->isMoving = true;
	}
	if (dbg)
		Graphics::rect(surface->rect, 0, { 1, 1, 1, 0.3 });
	return surface;
}

inline void Graphics::circle(Vec2 point, Vec2 size, fColor bkgColor, bool outline, fColor olnColor, float thickness)
{
	fRect rect = fRect().position(point).size(size);
	if (bkgColor != CLEAR)
	{
		Graphics::rect(rect, size, bkgColor);
	}
	if (outline && olnColor != CLEAR)
	{
		ID2D1SolidColorBrush* solid_brush = NULL;
		RENDERER::renderTarget->CreateSolidColorBrush(D2D1::ColorF(olnColor.r, olnColor.g, olnColor.b, olnColor.a), &solid_brush);
		D2D1_RECT_F r1 = D2D1::RectF(rect.left, rect.top, rect.right, rect.bottom);
		if (solid_brush)
		{
			RENDERER::renderTarget->DrawRoundedRectangle(D2D1::RoundedRect(r1, size.x, size.y), solid_brush);
			solid_brush->Release();
		}
	}
}