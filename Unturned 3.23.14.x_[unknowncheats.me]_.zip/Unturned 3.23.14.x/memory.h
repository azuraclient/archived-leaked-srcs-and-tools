#pragma once
#include <tlhelp32.h>
#include <string>
#include <vector>

#include "driver.h"

typedef unsigned long long QWORD;

namespace memory
{
	kernel::driver* driver = nullptr;
};

bool read(IN QWORD va, OUT PBYTE pb, IN DWORD bs)
{
	if (!memory::driver)
		return false;
	return memory::driver->read_buffer(va, pb, bs);
}

template <class AUTO>
AUTO read(IN QWORD va)
{
	AUTO results = { 0 };
	if (!va)
		return results;
	if (!read(va, (PBYTE)&results, sizeof(AUTO)))
		return { 0 };
	return results;
}
template <>
std::string read(IN QWORD va)
{
	if (!va)
		return { 0 };
	char buffer[MAX_PATH * sizeof(char)] = {0x0};
	if (!read(va, (PBYTE)buffer, (DWORD)MAX_PATH * sizeof(char)))
		return "";
	return std::string(buffer);
}
template <>
std::wstring read(IN QWORD va)
{
	if (!va)
		return { 0 };
	wchar_t buffer[MAX_PATH * sizeof(wchar_t)] = { 0x0 };
	if (!read(va, (PBYTE)buffer, (DWORD)MAX_PATH * sizeof(wchar_t)))
		return L"";
	return std::wstring(buffer);
}
template <class AUTO>
AUTO read(IN std::vector<QWORD> vac)
{
	uint64_t addr = 0x0;
	for (DWORD i = 0; i < vac.size() - 1; i++)
		addr = read<uint64_t>(addr + vac.at(i));
	AUTO results;
	read((uint64_t)(addr + vac.at(vac.size() - 1)), (PBYTE)&results, sizeof(AUTO));
	return results;
}

bool write(IN QWORD va, IN PBYTE pb, IN DWORD bs)
{
	if (!memory::driver)
		return false;
	return memory::driver->write_buffer(va, pb, bs);
}


template <class AUTO>
bool write(IN QWORD va, AUTO data)
{
	if (!va)
		return false;
	if (!write(va, (PBYTE)&data, sizeof(AUTO)))
		return false;
	return true;
}
template <class AUTO>
bool write(IN std::vector<QWORD> vac, AUTO data)
{
	uint64_t addr = 0x0;
	for (DWORD i = 0; i < vac.size() - 1; i++)
		addr = read<uint64_t>(addr + vac.at(i));
	if (!addr)
		return false;
	return write((uint64_t)(addr + vac.at(vac.size() - 1)), (PBYTE)&data, sizeof(AUTO));
}

unsigned char getProcessCount(const wchar_t* name)
{
	unsigned char results = 0;
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32W entry;
	entry.dwSize = sizeof(entry);
	if (Process32FirstW(hSnapshot, &entry)) {
		do {
			if (!lstrcmpW(name, entry.szExeFile))
				results++;
		} while (Process32Next(hSnapshot, &entry));
	}
	return results;
}

SHORT findProcess(const wchar_t* name, unsigned char count = 0)
{
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32W entry;
	entry.dwSize = sizeof(entry);
	if (Process32FirstW(hSnapshot, &entry)) {
		do {
			if (!lstrcmpW(name, entry.szExeFile))
			{
				if(!count)
					return (SHORT)entry.th32ProcessID;
				count--;
			}
		} while (Process32Next(hSnapshot, &entry));
	}
	return 0;
}

QWORD modBase(SHORT pid, const char* name)
{
	if (!memory::driver)
		return 0x0;
	memory::driver->attach(pid);
	return memory::driver->get_process_module(name);
}

bool memory_init()
{
	if (!memory::driver)
	{
		memory::driver = new kernel::driver();
		return memory::driver->init();
	}
	else
	{
		return memory::driver->init();
	}
}
