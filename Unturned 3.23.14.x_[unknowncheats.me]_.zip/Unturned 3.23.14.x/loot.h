#pragma once
#define clamp(data, min, max)if (data < min){ data = min; } else if (data > max) { data = max; }

class ItemList
{
public:
    struct Item
    {
        Vec3 position;
        float distance;
        std::wstring _itemName;
        byte amount, quality;
        WORD type, rarity;
    };
private:
    unity::Matrix* matrix;
    Vec2 WorldToScreen(Vec3 WorldPos)
    {
        if (WorldPos == 0)
            return -1;
        float width = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(WorldPos) + matrix->translation.w;
        Vec2 pos = Vec2(Vec3(matrix->right.x, matrix->up.x, matrix->forward.x).dot(WorldPos) + matrix->translation.x, Vec3(matrix->right.y, matrix->up.y, matrix->forward.y).dot(WorldPos) + matrix->translation.y);
        if (width < 0.098)
            return -1;
        Vec2 point = Vec2((draw->canvasSize.x / 2) * (1 + pos.x / width), (draw->canvasSize.y / 2) * (1 - pos.y / width));
        if (point.x > 0 && point.y > 0 && point.x < draw->canvasSize.x && point.y < draw->canvasSize.y)
            return point;
        return -1;
    }

    Graphics* draw = nullptr;
    std::vector<Item> items;

public:

    void begin()
    {
        items.resize(0);
    }

    void update(Vec3 cameraPos)
    {
        auto regions = ItemManager->regions();
        items.clear();

        for (auto region : regions)
        {
            auto _drops = region->_drops();

            for (int Index = 0; Index < _drops.size(); Index++)
            {
                Item item = { 0 };
                SDK::ItemDrop* itemDrops = _drops.at(Index);
                if (!itemDrops)
                    continue;
                item.position = itemDrops->_model()->child(0)->position();
                item.distance = item.position.distance(cameraPos);
                if (item.distance > Settings::Loot::renderDistance * 400.f)
                    continue;
                auto _interactableItem = itemDrops->_interactableItem();
                auto asset = _interactableItem->asset();
                auto _item = _interactableItem->item();

                
                item._itemName = asset->_itemName();
                item.rarity = asset->rarity();
                item.type = asset->type();
                item.amount = _item->amount();
                item.quality = _item->quality();
                items.push_back(item);

                for (int index = 0; index < items.size(); index++)
                {
                    if (items.at(index).distance > item.distance)
                    {
                        items.insert(items.begin() + index, item);
                        items.pop_back();
                        break;
                    }
                }
            }
        }
    }

    void render(unity::Matrix* matrix)
    {
        this->matrix = matrix;

        for (int index = (int)items.size() - 1; index >= 0; index--)
        {
            auto item = items.at(index);
            if (!item.distance)
                continue;

            float scale = Vec3(matrix->right.w, matrix->up.w, matrix->forward.w).dot(item.position) + matrix->translation.w;
            clamp(scale, 1.f, 10.f);

            if ((item.type == SDK::EItemType::MAGAZINE || (item.type == SDK::EItemType::SUPPLY && item._itemName.find(XORS(L"Caliber")) != std::string::npos)) && item.amount)
                draw->text2(WorldToScreen(item.position) + Vec2(0, 95.f / scale), CENTER, 95.f / scale, 0, { 0.42f, 0.48f, 0.31f, 1.0f }, XORS(L"%s [%i] %.1fm"), item._itemName.c_str(), item.amount, item.distance);
            else if (item.type == SDK::EItemType::GUN)
                draw->text2(WorldToScreen(item.position) + Vec2(0, 95.f / scale), CENTER, 95.f / scale, 0, { 0.42f, 1.f, 0.31f, 1.0f }, XORS(L"%s [%i%s] %.1fm"), item._itemName.c_str(), item.quality, L"%%", item.distance);
            else if (item.type == SDK::EItemType::MELEE && (item._itemName._Equal(XORS(L"Jackhammer")) || item._itemName._Equal(XORS(L"Chainsaw"))))
                draw->text2(WorldToScreen(item.position) + Vec2(0, 95.f / scale), CENTER, 95.f / scale, 0, { 0.31f, 0.31f, 0.31f, 1.0f }, XORS(L"%s [%i%s] %.1fm"), item._itemName.c_str(), item.quality, L"%%", item.distance);
            else if (item.type == SDK::EItemType::FILTER || item.type == SDK::EItemType::CHARGE || item.type == SDK::EItemType::DETONATOR || (item._itemName.find(XORS(L"Grenade")) != std::string::npos) || item._itemName._Equal(XORS(L"Raw Explosives")))
                draw->text2(WorldToScreen(item.position) + Vec2(0, 95.f / scale), CENTER, 12.f, 0, RED, XORS(L"%s [%i%s] %.1fm"), item._itemName.c_str(), item.quality, L"%%", item.distance);
            else if (item.rarity >= SDK::EItemRarity::EPIC || item.type == SDK::EItemType::GRIP || item.type == SDK::EItemType::BARREL)
                draw->text2(WorldToScreen(item.position) + Vec2(0, 95.f / scale), CENTER, 12.f, 0, { 0.65,0.47,0.86,1 }, XORS(L"%s [%i%s] %.1fm"), item._itemName.c_str(), item.quality, L"%%", item.distance);
            else if (item._itemName._Equal(XORS(L"Bricks")))
                draw->text2(WorldToScreen(item.position) + Vec2(0, 95.f / scale), CENTER, 12.f, 0, { 0.65,0.47,0.86,1 }, XORS(L"%s %.1fm"), item._itemName.c_str(), item.distance);
        }
    }

    void end()
    {
        
    }

    ItemList(Graphics* draw) { this->draw = draw; items.resize(0); }
};
#undef clamp