import sys
import subprocess
import os

def _install_prerequisites():
    packages = [
        ("tkinterdnd2", "tkinterdnd2"),
        ("PIL",         "Pillow"),
    ]
    needs_install = []
    for import_name, pkg_name in packages:
        try:
            __import__(import_name)
        except ImportError:
            needs_install.append((import_name, pkg_name))

    if not needs_install:
        return

    print("=" * 52)
    print("  WeAreDevs Deobfuscator — First-time Setup")
    print("=" * 52)
    print()
    print("  Installing required packages.")
    print("  This only happens once. Nothing suspicious")
    print("  is being downloaded — just Python libraries.")
    print()

    for import_name, pkg_name in needs_install:
        print(f"  [ ... ]  Installing {pkg_name}...", end="", flush=True)
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", pkg_name, "--quiet"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            print(f"\r  [  OK  ]  {pkg_name} installed successfully.      ")
        except Exception as e:
            print(f"\r  [ FAIL ]  Could not install {pkg_name}: {e}")

    print()
    print("  Setup complete. Starting application...")
    print("=" * 52)
    print()

_install_prerequisites()

import re
import time
import glob
import math

OUTPUT_FOLDER = "deobfuscated"


def deobfuscate_text(content, save_name=None):
    print("Processing pasted content...")
    _run_deobfuscation(content, "<pasted>", save_name)


def _run_deobfuscation(content, source_label, save_name=None):
    match = re.search(r'local ([a-zA-Z0-9_]+)=\{"', content)
    if not match:
        print(f"Could not identify string table variable in {source_label}.")
        return
    var_name = match.group(1)

    mock_env_code = r"""
local real_type = type
local real_tonumber = tonumber
local real_unpack = unpack
local real_concat = table.concat
local real_tostring = tostring
local real_print = print

local _LOOP_COUNTER = 0
local _MAX_LOOPS = 150
local _LOOP_BODIES = {}

local function _check_loop()
    _LOOP_COUNTER = _LOOP_COUNTER + 1
    if _LOOP_COUNTER > _MAX_LOOPS then
        return false
    end
    return true
end

local function type(v)
    local mt = getmetatable(v)
    if mt and mt.__is_mock_dummy then
        return "userdata"
    end
    return real_type(v)
end

local function typeof(v)
    local mt = getmetatable(v)
    if mt and mt.__is_mock_dummy then
        return "Instance"
    end
    return type(v)
end

local function tonumber(v, base)
    if type(v) == "userdata" or (type(v) == "table" and getmetatable(v) and getmetatable(v).__is_mock_dummy) then
        return 1
    end
    return real_tonumber(v, base)
end

local function unpack(t, i, j)
    if real_type(t) == "table" then
        local looks_like_chunk = true
        for k, v in pairs(t) do
            if real_type(k) ~= "number" then looks_like_chunk = false break end
        end
        if looks_like_chunk and #t > 0 then
            print("UNPACK CALLED WITH TABLE (Potential Chunk): size=" .. #t)
            local success, res = pcall(real_concat, t, ",")
            if success then
                print("CAPTURED CHUNK STRING: " .. res)
                if res:match("http") or res:match("www") then
                    print("URL DETECTED IN UNPACK --> " .. res:match("https?://[%w%.%-%/]+"))
                end
            end
        end
    end
    return real_unpack(t, i, j)
end

local function table_concat(t, sep, i, j)
    local res = real_concat(t, sep, i, j)
    if real_type(res) == "string" and (res:match("http") or res:match("www")) then
        print("URL DETECTED IN CONCAT --> " .. res:match("https?://[%w%.%-%/]+"))
    end
    return res
end

local function recursive_tostring(v, depth)
    if depth == nil then depth = 0 end
    if depth > 2 then return tostring(v) end
    if real_type(v) == "string" then
        return '"' .. v .. '"'
    elseif real_type(v) == "number" then
        if v == math.floor(v) and v >= -2147483648 and v <= 2147483647 then
            return tostring(math.floor(v))
        end
        return tostring(v)
    elseif real_type(v) == "boolean" then
        return tostring(v)
    elseif v == nil then
        return "nil"
    elseif real_type(v) == "table" then
        if getmetatable(v) and getmetatable(v).__is_mock_dummy then
            return tostring(v)
        end
        local parts = {}
        local keys = {}
        for k in pairs(v) do table.insert(keys, k) end
        table.sort(keys, function(a,b) return tostring(a) < tostring(b) end)
        for _, k in ipairs(keys) do
            local val = v[k]
            local k_str = tostring(k)
            if real_type(k) == "string" then k_str = '["' .. k .. '"]' end
            table.insert(parts, k_str .. " = " .. recursive_tostring(val, depth + 1))
        end
        return "{" .. real_concat(parts, ", ") .. "}"
    elseif real_type(v) == "function" then
        return tostring(v)
    else
        return tostring(v)
    end
end

local function create_dummy(name)
    local d = {}
    local mt = {
        __is_mock_dummy = true,
        __index = function(_, k)
            print("ACCESSED --> " .. name .. "." .. k)
            if k == "HttpGet" or k == "HttpGetAsync" then
                return function(_, url, ...)
                    print("URL DETECTED --> " .. tostring(url))
                    return create_dummy("HttpGetResult")
                end
            end
            return create_dummy(name .. "." .. k)
        end,
        __newindex = function(_, k, v)
            local val_str = recursive_tostring(v, 0)
            print("PROP_SET --> " .. name .. "." .. k .. " = " .. val_str)
        end,
        __call = function(_, ...)
            local args = {...}
            local arg_str = ""
            for i, v in ipairs(args) do
                if i > 1 then arg_str = arg_str .. ", " end
                arg_str = arg_str .. recursive_tostring(v)
            end
            local var_name = name:gsub("%.", "_") .. "_" .. math.random(100, 999)
            print("CALL_RESULT --> local " .. var_name .. " = " .. name .. "(" .. arg_str .. ")")
            for i, v in ipairs(args) do
                if real_type(v) == "function" then
                    print("--- ENTERING CLOSURE FOR " .. name .. " ---")
                    local success, err = pcall(v,
                        create_dummy("arg1"), create_dummy("arg2"),
                        create_dummy("arg3"), create_dummy("arg4"))
                    if not success then
                        print("-- CLOSURE ERROR: " .. tostring(err))
                    end
                    print("--- EXITING CLOSURE FOR " .. name .. " ---")
                end
            end
            return create_dummy(var_name)
        end,
        __tostring = function() return name end,
        __concat = function(a, b) return tostring(a) .. tostring(b) end,
        __add = function(a, b) return create_dummy("("..tostring(a).."+"..tostring(b)..")") end,
        __sub = function(a, b) return create_dummy("("..tostring(a).."-"..tostring(b)..")") end,
        __mul = function(a, b) return create_dummy("("..tostring(a).."*"..tostring(b)..")") end,
        __div = function(a, b) return create_dummy("("..tostring(a).."/"..tostring(b)..")") end,
        __mod = function(a, b) return create_dummy("("..tostring(a).."%"..tostring(b)..")") end,
        __pow = function(a, b) return create_dummy("("..tostring(a).."^"..tostring(b)..")") end,
        __unm = function(a) return create_dummy("-"..tostring(a)) end,
        __lt = function(a, b) return false end,
        __le = function(a, b) return false end,
        __eq = function(a, b) return false end,
        __len = function(a) return 2 end,
    }
    setmetatable(d, mt)
    return d
end

local function mock_pairs(t)
    local mt = getmetatable(t)
    if mt and mt.__is_mock_dummy then
        local i = 0
        return function(...)
            i = i + 1
            if i <= 1 then
                return i, create_dummy(tostring(t).."_v"..i)
            end
            return nil
        end
    end
    return pairs(t)
end

local function mock_ipairs(t)
    local mt = getmetatable(t)
    if mt and mt.__is_mock_dummy then
        local i = 0
        return function(...)
            i = i + 1
            if i <= 1 then
                return i, create_dummy(tostring(t).."_v"..i)
            end
            return nil
        end
    end
    return ipairs(t)
end

local MockEnv = {}
local safe_globals = {
    ["string"] = string,
    ["table"] = {
        ["insert"] = table.insert,
        ["remove"] = table.remove,
        ["sort"] = table.sort,
        ["concat"] = table_concat,
        ["maxn"] = table.maxn
    },
    ["math"] = math,
    ["pairs"] = mock_pairs,
    ["ipairs"] = mock_ipairs,
    ["select"] = select,
    ["unpack"] = unpack,
    ["tonumber"] = tonumber,
    ["tostring"] = tostring,
    ["type"] = type,
    ["typeof"] = typeof,
    ["pcall"] = pcall,
    ["xpcall"] = xpcall,
    ["getfenv"] = getfenv,
    ["setmetatable"] = setmetatable,
    ["getmetatable"] = getmetatable,
    ["error"] = error,
    ["assert"] = assert,
    ["next"] = next,
    ["print"] = function(...)
        local args = {...}
        local parts = {}
        for i,v in ipairs(args) do table.insert(parts, tostring(v)) end
        print("TRACE_PRINT --> " .. table.concat(parts, "\t"))
    end,
    ["_VERSION"] = _VERSION,
    ["rawset"] = rawset,
    ["rawget"] = rawget,
    ["os"] = os,
    ["io"] = io,
    ["package"] = package,
    ["debug"] = debug,
    ["dofile"] = dofile,
    ["loadfile"] = loadfile,
    ["loadstring"] = function(s)
        print("LOADSTRING DETECTED: size=" .. tostring(#s))
        print("LOADSTRING CONTENT START")
        print(s)
        print("LOADSTRING CONTENT END")
        return function() print("DUMMY FUNC CALLED") end
    end
}

setmetatable(MockEnv, {
    __index = function(t, k)
        if safe_globals[k] then
            return safe_globals[k]
        end
        if k == "game" then
            print("ACCESSED --> game")
            return create_dummy("game")
        end
        if k == "getgenv" or k == "getrenv" or k == "getreg" then
            return function() return MockEnv end
        end
        local exploit_funcs = {
            "getgc", "getinstances", "getnilinstances",
            "getloadedmodules", "getconnections", "firesignal", "fireclickdetector",
            "firetouchinterest", "isnetworkowner", "gethiddenproperty", "sethiddenproperty",
            "setsimulationradius", "rconsoleprint", "rconsolewarn", "rconsoleerr",
            "rconsoleinfo", "rconsolename", "rconsoleclear", "consoleprint", "consolewarn",
            "consoleerr", "consoleinfo", "consolename", "consoleclear", "warn", "print",
            "error", "debug", "clonefunction", "hookfunction", "newcclosure", "replaceclosure",
            "restoreclosure", "islclosure", "iscclosure", "checkcaller", "getnamecallmethod",
            "setnamecallmethod", "getrawmetatable", "setrawmetatable", "setreadonly",
            "isreadonly", "iswindowactive", "keypress", "keyrelease", "mouse1click",
            "mouse1press", "mouse1release", "mousescroll", "mousemoverel", "mousemoveabs",
            "hookmetamethod", "getcallingscript", "makefolder", "writefile", "readfile",
            "appendfile", "loadfile", "listfiles", "isfile", "isfolder", "delfile",
            "delfolder", "dofile", "bit", "bit32",
            "Vector2", "Vector3", "CFrame", "UDim2", "Color3", "Instance", "Ray",
            "Enum", "BrickColor", "NumberRange", "NumberSequence", "ColorSequence",
            "task", "coroutine", "Delay", "delay", "Spawn", "spawn", "Wait", "wait",
            "workspace", "Workspace", "tick", "time", "elapsedTime", "utf8"
        }
        for _, name in ipairs(exploit_funcs) do
            if k == name then
                print("ACCESSED --> " .. k)
                return create_dummy(k)
            end
        end
        print("ACCESSED (NIL) --> " .. k)
        return nil
    end,
    __newindex = function(t, k, v)
        local val_str = ""
        if real_type(v) == "string" then
            val_str = '"' .. v .. '"'
        elseif real_type(v) == "number" or real_type(v) == "boolean" then
            val_str = tostring(v)
        else
            val_str = tostring(v)
        end
        print("SET GLOBAL --> " .. tostring(k) .. " = " .. val_str)
        rawset(t, k, v)
    end
})

safe_globals["_G"] = MockEnv
safe_globals["shared"] = MockEnv
"""

    idx_args = content.rfind("(getfenv")
    if idx_args == -1:
        idx_args = content.rfind("( getfenv")
    if idx_args == -1:
        idx_args = len(content)

    idx_ret = content.rfind("return(function", 0, idx_args)
    if idx_ret == -1:
        print(f"Could not find return(function injection point in {source_label}.")
        return

    dumper_code = f"""
    print("--- CONSTANTS START ---")
    if {var_name} then
        local sorted_keys = {{}}
        for k in pairs({var_name}) do table.insert(sorted_keys, k) end
        table.sort(sorted_keys)
        local out = "local Constants = {{"
        for i, k in ipairs(sorted_keys) do
            local v = {var_name}[k]
            local v_str = tostring(v)
            v_str = string.format("%q", v)
            out = out .. " [" .. k .. "] = " .. v_str .. ","
        end
        out = out .. " }}"
        print(out)
    end
    print("--- CONSTANTS END ---")
    """

    new_content = mock_env_code + content[:idx_ret] + dumper_code + content[idx_ret:]

    if "getfenv and getfenv()or _ENV" in new_content:
        new_content = new_content.replace("getfenv and getfenv()or _ENV", "MockEnv")
    else:
        new_content = re.sub(r'getfenv\s+and\s+getfenv\(\)or\s+_ENV', 'MockEnv', new_content)

    temp_file = "temp_deob.lua"
    with open(temp_file, 'w', encoding='utf-8') as f:
        f.write(new_content)

    print(f"Executing deobfuscation for {source_label}...")

    process = subprocess.Popen(
        ["lua_bin/lua5.1.exe", temp_file, "1"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )

    stdout_lines = []
    RELEVANT_PREFIXES = (
        "ACCESSED", "CALL_RESULT", "local Constants =",
        "URL DETECTED", "SET GLOBAL", "UNPACK CALLED",
        "CAPTURED CHUNK", "CLOSURE", "TRACE_PRINT",
        "PROP_SET", "LOADSTRING"
    )

    start_time = time.time()
    try:
        while True:
            if process.poll() is not None:
                break
            line = process.stdout.readline()
            if line:
                decoded_line = line.decode('utf-8', errors='replace').strip()
                stdout_lines.append(decoded_line)
                if any(prefix in decoded_line for prefix in RELEVANT_PREFIXES):
                    print(decoded_line)
            if time.time() - start_time > 20:
                print("Timeout reached.")
                process.terminate()
                break
    except Exception as e:
        print(f"Error: {e}")
        process.kill()

    out, err = process.communicate()
    if out:
        for line in out.decode('utf-8', errors='replace').splitlines():
            stdout_lines.append(line.strip())
            if any(prefix in line for prefix in RELEVANT_PREFIXES):
                print(line.strip())
    if err:
        stderr_text = err.decode('utf-8', errors='replace')
        if stderr_text.strip():
            print("STDERR:", stderr_text)

    constants_str = ""
    trace_lines = []
    in_constants = False

    for line in stdout_lines:
        if line == "--- CONSTANTS START ---":
            in_constants = True
            continue
        if line == "--- CONSTANTS END ---":
            in_constants = False
            continue
        if in_constants:
            constants_str += line + "\n"
        elif any(prefix in line for prefix in RELEVANT_PREFIXES):
            trace_lines.append(line)

    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)

    if not save_name:
        save_name = "output"
    if not save_name.endswith(".lua"):
        save_name += ".lua"

    output_file = os.path.join(OUTPUT_FOLDER, save_name)

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("--- DEOBFUSCATION REPORT ---\n")
        f.write(f"File: {source_label}\n\n")
        f.write("--- TRACE ---\n")
        for line in trace_lines:
            f.write(line + "\n")
        f.write("\n--- CONSTANTS ---\n")
        f.write(constants_str)

    print(f"Script saved to {output_file}")

    try:
        import trace_to_lua
        import importlib
        importlib.reload(trace_to_lua)
        trace_to_lua.parse_trace(output_file)
    except Exception as e:
        print(f"Failed to convert trace: {e}")
        import traceback
        traceback.print_exc()

    if os.path.exists(temp_file):
        os.remove(temp_file)


def launch_gui():
    import tkinter as tk
    from tkinter import scrolledtext, font as tkfont, messagebox

    root = tk.Tk()
    root.title("WeAreDevs Deobfuscator")
    root.configure(bg="#f5f5f5")
    root.geometry("800x800")
    root.minsize(640, 700)
    root.resizable(True, True)

    WHITE   = "#ffffff"
    BG      = "#f5f5f5"
    CARD    = "#ffffff"
    BORDER  = "#e0e0e0"
    BORDER2 = "#bdbdbd"
    INPUT   = "#fafafa"
    TEXT    = "#1a1a1a"
    SUBTEXT = "#757575"
    LABEL   = "#424242"
    ACCENT  = "#1a1a1a"
    ACCENT_H= "#333333"
    SUCCESS = "#2e7d32"
    ERROR   = "#c62828"
    WARN    = "#e65100"
    LOG_BG  = "#1e1e1e"
    LOG_TEXT= "#d4d4d4"
    LOG_DIM = "#6e6e6e"
    LOG_OK  = "#4ec9b0"
    LOG_ERR = "#f44747"
    LOG_WARN= "#ce9178"

    F_HEAD  = tkfont.Font(family="Segoe UI", size=16, weight="bold")
    F_SUB   = tkfont.Font(family="Segoe UI", size=9)
    F_LABEL = tkfont.Font(family="Segoe UI", size=10)
    F_LABEL_B = tkfont.Font(family="Segoe UI", size=10, weight="bold")
    F_MONO  = tkfont.Font(family="Consolas", size=9)
    F_BTN   = tkfont.Font(family="Segoe UI", size=10, weight="bold")
    F_SMALL = tkfont.Font(family="Segoe UI", size=9)
    F_TINY  = tkfont.Font(family="Segoe UI", size=8)

    tk.Frame(root, bg=BORDER, height=3).pack(fill="x", side="top")

    header = tk.Frame(root, bg=CARD)
    header.pack(fill="x")

    header_inner = tk.Frame(header, bg=CARD)
    header_inner.pack(fill="x", padx=28, pady=12)

    title_block = tk.Frame(header_inner, bg=CARD)
    title_block.pack(side="left")

    tk.Label(title_block, text="WeAreDevs Deobfuscator v1.0",
             bg=CARD, fg=TEXT, font=F_HEAD).pack(anchor="w")
    tk.Label(title_block, text="Deobfuscator  ·  v1.0",
             bg=CARD, fg=SUBTEXT, font=F_SUB).pack(anchor="w", pady=(2, 0))

    tk.Frame(root, bg=BORDER, height=1).pack(fill="x")

    steps_bar = tk.Frame(root, bg=BG)
    steps_bar.pack(fill="x", padx=28, pady=(10, 8))

    tk.Label(steps_bar, text="HOW TO USE",
             bg=BG, fg=SUBTEXT,
             font=tkfont.Font(family="Segoe UI", size=8, weight="bold")).pack(anchor="w", pady=(0, 6))

    steps_row = tk.Frame(steps_bar, bg=BG)
    steps_row.pack(fill="x")

    for i, step in enumerate([
        "Paste your obfuscated Lua script into the editor",
        "Enter a name if you want to save as a file",
        "Click Deobfuscate then it will appear as raw lua",
    ]):
        col = tk.Frame(steps_row, bg=BG)
        col.pack(side="left", padx=(0, 24))

        num_ring = tk.Frame(col, bg=ACCENT, width=22, height=22)
        num_ring.pack_propagate(False)
        num_ring.pack(side="left", padx=(0, 8))
        tk.Label(num_ring, text=str(i + 1), bg=ACCENT, fg=WHITE,
                 font=F_TINY).place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(col, text=step, bg=BG, fg=LABEL, font=F_SMALL,
                 wraplength=160, justify="left").pack(side="left")

    tk.Frame(root, bg=BORDER, height=1).pack(fill="x", padx=28)

    body = tk.Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=28, pady=10)

    paste_lbl_row = tk.Frame(body, bg=BG)
    paste_lbl_row.pack(fill="x", pady=(0, 4))

    tk.Label(paste_lbl_row, text="Obfuscated Script",
             bg=BG, fg=LABEL, font=F_LABEL_B).pack(side="left")

    clear_btn = tk.Button(paste_lbl_row, text="Clear",
                          bg=BG, fg=SUBTEXT, font=F_SMALL,
                          relief="flat", bd=0, padx=0, pady=0,
                          activebackground=BG, activeforeground=TEXT,
                          cursor="hand2")
    clear_btn.pack(side="right")

    paste_wrap = tk.Frame(body, bg=BORDER2, padx=1, pady=1)
    paste_wrap.pack(fill="x")

    paste_inner = tk.Frame(paste_wrap, bg=WHITE)
    paste_inner.pack(fill="x")

    paste_box = scrolledtext.ScrolledText(
        paste_inner,
        bg=WHITE, fg="#383838", font=F_MONO,
        relief="flat", borderwidth=0,
        insertbackground="#1a1a1a",
        wrap="none",
        selectbackground="#cce5ff",
        selectforeground=TEXT,
        padx=10, pady=8,
        height=12
    )
    paste_box.pack(fill="x")

    char_var = tk.StringVar(value="0 characters")
    char_label = tk.Label(body, textvariable=char_var,
                          bg=BG, fg=SUBTEXT, font=F_TINY, anchor="e")
    char_label.pack(fill="x", pady=(3, 0))

    def on_paste_change(event=None):
        content = paste_box.get("1.0", "end-1c")
        char_var.set(f"{len(content):,} characters")
    paste_box.bind("<KeyRelease>", on_paste_change)
    paste_box.bind("<<Paste>>", lambda e: root.after(10, on_paste_change))

    clear_btn.config(command=lambda: [paste_box.delete("1.0", "end"), on_paste_change()])

    tk.Frame(body, bg=BORDER, height=1).pack(fill="x", pady=(8, 10))

    save_row = tk.Frame(body, bg=BG)
    save_row.pack(fill="x")

    save_left = tk.Frame(save_row, bg=BG)
    save_left.pack(side="left", fill="x", expand=True)

    tk.Label(save_left, text="Output filename",
             bg=BG, fg=LABEL, font=F_LABEL_B).pack(anchor="w", pady=(0, 5))

    name_row = tk.Frame(save_left, bg=BG)
    name_row.pack(anchor="w")

    name_wrap = tk.Frame(name_row, bg=BORDER2, padx=1, pady=1)
    name_wrap.pack(side="left")

    name_entry = tk.Entry(name_wrap, bg=WHITE, fg=TEXT, font=F_LABEL,
                          insertbackground=TEXT, relief="flat",
                          width=28)
    name_entry.pack(ipady=5, ipadx=6)

    tk.Label(name_row, text=".lua",
             bg=BG, fg=SUBTEXT, font=F_LABEL).pack(side="left", padx=(6, 0))

    run_btn = tk.Button(save_row, text="Deobfuscate",
                        bg=ACCENT, fg=WHITE, font=F_BTN,
                        relief="flat", bd=0,
                        padx=22, pady=10,
                        activebackground=ACCENT_H,
                        activeforeground=WHITE,
                        cursor="hand2")
    run_btn.pack(side="right", anchor="s")

    tk.Frame(root, bg=BORDER, height=1).pack(fill="x", padx=0)

    log_header = tk.Frame(root, bg=BG)
    log_header.pack(fill="x", padx=28, pady=(8, 4))

    tk.Label(log_header, text="Output Log",
             bg=BG, fg=LABEL, font=F_LABEL_B).pack(side="left")

    log_wrap = tk.Frame(root, bg=BORDER2, padx=1, pady=1)
    log_wrap.pack(fill="both", expand=True, padx=28, pady=(0, 0))

    log_box = scrolledtext.ScrolledText(
        log_wrap,
        bg=LOG_BG, fg=LOG_TEXT, font=F_MONO,
        relief="flat", borderwidth=0,
        insertbackground=LOG_TEXT,
        wrap="word", state="disabled",
        height=10,
        padx=10, pady=8
    )
    log_box.pack(fill="both", expand=True)

    log_box.tag_config("ok",      foreground=LOG_OK)
    log_box.tag_config("err",     foreground=LOG_ERR)
    log_box.tag_config("warn",    foreground=LOG_WARN)
    log_box.tag_config("neutral", foreground=LOG_TEXT)
    log_box.tag_config("dim",     foreground=LOG_DIM)

    status_bar = tk.Frame(root, bg=CARD)
    status_bar.pack(fill="x", pady=(4, 0))

    tk.Frame(status_bar, bg=BORDER, height=1).pack(fill="x")

    status_row = tk.Frame(status_bar, bg=CARD)
    status_row.pack(fill="x")

    status_var = tk.StringVar(value="Ready")
    tk.Label(status_row, textvariable=status_var,
             bg=CARD, fg=SUBTEXT, font=F_SMALL,
             anchor="w", padx=28, pady=7).pack(side="left")

    tk.Label(status_row, text="Deobfuscator",
             bg=CARD, fg=SUBTEXT, font=F_SMALL,
             anchor="e", padx=28, pady=7).pack(side="right")

    def log(msg, tag="neutral"):
        log_box.config(state="normal")
        log_box.insert("end", msg + "\n", tag)
        log_box.see("end")
        log_box.config(state="disabled")
        root.update_idletasks()

    def clear_log():
        log_box.config(state="normal")
        log_box.delete("1.0", "end")
        log_box.config(state="disabled")

    def run():
        pasted = paste_box.get("1.0", "end").strip()
        if not pasted:
            messagebox.showwarning("Nothing to deobfuscate", "Please paste a Lua script first.")
            return

        choice_win = tk.Toplevel(root)
        choice_win.title("Output")
        choice_win.configure(bg=CARD)
        choice_win.resizable(False, False)
        choice_win.grab_set()

        choice_win.update_idletasks()
        w, h = 340, 170
        rx = root.winfo_x() + (root.winfo_width() - w) // 2
        ry = root.winfo_y() + (root.winfo_height() - h) // 2
        choice_win.geometry(f"{w}x{h}+{rx}+{ry}")

        tk.Frame(choice_win, bg=BORDER, height=1).pack(fill="x")

        inner = tk.Frame(choice_win, bg=CARD, padx=24, pady=20)
        inner.pack(fill="both", expand=True)

        tk.Label(inner, text="What would you like to do with the output?",
                 bg=CARD, fg=TEXT,
                 font=tkfont.Font(family="Segoe UI", size=10),
                 wraplength=290, justify="left").pack(anchor="w", pady=(0, 16))

        btn_row = tk.Frame(inner, bg=CARD)
        btn_row.pack(fill="x")

        chosen = tk.StringVar(value="")

        def pick(val):
            chosen.set(val)
            choice_win.destroy()

        tk.Button(btn_row, text="Save to File",
                  bg=ACCENT, fg=WHITE, font=F_BTN,
                  relief="flat", bd=0, padx=16, pady=7,
                  activebackground=ACCENT_H, activeforeground=WHITE,
                  cursor="hand2",
                  command=lambda: pick("save")).pack(side="left", padx=(0, 10))

        tk.Button(btn_row, text="Show in Log",
                  bg=BG, fg=TEXT, font=F_BTN,
                  relief="flat", bd=0, padx=16, pady=7,
                  activebackground=BORDER, activeforeground=TEXT,
                  cursor="hand2",
                  command=lambda: pick("log")).pack(side="left")

        tk.Button(btn_row, text="Cancel",
                  bg=CARD, fg=SUBTEXT, font=F_SMALL,
                  relief="flat", bd=0, padx=10, pady=7,
                  activebackground=BG, activeforeground=TEXT,
                  cursor="hand2",
                  command=lambda: pick("cancel")).pack(side="right")

        choice_win.wait_window()

        action = chosen.get()
        if action == "cancel" or action == "":
            return

        if action == "save":
            save_name = name_entry.get().strip()
            if not save_name:
                messagebox.showwarning("Missing filename", "Please enter a file name before saving.")
                return

        clear_log()
        run_btn.config(state="disabled", text="Working...")
        status_var.set("Deobfuscating — please wait...")
        log("Starting deobfuscation...", "dim")

        import io, contextlib, threading

        def worker():
            buf = io.StringIO()
            try:
                if action == "save":
                    with contextlib.redirect_stdout(buf):
                        deobfuscate_text(pasted, save_name)
                    for line in buf.getvalue().splitlines():
                        if "Script saved to" in line:
                            root.after(0, lambda l=line: log(l, "ok"))
                        elif "Error" in line or "STDERR" in line:
                            root.after(0, lambda l=line: log(l, "err"))
                        elif any(p in line for p in ("ACCESSED", "URL", "CALL_RESULT", "PROP_SET")):
                            root.after(0, lambda l=line: log(l, "warn"))
                        else:
                            root.after(0, lambda l=line: log(l, "neutral"))
                    final = save_name if save_name.endswith(".lua") else save_name + ".lua"
                    root.after(0, lambda: status_var.set(f"Done — saved to deobfuscated/{final}"))

                else:
                    result_holder = {}

                    def capture():
                        import io as _io, contextlib as _ctx
                        b = _io.StringIO()
                        with _ctx.redirect_stdout(b):
                            deobfuscate_text(pasted, "_preview_")
                        result_holder["out"] = b.getvalue()

                        if not os.path.exists(OUTPUT_FOLDER):
                            os.makedirs(OUTPUT_FOLDER)
                        preview_path = os.path.join(OUTPUT_FOLDER, "_preview_.lua")
                        if os.path.exists(preview_path):
                            with open(preview_path, "r", encoding="utf-8", errors="replace") as fh:
                                result_holder["script"] = fh.read()
                            os.remove(preview_path)
                        else:
                            result_holder["script"] = "(no output generated)"

                    capture()

                    for line in result_holder.get("out", "").splitlines():
                        if "Script saved to" in line:
                            continue
                        elif "Error" in line or "STDERR" in line:
                            root.after(0, lambda l=line: log(l, "err"))
                        elif any(p in line for p in ("ACCESSED", "URL", "CALL_RESULT", "PROP_SET")):
                            root.after(0, lambda l=line: log(l, "warn"))
                        else:
                            root.after(0, lambda l=line: log(l, "neutral"))

                    script_text = result_holder.get("script", "")
                    root.after(0, lambda: log("", "dim"))
                    root.after(0, lambda: log("--- DEOBFUSCATED OUTPUT ---", "ok"))
                    for line in script_text.splitlines():
                        root.after(0, lambda l=line: log(l, "neutral"))
                    root.after(0, lambda: status_var.set("Done — output shown in log"))

            except Exception as exc:
                root.after(0, lambda: log(f"Error: {exc}", "err"))
                root.after(0, lambda: status_var.set("An error occurred."))
            finally:
                root.after(0, lambda: run_btn.config(state="normal", text="Deobfuscate"))

        threading.Thread(target=worker, daemon=True).start()

    run_btn.config(command=run)
    root.mainloop()


def main():
    if len(sys.argv) > 1:
        target = sys.argv[1]
        if os.path.isfile(target):
            _run_deobfuscation(open(target, encoding="utf-8", errors="replace").read(), target)
        elif os.path.isdir(target):
            for file in sorted(glob.glob(os.path.join(target, "*.lua"))):
                if "temp_deob" in file or ".report.txt" in file or ".deobf." in file:
                    continue
                _run_deobfuscation(open(file, encoding="utf-8", errors="replace").read(), file)
                print("-" * 40)
        else:
            print("Invalid path")
    else:
        launch_gui()


if __name__ == "__main__":
    main()