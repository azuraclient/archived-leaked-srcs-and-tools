# Unturned Internal Cheat - Technical Breakdown

This project is a high-performance **internal cheat** for *Unturned* (a Unity game using the Mono backend). It injects directly into the game process and interfaces with the internal Unity/Mono engine.

---

## 1. Core Architecture (`dllmain.cpp`)

The cheat is compiled as a Dynamic Link Library (DLL). When injected:
- It spawns a `MainThread`.
- **Module Synchronization:** It waits for `UnityPlayer.dll`, `mono-2.0-bdwgc.dll`, and `d3d11.dll` to ensure the game is fully loaded.
- **Initialization:** It initializes the Mono API exports and the hooking system.
- **Unload Logic:** Listens for the `END` key to safely restore hooks and exit.

---

## 2. Advanced Hooking System (`hooks.cpp`)

The cheat uses a **Per-Instance VMT (Virtual Method Table) Hook** to intercept DirectX 11 `Present`.

### How it works:
1. **Dummy Device:** Creates a temporary "dummy" DX11 Device and SwapChain to find the shared VTable address of `IDXGISwapChain`.
2. **Shared Interceptor:** Replaces the 8th entry (`Present`) of the *global* VTable with a temporary `hkPresentInterceptor`.
3. **Capture & Pivot:** When the game calls `Present`, the interceptor:
    - Captures the game's actual SwapChain pointer.
    - Immediately restores the shared VTable to its original state (stealth).
    - Creates a **Shadow VTable** (a heap-allocated copy of the original).
    - Replaces `Present` and `ResizeBuffers` in the Shadow VTable.
    - Points the game's SwapChain object to the Shadow VTable.
4. **Result:** Only the game's SwapChain is hooked. This bypasses many standard detection methods and avoids conflicts with other overlays like Steam.

---

## 3. Mono/Unity Interfacing (`features.hpp`)

Since *Unturned* is a Unity game using Mono, the cheat uses the internal **Mono API** to interact with C# classes and methods from C++.

### Key Mechanisms:
- **Metadata Analysis:** Uses functions like `mono_class_from_name` and `mono_field_get_offset` to dynamically find memory offsets for classes like `SDG.Unturned.Provider` or `SDG.Unturned.Player`. This makes the cheat more resilient to game updates.
- **Method Invocation:** Uses `mono_runtime_invoke` to call engine functions like `Transform.get_position()` or `Transform.set_position()`.
- **Camera Capture:** Captures the `Camera.main` object and its View/Projection matrices for accurate ESP calculations.

---

## 4. Feature Implementations

### ESP (Extra Sensory Perception)
- **Iteration:** Iterates through global manager lists like `Provider._clients` (Players), `ZombieManager._tickingZombies`, and `AnimalManager._tickingAnimals`.
- **World-to-Screen:** Converts 3D world coordinates to 2D screen coordinates using a custom matrix-based projection (captured from the game's camera).
- **Rendering:** Uses **ImGui** (hooked into `Present`) to draw boxes and text directly into the game's swapchain.

### Max Stats
- Directly modifies the `PlayerLife` class fields (`_health`, `_food`, `_water`, etc.) for the local player.

### Teleportation
- Accesses the `Transform` component of the local player and uses `SetPosition` (via `mono_runtime_invoke`) to update the player's coordinates.

---

## 5. Memory Management (`memory.hpp`)

- Provides safe `Read` and `Write` templates.
- **Surgical Detours:** Includes a raw detour implementation for 64-bit absolute jumps (`mov rax, <addr>; jmp rax`), used for low-level function patching if needed.

---

## 6. Rendering & UI (`menu.hpp`)

- **Backend:** DirectX 11.
- **UI Framework:** ImGui.
- **Input Handling:** Hooks `WndProc` to intercept mouse and keyboard messages, allowing the user to interact with the menu without moving the game camera or clicking through the UI.
