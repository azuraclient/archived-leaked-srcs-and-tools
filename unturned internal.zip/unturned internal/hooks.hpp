#pragma once
#include "includes.hpp"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx11.h"
#include "ImGui/imgui_impl_win32.h"
#include <d3d11.h>
#include <dxgi.h>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

namespace Hooks {
    // Function pointer types
    using tPresent       = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT);
    using tResizeBuffers = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
    using tWndProc       = LRESULT(CALLBACK*)(HWND, UINT, WPARAM, LPARAM);

    // State
    inline tPresent       oPresent       = nullptr;
    inline tResizeBuffers oResizeBuffers = nullptr;
    inline tWndProc       oWndProc       = nullptr;

    inline HWND                    hWindow          = nullptr;
    inline ID3D11Device*           pDevice          = nullptr;
    inline ID3D11DeviceContext*    pContext          = nullptr;
    inline ID3D11RenderTargetView* pRenderTargetView = nullptr;

    inline bool bImGuiInitialized = false;
    inline bool bShuttingDown     = false;

    // Trampoline memory for the original function bytes
    inline void* pPresentTrampoline       = nullptr;
    inline void* pResizeBuffersTrampoline = nullptr;

    bool Init();
    void Shutdown();
}
