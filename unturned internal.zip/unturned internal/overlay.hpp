#pragma once
#include "includes.hpp"
#include <d3d11.h>

namespace Overlay {
    inline HWND hOverlay = nullptr;
    inline HWND hTarget = nullptr;
    
    inline ID3D11Device* pDevice = nullptr;
    inline ID3D11DeviceContext* pContext = nullptr;
    inline IDXGISwapChain* pSwapChain = nullptr;
    inline ID3D11RenderTargetView* pRenderTargetView = nullptr;

    bool Init();
    void Render();
    void Shutdown();
    void Run();
}
