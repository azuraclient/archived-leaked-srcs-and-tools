#pragma once
#include "includes.hpp"
#include "ImGui/imgui.h"

namespace Menu {
    inline bool bOpen = true;

    inline void Render() {
        if (!bOpen) return;

        ImGui::Begin("Unturned Internal", &bOpen);
        
        if (ImGui::CollapsingHeader("Features", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::Checkbox("Max Stats", &Config::bMaxStats);
            ImGui::Checkbox("Teleport (F1)", &Config::bTeleport);
        }

        if (ImGui::CollapsingHeader("ESP", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::Checkbox("Enabled", &Config::bEspEnabled);
            ImGui::Checkbox("Box", &Config::bEspBoxes);
            ImGui::Checkbox("Names", &Config::bEspNames);
        }

        ImGui::End();
    }
}
