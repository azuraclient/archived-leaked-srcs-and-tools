#pragma once
#include "includes.hpp"
#include "ImGui/imgui.h"
#include "hooks.hpp"

namespace CheatFeatures {
    typedef void* (__cdecl* t_mono_domain_get)();
    typedef void* (__cdecl* t_mono_get_root_domain)();
    typedef void* (__cdecl* t_mono_thread_attach)(void* domain);
    typedef void* (__cdecl* t_mono_domain_assembly_open)(void* domain, const char* name);
    typedef void* (__cdecl* t_mono_assembly_get_image)(void* assembly);
    typedef const char* (__cdecl* t_mono_image_get_name)(void* image);
    typedef void (__cdecl* t_mono_assembly_foreach)(void (__cdecl* func)(void* assembly, void* user_data), void* user_data);
    typedef void* (__cdecl* t_mono_class_from_name)(void* image, const char* name_space, const char* name);
    typedef void* (__cdecl* t_mono_class_vtable)(void* domain, void* klass);
    typedef void* (__cdecl* t_mono_vtable_get_static_field_data)(void* vtable);
    typedef void* (__cdecl* t_mono_class_get_method_from_name)(void* klass, const char* name, int param_count);
    typedef void* (__cdecl* t_mono_runtime_invoke)(void* method, void* obj, void** params, void** exc);
    typedef void* (__cdecl* t_mono_class_get_fields)(void* klass, void** iter);
    typedef const char* (__cdecl* t_mono_field_get_name)(void* field);
    typedef uintptr_t (__cdecl* t_mono_field_get_offset)(void* field);

    inline t_mono_domain_get mono_domain_get;
    inline t_mono_get_root_domain mono_get_root_domain;
    inline t_mono_thread_attach mono_thread_attach;
    inline t_mono_domain_assembly_open mono_domain_assembly_open;
    inline t_mono_assembly_get_image mono_assembly_get_image;
    inline t_mono_image_get_name mono_image_get_name;
    inline t_mono_assembly_foreach mono_assembly_foreach;
    inline t_mono_class_from_name mono_class_from_name;
    inline t_mono_class_vtable mono_class_vtable;
    inline t_mono_vtable_get_static_field_data mono_vtable_get_static_field_data;
    inline t_mono_class_get_method_from_name mono_class_get_method_from_name;
    inline t_mono_runtime_invoke mono_runtime_invoke;
    inline t_mono_class_get_fields mono_class_get_fields;
    inline t_mono_field_get_name mono_field_get_name;
    inline t_mono_field_get_offset mono_field_get_offset;

    inline void* assembly_csharp_image = nullptr;
    inline void* unity_engine_image = nullptr;
    inline std::vector<void*> all_images;

    struct Matrix4x4 { 
        float m[16]; 
        static Matrix4x4 Multiply(const Matrix4x4& a, const Matrix4x4& b) {
            Matrix4x4 res;
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 4; j++) {
                    res.m[i + j * 4] = a.m[i + 0 * 4] * b.m[0 + j * 4] +
                                      a.m[i + 1 * 4] * b.m[1 + j * 4] +
                                      a.m[i + 2 * 4] * b.m[2 + j * 4] +
                                      a.m[i + 3 * 4] * b.m[3 + j * 4];
                }
            }
            return res;
        }
    };
    inline Matrix4x4 view_matrix;

    namespace Offsets {
        inline uintptr_t provider_clients = 0;
        inline uintptr_t steamplayer_player = 0;
        inline uintptr_t player_movement = 0;
        inline uintptr_t playermovement_position = 0x34; // Cached in mono layout, often constant 0x34 or 0x38. Kept static for now.
        
        inline uintptr_t player_life = 0;
        inline uintptr_t health = 0;
        inline uintptr_t food = 0;
        inline uintptr_t water = 0;
        inline uintptr_t virus = 0;
        inline uintptr_t stamina = 0;

        inline uintptr_t zombiemanager_tickingZombies = 0;
        inline uintptr_t animalmanager_tickingAnimals = 0;
    }

    inline uintptr_t GetFieldOffset(void* klass, const char* target_name) {
        if (!klass) return 0;
        void* iter = nullptr;
        void* field;
        while ((field = mono_class_get_fields(klass, &iter))) {
            const char* name = mono_field_get_name(field);
            if (name && strcmp(name, target_name) == 0) {
                return mono_field_get_offset(field);
            }
        }
        return 0;
    }

    inline void __cdecl AssemblyEnum(void* assembly, void* user_data) {
        if (!assembly) return;
        void* image = mono_assembly_get_image(assembly);
        if (!image) return;
        all_images.push_back(image);
        const char* name = mono_image_get_name(image);
        if (!name) return;
        if (strstr(name, "Assembly-CSharp")) assembly_csharp_image = image;
        if (strstr(name, "UnityEngine.CoreModule") || strcmp(name, "UnityEngine") == 0) unity_engine_image = image;
    }

    template<typename T>
    inline bool ReadMem(uintptr_t addr, T* out) {
        if (addr < 0x10000) return false;
        __try {
            *out = *(T*)addr;
            return true;
        } __except(1) {
            return false;
        }
    }

    inline bool InitializeMono() {
        HMODULE mono = GetModuleHandleA("mono-2.0-bdwgc.dll");
        if (!mono) return false;
        #define SET_EXPORT(name) name = reinterpret_cast<t_##name>(GetProcAddress(mono, #name));
        SET_EXPORT(mono_domain_get) SET_EXPORT(mono_get_root_domain) SET_EXPORT(mono_thread_attach) SET_EXPORT(mono_domain_assembly_open)
        SET_EXPORT(mono_assembly_get_image) SET_EXPORT(mono_image_get_name) SET_EXPORT(mono_assembly_foreach) SET_EXPORT(mono_class_from_name)
        SET_EXPORT(mono_class_vtable) SET_EXPORT(mono_vtable_get_static_field_data) SET_EXPORT(mono_class_get_method_from_name)
        SET_EXPORT(mono_runtime_invoke) SET_EXPORT(mono_class_get_fields) SET_EXPORT(mono_field_get_name) SET_EXPORT(mono_field_get_offset)
        #undef SET_EXPORT
        void* domain = mono_get_root_domain();
        if (!domain) domain = mono_domain_get();
        if (!domain) return false;
        mono_thread_attach(domain);
        mono_assembly_foreach(AssemblyEnum, nullptr);

        if (assembly_csharp_image) {
            void* provider_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "Provider");
            Offsets::provider_clients = GetFieldOffset(provider_class, "_clients");

            void* steamPlayer_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "SteamPlayer");
            Offsets::steamplayer_player = GetFieldOffset(steamPlayer_class, "_player");

            void* player_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "Player");
            Offsets::player_movement = GetFieldOffset(player_class, "_movement");
            Offsets::player_life = GetFieldOffset(player_class, "_life");

            void* playerLife_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "PlayerLife");
            if (playerLife_class) {
                Offsets::health = GetFieldOffset(playerLife_class, "_health");
                Offsets::food = GetFieldOffset(playerLife_class, "_food");
                Offsets::water = GetFieldOffset(playerLife_class, "_water");
                Offsets::virus = GetFieldOffset(playerLife_class, "_virus");
                Offsets::stamina = GetFieldOffset(playerLife_class, "_stamina");
            }

            void* zombie_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "Zombie");
            if (zombie_class) {
                std::cout << "[*] Zombie fields:\n";
                void* iter = nullptr; void* f;
                while ((f = mono_class_get_fields(zombie_class, &iter))) {
                    const char* name = mono_field_get_name(f);
                    uintptr_t off = mono_field_get_offset(f);
                    std::cout << "    - " << name << " (off: 0x" << std::hex << off << std::dec << ")\n";
                }
            }

            void* zm_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "ZombieManager");
            if (zm_class) {
                Offsets::zombiemanager_tickingZombies = GetFieldOffset(zm_class, "_tickingZombies");
            }

            void* am_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "AnimalManager");
            if (am_class) {
                Offsets::animalmanager_tickingAnimals = GetFieldOffset(am_class, "_tickingAnimals");
            }

            void* seeker_class = nullptr;
            for (void* img : all_images) {
                seeker_class = mono_class_from_name(img, "SDG.Unturned", "Seeker");
                if (!seeker_class) seeker_class = mono_class_from_name(img, "Pathfinding", "Seeker");
                if (!seeker_class) seeker_class = mono_class_from_name(img, "", "Seeker");
                if (seeker_class) {
                    std::cout << "[+] Found Seeker class in assembly: " << mono_image_get_name(img) << "\n";
                    std::cout << "[*] Seeker fields:\n";
                    void* iter = nullptr; void* f;
                    while ((f = mono_class_get_fields(seeker_class, &iter))) {
                        const char* name = mono_field_get_name(f);
                        uintptr_t off = mono_field_get_offset(f);
                        std::cout << "    - " << name << " (off: 0x" << std::hex << off << std::dec << ")\n";
                    }
                    break;
                }
            }
            
            void* zr_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "ZombieRegion");
            if (zr_class) {
                std::cout << "[*] ZombieRegion fields:\n";
                void* iter = nullptr; void* f;
                while ((f = mono_class_get_fields(zr_class, &iter))) {
                    const char* name = mono_field_get_name(f);
                    uintptr_t off = mono_field_get_offset(f);
                    std::cout << "    - " << name << " (off: 0x" << std::hex << off << std::dec << ")\n";
                }
            }
            
            std::cout << "[+] Offsets Updated from Dump." << std::endl;
        }

        return (assembly_csharp_image != nullptr && unity_engine_image != nullptr);
    }

    inline Vector3 GetPosition(void* transform) {
        if (!transform || !unity_engine_image) return { 0,0,0 };
        static void* get_pos = nullptr;
        if (!get_pos) {
            void* transform_class = mono_class_from_name(unity_engine_image, "UnityEngine", "Transform");
            get_pos = mono_class_get_method_from_name(transform_class, "get_position", 0);
        }
        if (!get_pos) return { 0,0,0 };

        Vector3 res;
        mono_runtime_invoke(get_pos, transform, nullptr, nullptr); 
        // Note: mono_runtime_invoke for primitive types/structs returns an unboxed pointer or we can use another way
        // Actually, for get_position, it returns a boxed Vector3.
        return *(Vector3*)((char*)mono_runtime_invoke(get_pos, transform, nullptr, nullptr) + 0x10);
    }

    inline void* GetTransform(void* component) {
        if (!component || !unity_engine_image) return nullptr;
        static void* get_transform = nullptr;
        if (!get_transform) {
            void* component_class = mono_class_from_name(unity_engine_image, "UnityEngine", "Component");
            get_transform = mono_class_get_method_from_name(component_class, "get_transform", 0);
        }
        if (!get_transform) return nullptr;
        return mono_runtime_invoke(get_transform, component, nullptr, nullptr);
    }

    inline void UpdateViewMatrix() {
        __try {
            if (!unity_engine_image || !mono_runtime_invoke) return;
            static void* camera_class = nullptr;
            static void* get_main = nullptr;
            static void* get_view = nullptr;
            static void* get_proj = nullptr;
            if (!camera_class) camera_class = mono_class_from_name(unity_engine_image, "UnityEngine", "Camera");
            if (!get_main && camera_class) get_main = mono_class_get_method_from_name(camera_class, "get_main", 0);
            if (!get_view && camera_class) get_view = mono_class_get_method_from_name(camera_class, "get_worldToCameraMatrix", 0);
            if (!get_proj && camera_class) get_proj = mono_class_get_method_from_name(camera_class, "get_projectionMatrix", 0);
            
            if (!get_main || !get_view || !get_proj) return;
            
            void* main_camera = mono_runtime_invoke(get_main, nullptr, nullptr, nullptr);
            if (!main_camera) return;

            void* view_obj = mono_runtime_invoke(get_view, main_camera, nullptr, nullptr);
            void* proj_obj = mono_runtime_invoke(get_proj, main_camera, nullptr, nullptr);

            if (view_obj && proj_obj) {
                Matrix4x4 view = *(Matrix4x4*)((char*)view_obj + 0x10);
                Matrix4x4 proj = *(Matrix4x4*)((char*)proj_obj + 0x10);
                view_matrix = Matrix4x4::Multiply(proj, view);
            }
        } __except(1) {}
    }

    inline void SetPosition(void* transform, Vector3 pos) {
        if (!transform || !unity_engine_image) return;
        static void* set_pos = nullptr;
        if (!set_pos) {
            void* transform_class = mono_class_from_name(unity_engine_image, "UnityEngine", "Transform");
            set_pos = mono_class_get_method_from_name(transform_class, "set_position", 1);
        }
        if (!set_pos) return;
        
        void* args[1];
        args[0] = &pos;
        mono_runtime_invoke(set_pos, transform, args, nullptr);
    }

    inline bool WorldToScreen(Vector2& screen, Vector3 world) {
        float w = view_matrix.m[3] * world.x + view_matrix.m[7] * world.y + view_matrix.m[11] * world.z + view_matrix.m[15];
        if (w < 0.01f) return false;
        float x = view_matrix.m[0] * world.x + view_matrix.m[4] * world.y + view_matrix.m[8] * world.z + view_matrix.m[12];
        float y = view_matrix.m[1] * world.x + view_matrix.m[5] * world.y + view_matrix.m[9] * world.z + view_matrix.m[13];
        
        RECT rect;
        if (!Hooks::hWindow || !GetClientRect(Hooks::hWindow, &rect)) return false;
        float width = (float)(rect.right - rect.left);
        float height = (float)(rect.bottom - rect.top);

        screen.x = (width / 2) * (1 + x / w);
        screen.y = (height / 2) * (1 - y / w);
        return true;
    }

    inline void RenderZombieESP(ImDrawList* drawList) {
        if (!Config::bZombieEsp || !assembly_csharp_image) return;
        __try {
            void* domain = mono_get_root_domain();
            if (!domain) return;

            void* zm_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "ZombieManager");
            if (!zm_class) return;
            void* zm_vtable = mono_class_vtable(domain, zm_class);
            void* zm_data = zm_vtable ? mono_vtable_get_static_field_data(zm_vtable) : nullptr;
            if (!zm_data) return;

            // Try _tickingZombies first
            uintptr_t tickingZombies = 0;
            if (ReadMem((uintptr_t)zm_data + Offsets::zombiemanager_tickingZombies, &tickingZombies)) {
                if (tickingZombies > 0x10000) {
                    uintptr_t items = 0; int size = 0;
                    if (ReadMem(tickingZombies + 0x10, &items) && ReadMem(tickingZombies + 0x18, &size)) {
                        static bool once = false;
                        if (!once) { std::cout << "[*] TickingZombies: size=" << size << " items=0x" << std::hex << items << std::dec << "\n"; once = true; }
                        if (size > 0 && size < 2000 && items) {
                            for (int i = 0; i < size; i++) {
                                uintptr_t zombie = 0;
                                if (!ReadMem(items + 0x20 + (i * 0x8), &zombie) || zombie < 0x10000) continue;
                                void* trans = GetTransform((void*)zombie);
                                if (!trans) continue;
                                Vector3 pos = GetPosition(trans);
                                Vector2 screen;
                                if (WorldToScreen(screen, pos)) {
                                    drawList->AddRect({ screen.x - 10, screen.y - 10 }, { screen.x + 10, screen.y + 10 }, IM_COL32(0, 255, 0, 255));
                                    drawList->AddText({ screen.x - 10, screen.y + 12 }, IM_COL32(200, 255, 200, 255), "Zombie");
                                }
                            }
                        }
                    } else {
                        static bool fail_once = false;
                        if (!fail_once) { std::cout << "[!] Failed to read TickingZombies items/size at 0x" << std::hex << tickingZombies << std::dec << "\n"; fail_once = true; }
                    }
                } else {
                    static bool null_once = false;
                    if (!null_once) { std::cout << "[!] TickingZombies is null/invalid (0x" << std::hex << tickingZombies << std::dec << ")\n"; null_once = true; }
                }
            }

            // Fallback: _regions (off: 0x40)
            uintptr_t regions = 0;
            if (ReadMem((uintptr_t)zm_data + 0x40, &regions) && regions > 0x10000) {
                int size = 0;
                if (ReadMem(regions + 0x18, &size) && size > 0 && size < 500) {
                    static bool reg_once = false;
                    if (!reg_once) { std::cout << "[*] Regions array size: " << size << "\n"; reg_once = true; }
                    for (int i = 0; i < size; i++) {
                        // In a Mono multidimensional array, elements start at 0x20 directly in the array object.
                        uintptr_t region = 0;
                        if (!ReadMem(regions + 0x20 + (i * 0x8), &region) || region < 0x10000) continue;
                        
                        // ZombieRegion._zombies (off: 0x20 based on dump)
                        uintptr_t zList = 0;
                        if (ReadMem(region + 0x20, &zList) && zList > 0x10000) {
                            uintptr_t zItems = 0; int zSize = 0;
                            // zList is a List<Zombie>, so items at 0x10, size at 0x18
                            if (ReadMem(zList + 0x10, &zItems) && ReadMem(zList + 0x18, &zSize)) {
                                static int loggedRegions = 0;
                                if (loggedRegions < 5 || (zSize > 0 && zSize < 500)) {
                                    std::cout << "[*] Region " << i << ": zList=0x" << std::hex << zList << " zItems=0x" << zItems << " zSize=" << std::dec << zSize << "\n";
                                    loggedRegions++;
                                }
                                if (zSize > 0 && zSize < 500 && zItems) {
                                    for (int j = 0; j < zSize; j++) {
                                        uintptr_t zombie = 0;
                                        if (!ReadMem(zItems + 0x20 + (j * 0x8), &zombie) || zombie < 0x10000) continue;
                                        
                                        void* trans = GetTransform((void*)zombie);
                                        if (!trans) continue;
                                        Vector3 pos = GetPosition(trans);
                                        Vector2 screen;
                                        if (WorldToScreen(screen, pos)) {
                                            drawList->AddRect({ screen.x - 10, screen.y - 10 }, { screen.x + 10, screen.y + 10 }, IM_COL32(255, 0, 0, 255));
                                            drawList->AddText({ screen.x - 10, screen.y + 12 }, IM_COL32(255, 100, 100, 255), "Zombie");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } __except(1) {}
    }

    inline void RenderAnimalESP(ImDrawList* drawList) {
        if (!Config::bAnimalEsp || !assembly_csharp_image) return;
        __try {
            void* domain = mono_get_root_domain();
            if (!domain) return;

            void* am_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "AnimalManager");
            if (!am_class) return;
            void* am_vtable = mono_class_vtable(domain, am_class);
            void* am_data = am_vtable ? mono_vtable_get_static_field_data(am_vtable) : nullptr;
            if (!am_data) return;

            uintptr_t tickingAnimals = 0;
            if (ReadMem((uintptr_t)am_data + Offsets::animalmanager_tickingAnimals, &tickingAnimals) && tickingAnimals > 0x10000) {
                uintptr_t items = 0; int size = 0;
                if (ReadMem(tickingAnimals + 0x10, &items) && ReadMem(tickingAnimals + 0x18, &size)) {
                    if (size > 0 && size < 2000 && items) {
                        for (int i = 0; i < size; i++) {
                            uintptr_t animal = 0;
                            if (!ReadMem(items + 0x20 + (i * 0x8), &animal) || animal < 0x10000) continue;
                            void* trans = GetTransform((void*)animal);
                            if (!trans) continue;
                            Vector3 pos = GetPosition(trans);
                            Vector2 screen;
                            if (WorldToScreen(screen, pos)) {
                                drawList->AddRect({ screen.x - 10, screen.y - 10 }, { screen.x + 10, screen.y + 10 }, IM_COL32(255, 255, 0, 255));
                                drawList->AddText({ screen.x - 10, screen.y + 12 }, IM_COL32(255, 255, 200, 255), "Animal");
                            }
                        }
                    }
                }
            }
        } __except(1) {}
    }

    inline void RenderESP() {
        if (!Config::bEspEnabled || !assembly_csharp_image) return;

        RECT rect;
        if (!Hooks::hWindow || !GetClientRect(Hooks::hWindow, &rect)) return;

        auto drawList = ImGui::GetBackgroundDrawList();

        __try {
            void* domain = mono_get_root_domain();
            if (!domain) return;
            mono_thread_attach(domain);
            UpdateViewMatrix();

            void* provider_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "Provider");
            if (!provider_class) return;
            void* vtable = mono_class_vtable(domain, provider_class);
            void* providerData = vtable ? mono_vtable_get_static_field_data(vtable) : nullptr;
            if (!providerData) return;

            uintptr_t clientsList = 0;
            if (!ReadMem((uintptr_t)providerData + Offsets::provider_clients, &clientsList) || clientsList < 0x10000) return;

            uintptr_t items = 0;
            int size = 0;
            if (!ReadMem(clientsList + 0x10, &items) || !ReadMem(clientsList + 0x18, &size)) return;
            
            if (size <= 0 || size > 150 || !items) return;

            for (int i = 0; i < size; i++) {
                uintptr_t steamPlayer = 0;
                if (!ReadMem(items + 0x20 + (i * 0x8), &steamPlayer) || steamPlayer < 0x10000) continue;
                
                uintptr_t player = 0;
                if (!ReadMem(steamPlayer + Offsets::steamplayer_player, &player) || player < 0x10000) continue;
                
                void* trans = GetTransform((void*)player);
                if (!trans) continue;

                Vector3 pos = GetPosition(trans);
                
                Vector2 screen;
                if (WorldToScreen(screen, pos)) {
                    drawList->AddRect({ screen.x - 15, screen.y - 30 }, { screen.x + 15, screen.y + 5 }, IM_COL32(255, 0, 0, 255));
                    drawList->AddText({ screen.x - 15, screen.y + 10 }, IM_COL32(255, 255, 255, 255), "Player");
                }
            }

            RenderZombieESP(drawList);
            RenderAnimalESP(drawList);
        } __except(1) {}
    }

    inline void HackLoop() {
        if (!assembly_csharp_image) return;
        __try {
            void* domain = mono_get_root_domain();
            if (!domain) return;
            mono_thread_attach(domain);

            void* player_class = mono_class_from_name(assembly_csharp_image, "SDG.Unturned", "Player");
            if (!player_class) return;
            
            void* pVtable = mono_class_vtable(domain, player_class);
            void* pData = pVtable ? mono_vtable_get_static_field_data(pVtable) : nullptr;
            if (!pData) return;

            uintptr_t localPlayerField = GetFieldOffset(player_class, "_localPlayer");
            if (!localPlayerField) return;

            uintptr_t localPlayer = 0;
            if (!ReadMem((uintptr_t)pData + localPlayerField, &localPlayer) || localPlayer < 0x10000) return;

            // Optional Max Stats (Visual / Singleplayer)
            if (Config::bMaxStats) {
                uintptr_t life = 0;
                if (ReadMem(localPlayer + Offsets::player_life, &life) && life > 0x10000) {
                    uint8_t max = 100;
                    if (Offsets::health) *(uint8_t*)(life + Offsets::health) = max;
                    if (Offsets::food) *(uint8_t*)(life + Offsets::food) = max;
                    if (Offsets::water) *(uint8_t*)(life + Offsets::water) = max;
                    if (Offsets::virus) *(uint8_t*)(life + Offsets::virus) = max;
                    if (Offsets::stamina) *(uint8_t*)(life + Offsets::stamina) = max;
                }
            }
            
            // F1 Teleport Key
            if (Config::bTeleport && (GetAsyncKeyState(VK_F1) & 0x8000)) {
                void* trans = GetTransform((void*)localPlayer);
                if (trans) {
                    Vector3 pos = GetPosition(trans);
                    pos.y += 2.0f; // Jump forward test
                    pos.z += 2.0f;
                    SetPosition(trans, pos);
                }
            }
        } __except(1) {}
    }

    inline void Run() {}
}
