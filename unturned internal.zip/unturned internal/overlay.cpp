#include "overlay.hpp"
#include "menu.hpp"
#include "features.hpp"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx11.h"
#include "ImGui/imgui_impl_win32.h"
#include <dwmapi.h>
#include <dxgi1_2.h>
#pragma comment(lib, "dwmapi.lib")

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK OverlayProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui::GetCurrentContext()) {
        if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
            return true;
    }
    if (msg == WM_DESTROY) {
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

namespace Overlay {
    bool bClassRegistered = false;

    bool Init() {
        hTarget = FindWindowA("UnityWndClass", "Unturned");
        if (!hTarget) hTarget = FindWindowA(NULL, "Unturned");
        if (!hTarget) { std::cout << "[Overlay] FindWindowA failed!" << std::endl; return false; }

        RECT rect;
        GetWindowRect(hTarget, &rect);

        WNDCLASSEXW wc = { sizeof(WNDCLASSEXW), CS_HREDRAW | CS_VREDRAW, OverlayProc, 0L, 0L, GetModuleHandle(NULL), NULL, NULL, NULL, NULL, L"AetherOverlay_Final", NULL };
        if (RegisterClassExW(&wc)) {
            bClassRegistered = true;
        }

        hOverlay = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW, 
            L"AetherOverlay_Final", L"Overlay", WS_POPUP,
            rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, NULL, NULL, wc.hInstance, NULL);

        if (!hOverlay) { std::cout << "[Overlay] CreateWindowExW failed!" << std::endl; return false; }

        SetLayeredWindowAttributes(hOverlay, RGB(0, 0, 0), 255, LWA_COLORKEY);
        MARGINS margins = { -1 };
        DwmExtendFrameIntoClientArea(hOverlay, &margins);

        DXGI_SWAP_CHAIN_DESC sd = {};
        sd.BufferCount = 2; // Double buffering
        sd.BufferDesc.Width = rect.right - rect.left;
        sd.BufferDesc.Height = rect.bottom - rect.top;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferDesc.RefreshRate.Numerator = 60;
        sd.BufferDesc.RefreshRate.Denominator = 1;
        sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = hOverlay;
        sd.SampleDesc.Count = 1;
        sd.SampleDesc.Quality = 0;
        sd.Windowed = TRUE;
        sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

        UINT createDeviceFlags = 0;
        D3D_FEATURE_LEVEL featureLevel;
        const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };

        if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &pSwapChain, &pDevice, &featureLevel, &pContext))) {
            std::cout << "[Overlay] D3D11CreateDeviceAndSwapChain failed!" << std::endl;
            return false;
        }

        ID3D11Texture2D* pBackBuffer = nullptr;
        if (FAILED(pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer)))) { std::cout << "[Overlay] GetBuffer failed!" << std::endl; return false; }
        pDevice->CreateRenderTargetView(pBackBuffer, nullptr, &pRenderTargetView);
        pBackBuffer->Release();

        ImGui::CreateContext();
        ImGui_ImplWin32_Init(hOverlay);
        ImGui_ImplDX11_Init(pDevice, pContext);
        ImGui::GetIO().IniFilename = NULL;

        ShowWindow(hOverlay, SW_SHOWDEFAULT);
        UpdateWindow(hOverlay);

        std::cout << "[+] Classic D3D11 Overlay Initialized" << std::endl;
        return true;
    }

    void Render() {
        if (!hTarget || !IsWindow(hTarget)) { Globals::bIsRunning = false; return; }

        RECT rect;
        GetWindowRect(hTarget, &rect);
        MoveWindow(hOverlay, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, TRUE);

        static bool lastF4State = false;
        bool currentF4State = (GetAsyncKeyState(VK_F4) & 0x8000) != 0;
        if (currentF4State && !lastF4State) {
            Menu::bOpen = !Menu::bOpen;
            if (Menu::bOpen) {
                SetWindowLongW(hOverlay, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
                SetForegroundWindow(hOverlay);
            } else {
                SetWindowLongW(hOverlay, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
            }
        }
        lastF4State = currentF4State;

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        if (Menu::bOpen) Menu::Render();
        CheatFeatures::RenderESP();
        CheatFeatures::HackLoop();

        ImGui::Render();
        
        const float clear_color[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; 
        pContext->OMSetRenderTargets(1, &pRenderTargetView, NULL);
        pContext->ClearRenderTargetView(pRenderTargetView, clear_color);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        pSwapChain->Present(1, 0); 
    }

    void Shutdown() {
        if (ImGui::GetCurrentContext()) {
            ImGui_ImplDX11_Shutdown();
            ImGui_ImplWin32_Shutdown();
            ImGui::DestroyContext();
        }
        if (pRenderTargetView) { pRenderTargetView->Release(); pRenderTargetView = nullptr; }
        if (pSwapChain) { pSwapChain->Release(); pSwapChain = nullptr; }
        if (pContext) { pContext->Release(); pContext = nullptr; }
        if (pDevice) { pDevice->Release(); pDevice = nullptr; }
        if (hOverlay) { DestroyWindow(hOverlay); hOverlay = nullptr; }
        if (bClassRegistered) {
            UnregisterClassW(L"AetherOverlay_Final", GetModuleHandle(NULL));
            bClassRegistered = false;
        }
    }

    void Run() {
        if (!Init()) return;
        MSG msg;
        while (Globals::bIsRunning) {
            if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE)) {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
                if (msg.message == WM_QUIT) break;
            }
            if (GetAsyncKeyState(VK_END) & 0x8000) { Globals::bIsRunning = false; break; }
            Render();
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        Shutdown();
    }
}
