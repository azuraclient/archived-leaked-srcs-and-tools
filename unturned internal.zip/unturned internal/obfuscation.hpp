#pragma once
#include "includes.hpp"

namespace Obfuscation {
    inline void Initialize() {
        std::thread([]() {
            while (Globals::bIsRunning) {
                volatile int junk = rand() % 1000;
                junk = (junk * 2) / 3;
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
            }
            }).detach();
    }
}