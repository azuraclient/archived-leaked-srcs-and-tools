#include "includes.hpp"
#include "features.hpp"
#include "hooks.hpp"

DWORD WINAPI MainThread(LPVOID lpParam) {
    ConsoleUI::Init();
    std::cout << "[*] MainThread Started" << std::endl;

    // Wait for game modules to load
    while (!GetModuleHandleA("UnityPlayer.dll") || !GetModuleHandleA("mono-2.0-bdwgc.dll") || !GetModuleHandleA("d3d11.dll")) {
        if (GetAsyncKeyState(VK_END) & 0x8000) goto _exit;
        Sleep(100);
    }
    Sleep(2000); // Extra delay - let the game fully initialize its renderer

    Globals::GameBase = (uintptr_t)GetModuleHandleA("UnityPlayer.dll");
    Globals::MonoBase = (uintptr_t)GetModuleHandleA("mono-2.0-bdwgc.dll");

    if (!CheatFeatures::InitializeMono()) {
        std::cout << "[!] Mono Init failed!" << std::endl;
        goto _exit;
    }
    std::cout << "[+] Mono Initialized." << std::endl;

    Globals::SoundLoad();

    // Install Present hook - renders ImGui directly into the game's swapchain
    if (!Hooks::Init()) {
        std::cout << "[!] Hook Init failed!" << std::endl;
        goto _exit;
    }

    // Wait for unload key
    while (Globals::bIsRunning) {
        if (GetAsyncKeyState(VK_END) & 0x8000) {
            Globals::bIsRunning = false;
            break;
        }
        Sleep(100);
    }

_exit:
    std::cout << "[*] Unloading..." << std::endl;
    Hooks::Shutdown();
    Globals::SoundUnload();
    
    Sleep(500);
    FreeConsole();
    FreeLibraryAndExitThread((HMODULE)lpParam, 0);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        Globals::hThisDll = hModule;
        DisableThreadLibraryCalls(hModule);
        HANDLE h = CreateThread(nullptr, 0, MainThread, hModule, 0, nullptr);
        if (h) CloseHandle(h);
    }
    return TRUE;
}
