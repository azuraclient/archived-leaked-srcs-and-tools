#pragma once
#include "includes.hpp"

namespace Input {
    inline HHOOK hKeyboardHook = nullptr;
    inline LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
        if (nCode == HC_ACTION && wParam == WM_KEYDOWN) {
            KBDLLHOOKSTRUCT* pKey = (KBDLLHOOKSTRUCT*)lParam;
        }
        return CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
    }
}
