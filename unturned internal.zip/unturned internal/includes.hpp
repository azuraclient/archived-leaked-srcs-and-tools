#pragma once
#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <atomic>
#include <chrono>
#include <psapi.h>
#include <map>
#include <mutex>
#include <unordered_map>

#pragma comment(lib, "psapi.lib")

#define XOR(str) str

#include "types.hpp"

namespace Config {
    inline bool bMaxStats = false;
    inline bool bTeleport = false;
    inline bool bEspEnabled = false;
    inline bool bEspBoxes = true;
    inline bool bEspNames = true;
    inline bool bZombieEsp = true;
    inline bool bAnimalEsp = true;
    inline bool bNpcEsp = true;
}

namespace Offsets {
    // SDG.Unturned.Provider (Static)
    inline uintptr_t Provider_clients = 0x118; // List<SteamPlayer>
    
    // SDG.Unturned.SteamPlayer
    inline uintptr_t SteamPlayer_player = 0x30;
    inline uintptr_t SteamPlayer_model = 0x28;
    
    // SDG.Unturned.Player
    inline uintptr_t Player_life = 0x68;
    inline uintptr_t Player_look = 0x88;
    inline uintptr_t Player_movement = 0x80;

    // SDG.Unturned.PlayerLife
    inline uintptr_t PlayerLife_health = 0xD2;
    inline uintptr_t PlayerLife_isDead = 0xD0;

    // SDG.Unturned.PlayerLook
    inline uintptr_t PlayerLook_camera = 0x40;
}

#include <dwmapi.h>
#pragma comment(lib, "dwmapi.lib")

namespace Globals {
    inline HMODULE hThisDll = nullptr;
    inline uintptr_t GameBase = 0;
    inline uintptr_t MonoBase = 0;
    inline volatile bool bIsRunning = true;

    inline void SoundLoad() { Beep(1000, 200); }
    inline void SoundUnload() { Beep(500, 200); }
}

#include "memory.hpp"
#include "obfuscation.hpp"
#include "security.hpp"
#include "console_ui.hpp"
#include "input.hpp"