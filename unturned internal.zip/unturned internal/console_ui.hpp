#pragma once
#include "includes.hpp"

namespace ConsoleUI {
    inline void ResetCursor() {
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
        if (h != INVALID_HANDLE_VALUE) {
            COORD c = { 0, 0 };
            SetConsoleCursorPosition(h, c);
        }
    }
    inline void Init() {
        AllocConsole();
        FILE* f;
        freopen_s(&f, "CONOUT$", "w", stdout);
        freopen_s(&f, "CONIN$", "r", stdin);
    }
}
