#include "hooks.hpp"
#include "menu.hpp"
#include "features.hpp"
#include <iostream>

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ============================================================
// Per-Instance VMT Hook
// No function body patching. Works even when Present is already
// hooked by Steam Overlay (gameoverlayrenderer64.dll).
//
// Strategy:
// 1. Create dummy SwapChain to get shared VTable address
// 2. Temporarily replace shared VTable[8] (Present) with our
//    one-shot interceptor
// 3. When game calls Present, interceptor fires:
//    - Captures the game's SwapChain pointer
//    - Restores the shared VTable immediately
//    - Creates a shadow VTable for the game's SwapChain
//    - Points the SwapChain object to the shadow VTable
// 4. All future Present calls go through our shadow VTable
// ============================================================

namespace Hooks {
    // Shadow VTable state
    static void** g_OriginalVTable      = nullptr;  // Game SC's original vtable ptr
    static void** g_ShadowVTable        = nullptr;  // Our copy with hooks
    static IDXGISwapChain* g_GameSC     = nullptr;  // Game's SwapChain
    static constexpr int VTABLE_SIZE    = 18;        // IDXGISwapChain vtable entry count

    // For the temporary interceptor
    static void** g_SharedVTable        = nullptr;
    static void*  g_SavedPresent        = nullptr;   // Original vtable[8] before intercept
    static bool   g_Intercepted         = false;

    static int g_FrameCount = 0;

    // ---- WndProc ----
    LRESULT __stdcall hkWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
        if (ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam))
            return true;
        if (Menu::bOpen && (ImGui::GetIO().WantCaptureMouse || ImGui::GetIO().WantCaptureKeyboard)) {
            switch (uMsg) {
            case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_RBUTTONDOWN: case WM_RBUTTONUP:
            case WM_MBUTTONDOWN: case WM_MBUTTONUP: case WM_MOUSEWHEEL:
            case WM_KEYDOWN: case WM_KEYUP: case WM_CHAR:
                return true;
            }
        }
        return CallWindowProc(oWndProc, hWnd, uMsg, wParam, lParam);
    }

    // ---- Main Present hook (on shadow VTable) ----
    HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags) {
        if (bShuttingDown)
            return oPresent(pSwapChain, SyncInterval, Flags);

        if (!bImGuiInitialized) {
            if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&pDevice))) {
                pDevice->GetImmediateContext(&pContext);
                DXGI_SWAP_CHAIN_DESC sd;
                pSwapChain->GetDesc(&sd);
                hWindow = sd.OutputWindow;
                oWndProc = (tWndProc)SetWindowLongPtr(hWindow, GWLP_WNDPROC, (LONG_PTR)hkWndProc);
                ImGui::CreateContext();
                ImGuiIO& io = ImGui::GetIO();
                io.IniFilename = nullptr;
                ImGui::StyleColorsDark();
                ImGui_ImplWin32_Init(hWindow);
                ImGui_ImplDX11_Init(pDevice, pContext);
                bImGuiInitialized = true;
                std::cout << "[+] ImGui initialized on game window." << std::endl;
            }
        }

        if (bImGuiInitialized && pContext) {
            // Recreate RTV every frame (needed for FLIP-model swapchains)
            ID3D11Texture2D* pBackBuffer = nullptr;
            if (SUCCEEDED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&pBackBuffer))) {
                ID3D11RenderTargetView* frameRTV = nullptr;
                pDevice->CreateRenderTargetView(pBackBuffer, nullptr, &frameRTV);
                pBackBuffer->Release();

                if (frameRTV) {
                    ImGui_ImplDX11_NewFrame();
                    ImGui_ImplWin32_NewFrame();
                    ImGui::NewFrame();

                    if (GetAsyncKeyState(VK_RSHIFT) & 1)
                        Menu::bOpen = !Menu::bOpen;
                    if (Menu::bOpen) Menu::Render();

                    g_FrameCount++;
                    if (g_FrameCount > 60) {
                        __try {
                            CheatFeatures::RenderESP();
                            CheatFeatures::HackLoop();
                        } __except (EXCEPTION_EXECUTE_HANDLER) {}
                    }

                    ImGui::Render();
                    pContext->OMSetRenderTargets(1, &frameRTV, nullptr);
                    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
                    frameRTV->Release();
                }
            }
        }

        return oPresent(pSwapChain, SyncInterval, Flags);
    }

    // ---- ResizeBuffers hook ----
    HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags) {
        if (bImGuiInitialized) {
            ImGui_ImplDX11_InvalidateDeviceObjects();
        }
        HRESULT hr = oResizeBuffers(pSwapChain, BufferCount, Width, Height, NewFormat, SwapChainFlags);
        if (bImGuiInitialized && SUCCEEDED(hr)) {
            ImGui_ImplDX11_CreateDeviceObjects();
        }
        return hr;
    }

    // ---- One-shot interceptor (temporary global vtable hook) ----
    HRESULT __stdcall hkPresentInterceptor(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags) {
        if (g_Intercepted) {
            // Already intercepted, just call original
            tPresent origFn = (tPresent)g_SavedPresent;
            return origFn(pSwapChain, SyncInterval, Flags);
        }

        g_Intercepted = true;
        std::cout << "[*] Intercepted game SwapChain: " << pSwapChain << std::endl;

        // Step 1: Immediately restore the shared vtable
        DWORD old;
        VirtualProtect(&g_SharedVTable[8], 8, PAGE_READWRITE, &old);
        g_SharedVTable[8] = g_SavedPresent;
        VirtualProtect(&g_SharedVTable[8], 8, old, &old);
        std::cout << "[*] Shared VTable restored." << std::endl;

        // Step 2: Read this SwapChain's vtable
        g_GameSC = pSwapChain;
        g_OriginalVTable = *(void***)pSwapChain;

        // Step 3: Create shadow vtable (copy of original)
        g_ShadowVTable = new void* [VTABLE_SIZE];
        memcpy(g_ShadowVTable, g_OriginalVTable, VTABLE_SIZE * sizeof(void*));

        // Step 4: Save originals and replace with our hooks
        oPresent       = (tPresent)g_OriginalVTable[8];
        oResizeBuffers = (tResizeBuffers)g_OriginalVTable[13];
        g_ShadowVTable[8]  = (void*)hkPresent;
        g_ShadowVTable[13] = (void*)hkResizeBuffers;

        // Step 5: Point the SwapChain to our shadow vtable
        DWORD old2;
        VirtualProtect(pSwapChain, 8, PAGE_READWRITE, &old2);
        *(void***)pSwapChain = g_ShadowVTable;
        VirtualProtect(pSwapChain, 8, old2, &old2);

        std::cout << "[+] Per-instance VMT hook installed!" << std::endl;

        // Call our real hook for this frame
        return hkPresent(pSwapChain, SyncInterval, Flags);
    }

    // ---- Init ----
    bool Init() {
        // Create dummy device + swapchain to get the shared VTable
        WNDCLASSEXA wc = { sizeof(WNDCLASSEXA), CS_CLASSDC, DefWindowProcA, 0, 0, GetModuleHandle(NULL), NULL, NULL, NULL, NULL, "DXDummy", NULL };
        RegisterClassExA(&wc);
        HWND hDummyWnd = CreateWindowA("DXDummy", NULL, WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, NULL, NULL, wc.hInstance, NULL);

        DXGI_SWAP_CHAIN_DESC sd = {};
        sd.BufferCount = 1;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = hDummyWnd;
        sd.SampleDesc.Count = 1;
        sd.Windowed = TRUE;
        sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

        IDXGISwapChain* pDummy = nullptr;
        ID3D11Device* pDummyDev = nullptr;
        ID3D11DeviceContext* pDummyCtx = nullptr;
        D3D_FEATURE_LEVEL fl;

        HRESULT hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, NULL, 0,
            D3D11_SDK_VERSION, &sd, &pDummy, &pDummyDev, &fl, &pDummyCtx);
        if (FAILED(hr)) {
            DestroyWindow(hDummyWnd);
            UnregisterClassA("DXDummy", wc.hInstance);
            std::cout << "[-] Dummy device creation failed." << std::endl;
            return false;
        }

        // Read the shared vtable from the dummy swapchain
        g_SharedVTable = *(void***)pDummy;
        g_SavedPresent = g_SharedVTable[8]; // Save original Present pointer

        std::cout << "[*] Shared VTable: " << g_SharedVTable << std::endl;
        std::cout << "[*] Present entry: " << g_SavedPresent << std::endl;

        // Clean up dummy (but DON'T release the dummy SC until after vtable patch,
        // because releasing might affect the shared vtable)
        pDummyDev->Release();
        pDummyCtx->Release();

        // Temporarily replace shared VTable[8] with our interceptor
        DWORD old;
        if (!VirtualProtect(&g_SharedVTable[8], 8, PAGE_READWRITE, &old)) {
            std::cout << "[-] VirtualProtect failed: " << GetLastError() << std::endl;
            pDummy->Release();
            DestroyWindow(hDummyWnd);
            UnregisterClassA("DXDummy", wc.hInstance);
            return false;
        }
        g_SharedVTable[8] = (void*)hkPresentInterceptor;
        VirtualProtect(&g_SharedVTable[8], 8, old, &old);

        // Now release the dummy
        pDummy->Release();
        DestroyWindow(hDummyWnd);
        UnregisterClassA("DXDummy", wc.hInstance);

        std::cout << "[+] Interceptor installed. Waiting for game's Present..." << std::endl;
        return true;
    }

    // ---- Shutdown ----
    void Shutdown() {
        bShuttingDown = true;
        Sleep(200);

        // Restore WndProc
        if (hWindow && oWndProc)
            SetWindowLongPtr(hWindow, GWLP_WNDPROC, (LONG_PTR)oWndProc);

        // Shutdown ImGui
        if (bImGuiInitialized) {
            ImGui_ImplDX11_Shutdown();
            ImGui_ImplWin32_Shutdown();
            ImGui::DestroyContext();
            bImGuiInitialized = false;
        }

        // Restore game SwapChain's original vtable
        if (g_GameSC && g_OriginalVTable) {
            DWORD old;
            VirtualProtect(g_GameSC, 8, PAGE_READWRITE, &old);
            *(void***)g_GameSC = g_OriginalVTable;
            VirtualProtect(g_GameSC, 8, old, &old);
        }

        // Restore shared vtable if interceptor was never called
        if (!g_Intercepted && g_SharedVTable && g_SavedPresent) {
            DWORD old;
            VirtualProtect(&g_SharedVTable[8], 8, PAGE_READWRITE, &old);
            g_SharedVTable[8] = g_SavedPresent;
            VirtualProtect(&g_SharedVTable[8], 8, old, &old);
        }

        // Free shadow vtable
        if (g_ShadowVTable) {
            delete[] g_ShadowVTable;
            g_ShadowVTable = nullptr;
        }
    }
}
