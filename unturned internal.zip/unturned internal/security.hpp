#pragma once
#include "includes.hpp"

namespace Security {
    inline void Initialize() {
        DWORD old;
        VirtualProtect(Globals::hThisDll, 0x1000, PAGE_EXECUTE_READWRITE, &old);
        SecureZeroMemory(Globals::hThisDll, 0x1000);
        VirtualProtect(Globals::hThisDll, 0x1000, old, &old);

        if (IsDebuggerPresent()) exit(0);
    }
}