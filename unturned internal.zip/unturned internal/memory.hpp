#pragma once
#include "includes.hpp"

namespace Memory {
    template <typename T>
    inline T Read(uintptr_t addr) {
        if (addr < 0x10000 || addr > 0x7FFFFFFEFFFF) return T();
        return *(T*)addr;
    }

    template <typename T>
    inline void Write(uintptr_t addr, T val) {
        if (addr < 0x10000 || addr > 0x7FFFFFFEFFFF) return;
        DWORD old;
        if (VirtualProtect((void*)addr, sizeof(T), PAGE_EXECUTE_READWRITE, &old)) {
            *(T*)addr = val;
            VirtualProtect((void*)addr, sizeof(T), old, &old);
        }
    }

    // Surgical Detour: Writes a JMP from target to detour
    // Returns original bytes to restore or call
    inline bool Detour(void* pTarget, void* pDetour, size_t size) {
        if (size < 12) return false; // Need at least 12 bytes for absolute jmp on x64

        DWORD oldProtect;
        if (!VirtualProtect(pTarget, size, PAGE_EXECUTE_READWRITE, &oldProtect))
            return false;

        // x64 Absolute Jump:
        // mov rax, <address>
        // jmp rax
        uint8_t jmp_bytes[] = { 
            0x48, 0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov rax, addr
            0xFF, 0xE0                                                 // jmp rax
        };
        *reinterpret_cast<void**>(&jmp_bytes[2]) = pDetour;

        memcpy(pTarget, jmp_bytes, sizeof(jmp_bytes));
        
        // NOP the rest if size > 12
        for (size_t i = sizeof(jmp_bytes); i < size; i++)
            static_cast<uint8_t*>(pTarget)[i] = 0x90;

        VirtualProtect(pTarget, size, oldProtect, &oldProtect);
        return true;
    }
}