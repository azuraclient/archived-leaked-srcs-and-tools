const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Supabase Configuration
// We check environment variables first, but fallback to these hardcoded values if missing.
// NOTE: This is the ANON key, which is safe to be public (it's exposed in browsers anyway).
// NEVER hardcode the SERVICE_ROLE key here.
const supabaseUrl = process.env.SUPABASE_URL || 'https://woxmcahgzwkyczkjngdg.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndveG1jYWhnendreWN6a2puZ2RnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg4NTEyNjgsImV4cCI6MjA4NDQyNzI2OH0.OnX9hbTf9Z2EdXOSrUp5kSrK_zpvb4A9U5XFonorKoI';

if (!supabaseUrl || !supabaseKey) {
    console.error('CRITICAL ERROR: Supabase URL/Key missing.');
}

const supabase = createClient(supabaseUrl, supabaseKey);

// --- API ROUTES ---

// Signup Route
app.post('/api/signup', async (req, res) => {
    const { email, password, options } = req.body;
    const licenseKey = options?.data?.license_key;

    console.log(`[SIGNUP] Attempt for email: ${email}, Key: ${licenseKey}`);

    if (!licenseKey) {
        return res.status(400).json({ success: false, error: 'License key is required' });
    }

    try {
        // 1. PRE-VALIDATION: Check if key exists and is unused
        const { data: keyData, error: keyError } = await supabase
            .from('license_keys')
            .select('*')
            .eq('key', licenseKey)
            .single();

        console.log('[SIGNUP] Key Lookup Result:', { keyData, keyError });

        if (keyError || !keyData) {
            console.error('[SIGNUP] Invalid Key Error');
            return res.status(400).json({ success: false, error: 'Invalid license key' });
        }

        if (keyData.status === 'used') {
            console.error('[SIGNUP] Key Already Used');
            return res.status(400).json({ success: false, error: 'License key already used' });
        }

        // 2. SIGN UP
        console.log('[SIGNUP] Valid Key. Proceeding to Auth...');
        const authResponse = await supabase.auth.signUp({
            email,
            password,
            options
        });

        console.log('[SIGNUP] Auth Response:', JSON.stringify(authResponse, null, 2));

        if (authResponse.error) throw authResponse.error;

        // Check if user already exists (Supabase returns fake success for security, but data.user is null or identities empty if dupe)
        // However, with `connnection` or detailed error enabled, we might catch it.
        // Actually, Supabase `signUp` usually returns an error object if the user exists BUT strict email security is on.
        // If "User already registered" error is thrown:

        res.json({ success: true, data: authResponse.data });

    } catch (err) {
        console.error('[SIGNUP] FAILURE:', err.message);
        // Supabase error for existing user
        if (err.message.includes("User already registered") || err.code === 'user_already_exists') {
            return res.status(400).json({ success: false, error: 'Email already registered' });
        }
        res.status(400).json({ success: false, error: err.message });
    }
});

// Login Route
app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password
        });

        if (error) throw error;
        res.json({ success: true, data });
    } catch (err) {
        console.error('[LOGIN] FAILURE:', err.message);
        let errorMsg = err.message;
        if (err.message === 'Email not confirmed') {
            errorMsg = 'Email not confirmed. Please check your inbox.';
        } else if (err.message === 'Invalid login credentials') {
            errorMsg = 'Invalid email or password.';
        }
        res.status(400).json({ success: false, error: errorMsg });
    }
});

// Fallback: Serve index.html for any other route (SPA support)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

module.exports = app; // For Vercel
