async function login() {
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;
  const msgBox = document.getElementById("login-msg"); // optional inline message
  const notification = document.getElementById("notification-container"); // main notification

  // Clear previous notifications
  msgBox.textContent = "";
  notification.innerHTML = "";

  try {
    const res = await fetch("/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });

    const data = await res.json();

    if (res.ok) {
      // ✅ Success notification
      notification.innerHTML = `<div class="notification success">${data.message}</div>`;
      msgBox.style.color = "lime";
      msgBox.textContent = data.message;

      // Optional: redirect after 1.5s
      // setTimeout(() => window.location.href = "index.html", 1500);

    } else {
      // ❌ Error notification
      notification.innerHTML = `<div class="notification error">${data.message}</div>`;
      msgBox.style.color = "red";
      msgBox.textContent = data.message;
    }

  } catch (err) {
    notification.innerHTML = `<div class="notification error">Server error</div>`;
    msgBox.style.color = "red";
    msgBox.textContent = "Server error";
    console.error(err);
  }
}
