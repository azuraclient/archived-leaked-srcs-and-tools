const API_BASE = "https://server-2hpe.onrender.com";
const loginForm = document.getElementById('loginForm');
const submitBtn = document.getElementById('submitBtn');
const btnLoader = document.getElementById('btnLoader');
const btnText = document.querySelector('.btn-text');

// Helper: Show Toast Notification
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return; // Guard clause
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// Helper: Loading State
function setLoading(isLoading) {
    if (isLoading) {
        submitBtn.disabled = true;
        btnText.style.display = 'none';
        btnLoader.style.display = 'block';
    } else {
        submitBtn.disabled = false;
        btnText.style.display = 'block';
        btnLoader.style.display = 'none';
    }
}

// Login Logic
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    
    // Captcha (Optional for localhost, required for production)
    let captchaToken = null;
    if (window.hcaptcha) {
        captchaToken = hcaptcha.getResponse();
        if (!captchaToken) {
            showToast("Please complete the captcha", "error");
            return;
        }
    }

    setLoading(true);

    try {
        const res = await fetch(`${API_BASE}/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
                username, 
                password,
                captchaToken 
            })
        });

        const data = await res.json();

        if (res.ok) {
            showToast("Login Successful!", "success");
            
            // 1. SAVE DATA CORRECTLY (This fixes the redirect loop)
            const authData = {
                username: data.username,
                token: data.token,
                plan: data.plan || "Free",
                EclipseID: data.EclipseID || "Unknown"
            };
            localStorage.setItem("userAuth", JSON.stringify(authData));

            // 2. REDIRECT to Dashboard Folder
            setTimeout(() => {
                window.location.href = "/dashboard/";
            }, 1000);
        } else {
            throw new Error(data.message || "Invalid credentials");
        }
    } catch (err) {
        showToast(err.message || "Connection failed", "error");
        if (window.hcaptcha) hcaptcha.reset();
    } finally {
        setLoading(false);
    }
});
