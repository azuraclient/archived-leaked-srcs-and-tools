document.addEventListener('DOMContentLoaded', async () => {
    // 1. READ DATA: Look for 'userAuth' in localStorage
    const storedAuth = localStorage.getItem('userAuth');
    
    // REDIRECT CHECK: If no data exists, go to login immediately
    if (!storedAuth) {
        window.location.href = '/login/'; 
        return;
    }

    const userAuth = JSON.parse(storedAuth);
    const token = userAuth.token;

    // 2. UPDATE UI: Show username/ID immediately
    if (userAuth.username) document.getElementById('display-username').textContent = userAuth.username;
    if (userAuth.EclipseID) document.getElementById('display-userid').textContent = userAuth.EclipseID;
    if (userAuth.plan) document.getElementById('display-plan').textContent = userAuth.plan.toUpperCase();

    // 3. OPTIONAL SECURITY: Verify token with backend
    // If you don't have a /verify endpoint yet, you can comment this block out.
    try {
        const API_BASE = "https://server-2hpe.onrender.com"; 
        // Using a gentle verify that doesn't crash if 404
        const response = await fetch(`${API_BASE}/verify-session`, { 
            method: 'GET',
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (response.status === 401 || response.status === 403) {
            throw new Error("Token Invalid");
        }
    } catch (error) {
        console.warn("Session check failed:", error);
        // Uncomment the line below ONLY if your backend verify route is working perfectly
        // localStorage.removeItem('userAuth'); window.location.href = '/login/';
    }

    // 4. LOGOUT BUTTON
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('userAuth');
            window.location.href = '/login/';
        });
    }
});
