#NoEnv
#SingleInstance Force
#Persistent
ListLines, 0
SetBatchLines, -1

#Include %A_ScriptDir%\data\JSON.ahk

global A_ScriptFullPath2, A_ScriptDir2
A_ScriptFullPath2 := A_ScriptFullPath
A_ScriptDir2 := A_ScriptDir

Gui, +AlwaysOnTop
Gui, Color, 111111
Gui, Font, s10 c8B668B, Segoe UI
Gui, Add, Text, w280 Center, Enter your key:
Gui, Add, Edit, vUserKey x10 y35 w280 h23 c8B668B Background1a1a1a
Gui, Add, Button, x100 y70 w100 h28 gSubmit, Continue
Gui, Show, w300 h115, ZyuL.io AHK "Camlock"
return

Submit:
Gui, Submit
if (UserKey = "") {
    MsgBox, ERROR 005: You must enter a license key! The program will now exit.
    ExitApp
}

HttpRequest := ComObjCreate("MSXML2.XMLHTTP")
HttpRequest.Open("GET", "https://pastebin.com/raw/2Vh1FJNB", false)
HttpRequest.Send()

if (HttpRequest.Status != 200) {
    MsgBox, ERROR 001: NO NETWORK CONNECTION
    ExitApp
}

Response := HttpRequest.ResponseText
Response := StrReplace(Response, "`r", "")
Keys := StrSplit(Response, "`n")

IsValidKey := false
Loop, % Keys.MaxIndex() {
    Key := Trim(Keys[A_Index])
    if (Key = UserKey) {
        IsValidKey := true
        break
    }
}

if (!IsValidKey) {
    MsgBox, ERROR 003: Invalid license key!
    ExitApp
}

MsgBox, Valid license key! ZyuL.io AHK Camlock Injected successfully!

msgbox, credits @piiercing

if !FileExist("config.json") {
    MsgBox, ERROR 002: CONFIG_JSON_NOT_FOUND
    ExitApp
}

file := FileOpen("config.json", "r")
json := JSON.Load(file.Read())
file.Close()

AimbotKey       := json.Binding.AimbotKey
Saturation      := json.PixelSearch.Saturation
ModelPixels     := json.PixelSearch.ModelPixels
PixelMoveAmount := json.PixelSearch.PixelMoveAmount
Smoothness      := json.Smoothing.Smoothness
SmoothingFactor := json.Smoothing.SmoothingFactor
Prediction      := json.Prediction.Prediction
PredictionX     := json.Prediction.PredictionX
PredictionY     := json.Prediction.PredictionY
SearchRadiusX   := json.SearchRadius.SearchRadiusX
SearchRadiusY   := json.SearchRadius.SearchRadiusY

ScreenWidth  := A_ScreenWidth
ScreenHeight := A_ScreenHeight
CenterX      := ScreenWidth // 2
CenterY      := ScreenHeight // 2

PreviousX := CenterX
PreviousY := CenterY

DllCall("QueryPerformanceFrequency", "Int64", Update)
DllCall("QueryPerformanceCounter", "Int64", LastTime)

SetTimer, AimbotLoop, 1
return

AimbotLoop:
if !GetKeyState(AimbotKey, "P") {
    PreviousX := CenterX
    PreviousY := CenterY
    return
}

Position := ModelSearch(CenterX - SearchRadiusX, CenterY - SearchRadiusY
    , CenterX + SearchRadiusX, CenterY + SearchRadiusY, ModelPixels, Saturation)

if (!ErrorLevel && Position[1] != "" && Position[2] != "") {
    LookAtX := Position[1]
    LookAtY := Position[2]

    if (Prediction) {
        LookAtX += PredictionX
        LookAtY += PredictionY
    }

    SmoothedX := PreviousX + (LookAtX - PreviousX) * SmoothingFactor
    SmoothedY := PreviousY + (LookAtY - PreviousY) * SmoothingFactor

    PreviousX := SmoothedX
    PreviousY := SmoothedY

    DllCall("mouse_event", "UInt", 0x8000|0x0001
        , "Int", Round((SmoothedX * 65535) / ScreenWidth)
        , "Int", Round((SmoothedY * 65535) / ScreenHeight)
        , "UInt", 0, "UInt", 0)
}
return

Clamp(Value, Min, Max) {
    if (Value < Min)
        return Min
    if (Value > Max)
        return Max
    return Value
}

ModelSearch(X1, Y1, X2, Y2, ColorIDs, Variation) {
    Position := []
    PixelSearch, OutputVarX, OutputVarY, %X1%, %Y1%, %X2%, %Y2%, %ColorIDs%, %Variation%, Fast RGB
    if (!ErrorLevel) {
        Position[1] := OutputVarX
        Position[2] := OutputVarY
    }
    return Position
}